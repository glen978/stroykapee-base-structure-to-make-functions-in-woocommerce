<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 */

get_template_part( 'index' );
