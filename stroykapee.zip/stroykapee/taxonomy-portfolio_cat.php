<?php
/**
 * The template for displaying portfolio category archive pages.
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 *
 */

get_header();

get_template_part( 'archive-portfolio' );

get_footer();?>