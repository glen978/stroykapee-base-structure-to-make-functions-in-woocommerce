<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
$layout = alaha_get_layout();
if($layout == 'full-width'){
	return;
}
$sidebar_name = alaha_get_sidebar_name();
?>

<div id="secondary" <?php alaha_sidebar_class();?>>
	<div class="sidebar-inner">
		<?php dynamic_sidebar( $sidebar_name ); ?>
	</div>
</div><!-- #secondary -->
