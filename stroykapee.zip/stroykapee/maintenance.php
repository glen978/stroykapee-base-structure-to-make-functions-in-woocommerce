<?php
/**
 * Template name: Maintenance 
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 */
 
//get_header(); 
?>
<!DOCTYPE html>
<?php do_action( 'alaha_before_html' ); ?>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<link rel="profile" href="http://gmpg.org/xfn/11">	
	<?php wp_head(); ?>
</head>
<body>
<!-- Wrapper main -->
<main id="main" class="site-main">
	<div class="coming-soon">
		<div class="container-fluid">
			<?php /* The loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
					<article id="post-<?php esc_attr( get_the_ID() ); ?>" <?php post_class(); ?>>

						<div class="entry-content">
							<?php the_content(); ?>
						</div>

					</article><!-- #post -->
			<?php endwhile; ?>                  
		</div> <!--.container-fluid-->
	</div> <!--.coming-soon-->
</main> <!--.main-->
<?php wp_footer(); ?>
</body>
</html>