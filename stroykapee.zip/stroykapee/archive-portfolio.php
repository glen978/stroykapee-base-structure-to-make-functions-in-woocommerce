<?php
/**
 * Template part for displaying archive portfolio
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 */

get_header(); ?>

<?php
/**
 * Hook: alaha_before_main_content.
 *
 * @hooked alaha_output_content_wrapper - 10 (outputs opening divs for the content area)
 */
do_action( 'alaha_before_main_content' );

if ( have_posts() ) :

	/**
	 * Hook: alaha_before_portfolio_loop.
	 *
	 * @hooked alaha_portfolio_filter - 10
	 */
	do_action( 'alaha_before_portfolio_loop' );
	
	alaha_portfolio_loop_start();
	
	while ( have_posts() ) :
		the_post();	
		
		// Include the portfolio loop content template.
		get_template_part( 'template-parts/portfolio-loop/layout', get_post_format() );

	endwhile;
	
	alaha_portfolio_loop_end();
	
	/**
	 * Hook: alaha_after_portfolio_loop.
	 *
	 * @hooked alaha_portfolio_pagination - 10
	 */
	do_action( 'alaha_after_portfolio_loop' );

else :

	get_template_part( 'template-parts/content', 'none' );

endif;

/**
 * Hook: alaha_after_main_content.
 *
 * @hooked alaha_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action( 'alaha_after_main_content' );

/**
 * Hook: alaha_sidebar.
 *
 * @hooked alaha_get_sidebar - 10
 */
do_action( 'alaha_sidebar' );?>

<?php get_footer();
