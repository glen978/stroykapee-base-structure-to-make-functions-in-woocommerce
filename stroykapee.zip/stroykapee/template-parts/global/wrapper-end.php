<?php
/**
 * Template part for displaying content wrappers
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 		stroykas
 * @package 	Stroyka/template-parts/global
 * @since 		1.0
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}?>

</div><!-- .entry-content-wrapper -->