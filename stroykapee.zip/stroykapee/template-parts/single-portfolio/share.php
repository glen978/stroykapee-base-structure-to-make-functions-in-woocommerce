<?php
/**
 * Template part for displaying share of project
 *
 * @author 	stroykas
 * @package alaha/template-parts/single-portfolio
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( function_exists( 'alaha_social_share' ) ) { ?>
	<div class="project-info-item">
		<h5><?php esc_html_e( 'Share', 'alaha' );?><span>:</span></h5>
		<?php alaha_social_share( 
			array('type' => 'share', 'style' => $social_icons_style, 'shape' => $social_icons_shape, 'size' => $social_icons_size ) ); ?>
	</div>
<?php } ?>