<?php
/**
 * Displays the post entry header
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/single-post
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<header class="entry-header">

	<?php
	/**
	 * Hook: alaha_single_post_header.
	 *
	 * @hooked alaha_template_single_post_title - 10
	 * @hooked alaha_template_single_post_meta - 20
	 */
	do_action( 'alaha_single_post_header' );
	?>
	
</header><!-- .entry-header -->