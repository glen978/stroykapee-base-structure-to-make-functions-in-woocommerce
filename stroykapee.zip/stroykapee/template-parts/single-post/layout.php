<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/single-post
 * @since 1.0
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$classes[] = 'single-post-page';
$classes[] = ( alaha_get_option('post-meta', 1) ) ? alaha_get_option('post-meta-separator', 'meta-separator-colon') : '';
$classes[] = ( alaha_get_option('post-meta', 1) && alaha_get_option('post-meta-icon', 1) ) ? 'post-meta-icon' : 'post-meta-label';
$classes[] = ( alaha_get_option('post-fancy-date', 1) ) ? alaha_get_option('fancy-date-style', 'fancy-square-date') : '';
$classes[] = ( alaha_get_option('single-post-thumbnail', 1) && alaha_has_post_thumbnail() ) ? 'has-post-thumbnail' : 'no-post-thumbnail';
$classes[] = ( is_sticky() ) ? 'sticky' : '';
?>

<?php do_action( 'alaha_before_single_post_entry' ); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	
	<?php
	/**
	 * alaha_single_post_entry_top hook.
	 *
	 * @hooked alaha_post_wrapper - 10
	 * @hooked alaha_single_post_header 	- 15
	 */
	do_action( 'alaha_single_post_entry_top' );
	?>
	
	<div class="entry-thumbnail-wrapper">
		<?php 
		/**
		 * alaha_single_post_thumbnail hook.
		 *
		 * @hooked alaha_template_single_post_fancy_date - 10
		 * @hooked alaha_template_single_post_highlight - 20
		 * @hooked alaha_template_single_post_thumbnail - 30
		 */
		do_action( 'alaha_single_post_thumbnail' );
		?>
	</div>
	
	<div class="entry-content-wrapper">
		<?php	
		/**
		 * alaha_single_post_content hook.
		 *		 
		 * @hooked alaha_single_post_content - 20
		 */
		do_action( 'alaha_single_post_content' );
		?>
	</div>
	
	<?php	
	/**
	 * alaha_single_post_entry_bottom hook.
	 *
	 * @hooked alaha_post_wrapper_end - 10
	 */
	do_action( 'alaha_single_post_entry_bottom' );
	?>
		
</article>

<?php
/**
 * alaha_after_single_post_entry hook.
 * 
 * @hooked alaha_template_single_post_author_bios - 10
 * @hooked alaha_template_single_social_share - 20
 * @hooked alaha_template_single_post_navigation - 30
 * @hooked alaha_template_single_related - 40
 * @hooked alaha_template_single_post_comments - 50
 */
do_action( 'alaha_after_single_post_entry' ); 