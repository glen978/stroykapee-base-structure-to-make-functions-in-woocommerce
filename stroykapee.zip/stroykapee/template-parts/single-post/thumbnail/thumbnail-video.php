<?php
/**
 * Displays the post entry image / gallery / audio / video etc. As per the post format.
 *
 * @package Stroyka Woocommerce theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( !alaha_get_option('single-post-thumbnail', 1) ) return;

// Get post video
$video = alaha_get_post_video();

if(! empty( $video ) ){?>
	<div class="entry-video">
		<?php echo apply_filters( 'alaha_post_video', $video ); // WPCS: XSS OK. ?>
	</div>
<?php }else{
	if( has_post_thumbnail() ){?>
		<div class="post-thumbnail">
		<?php the_post_thumbnail('large');?>
		</div>
	<?php }
}