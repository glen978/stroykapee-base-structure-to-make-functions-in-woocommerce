<?php
/**
 * Template part for displaying social profile icon on topbar
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/header
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$style 	= alaha_get_option( 'social-profile-icons-style', 'icons-default' );
$shape 	= alaha_get_option( 'profile-icons-shape', 'icons-shape-circle' );
$size 	= alaha_get_option( 'profile-icons-size', 'icons-size-small' );
if ( function_exists( 'alaha_social_share' ) ) {		
	alaha_social_share( 
		array(
			'type' => 'profile', 
			'style' => $style, 
			'shape' => $shape,
			'size' => $size
		) 
	);
}