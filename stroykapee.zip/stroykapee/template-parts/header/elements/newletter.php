<?php
/**
 * Template part for displaying newsletter
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/header
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>			

<span class="header-newsletter"><i class="icon-envelope"></i> <?php echo esc_html( alaha_get_option('header-newsletter','Newsletter') );?></span>
