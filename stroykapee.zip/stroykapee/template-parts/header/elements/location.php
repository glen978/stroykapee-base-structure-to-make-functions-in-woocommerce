<?php
/**
 * Template part for displaying location of topbar
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/header
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>			

<span class="contact-location"><i class="icon-location-pin"></i> <?php echo esc_html( alaha_get_option('header-location','123 Shop Street, New York, US') );?></span>
