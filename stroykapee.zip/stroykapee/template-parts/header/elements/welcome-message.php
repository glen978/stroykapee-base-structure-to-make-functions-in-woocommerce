<?php
/**
 * Template part for displaying welcome message of topbar
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/header
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>			

<span class="welcome-message"><?php echo esc_html( alaha_get_option('header-welcome-message', 'Welcome to Our Store!') );?></span>
