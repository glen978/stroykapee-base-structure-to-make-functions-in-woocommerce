<?php
/**
 * Template part for displaying page layout
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Stroyka
 * @since 1.0
 */

do_action( 'alaha_before_page_entry' );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<?php	
	/**
	 * alaha_page_content hook.
	 *		 
	 * @hooked alaha_template_page_content - 10
	 */
	do_action( 'alaha_page_content' );
	?>	
</article><!-- #post-## -->

<?php
/**
 * alaha_after_page_entry hook.
 * 
 * @hooked alaha_template_page_comments - 10
 */
do_action( 'alaha_after_page_entry' ); 
