<?php
/**
 * Post Loop Start
 *
 * @author 	stroykas
 * @package alaha/template-parts/post-loop
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="<?php alaha_blog_wrapper_classes();?>">


