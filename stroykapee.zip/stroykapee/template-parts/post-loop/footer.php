<?php
/**
 * Displays the post entry footer
 *
 * @author 	stroykas
 * @package alaha/template-parts/post-loop
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="entry-footer">
	<?php 
	/**
	 * alaha_loop_post_footer hook.
	 *
	 * @hooked alaha_read_more_link - 10
	 */
	do_action( 'alaha_loop_post_footer' );
	?>
</div>