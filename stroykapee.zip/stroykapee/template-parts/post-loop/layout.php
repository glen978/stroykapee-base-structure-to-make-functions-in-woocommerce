<?php
/**
 * Template part for displaying posts
 *
 * @author 	stroykas
 * @package alaha/template-parts/post-loop
 * @since 1.0
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$blog_post_style	= alaha_get_loop_prop( 'blog-post-style' );	
if( alaha_get_loop_prop('name') == 'related-posts') {
	$classes[] = 'related-post';
}else{
	$classes[]   = 'blog-post-loop';
}
$classes[] = ( ! alaha_get_loop_prop( 'blog-post-thumbnail' ) ) ? 'no-post-thumbnail' : '';
if(alaha_get_loop_prop('name') == 'posts-loop-shortcode'){
	if( $blog_post_style == 'blog-grid'){
		$classes[] = alaha_get_grid_class( alaha_get_loop_prop( 'blog-grid-columns' ) );
	}				
}elseif( $blog_post_style == 'blog-grid' && !is_single()){
	if(alaha_get_loop_prop('name') != 'posts-slider-shortcode'){
		$classes[] = alaha_get_grid_class( alaha_get_loop_prop( 'blog-grid-columns' ) );
	}					
}
$classes[] = ( alaha_get_loop_prop( 'post-meta' ) ) ? alaha_get_loop_prop( 'post-meta-separator' ) : '';
$classes[] = ( alaha_get_loop_prop( 'post-meta' ) && alaha_get_loop_prop( 'post-meta-icon' ) ) ? 'post-meta-icon' : 'post-meta-label';
$classes[] = ( alaha_get_loop_prop( 'post-fancy-date' ) ) ? alaha_get_loop_prop( 'fancy-date-style' ) : '';
?>

<?php do_action( 'alaha_before_loop_post_entry' ); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ); ?>>
	
	<?php
	/**
	 * alaha_loop_post_entry_top hook.
	 *
	 * @hooked alaha_post_wrapper - 10
	 */
	do_action( 'alaha_loop_post_entry_top' );
	?>
	
	<div class="entry-thumbnail-wrapper">
		<?php 
		/**
		 * alaha_loop_post_thumbnail hook.
		 *
		 * @hooked alaha_template_loop_post_fancy_date - 10
		 * @hooked alaha_template_loop_post_highlight - 20
		 * @hooked alaha_template_loop_post_thumbnail - 30
		 */
		do_action( 'alaha_loop_post_thumbnail' );
		?>
	</div>
	
	<div class="entry-content-wrapper">
		<?php	
		/**
		 * alaha_loop_post_content hook.
		 *
		 * @hooked alaha_loo_post_header 	- 10
		 * @hooked alaha_loop_post_content 	- 20
		 * @hooked alaha_loop_post_footer 	- 30
		 */
		do_action( 'alaha_loop_post_content' );
		?>
	</div>
	
	<?php	
	/**
	 * alaha_loop_post_entry_bottom hook.
	 *
	 * @hooked alaha_post_wrapper_end - 10
	 */
	do_action( 'alaha_loop_post_entry_bottom' );
	?>
		
</article>

<?php
do_action( 'alaha_after_loop_post_entry' ); 