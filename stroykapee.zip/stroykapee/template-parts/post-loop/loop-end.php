<?php
/**
 * Post Loop End
 *
 * @author 	stroykas
 * @package alaha/template-parts/post-loop
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>