<?php
/**
 * Displays the post entry header
 *
 * @author 	stroykas
 * @package alaha/template-parts/post-loop
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<header class="entry-header">

	<?php
	/**
	 * Hook: alaha_loop_post_header.
	 *
	 * @hooked alaha_template_loop_post_title - 10
	 * @hooked alaha_template_loop_post_meta - 20
	 */
	do_action( 'alaha_loop_post_header' );
	?>
	
</header><!-- .entry-header -->