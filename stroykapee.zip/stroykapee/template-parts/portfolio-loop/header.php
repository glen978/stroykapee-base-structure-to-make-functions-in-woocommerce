<?php
/**
 * Displays the portfolio entry header
 *
 * @author 	stroykas
 * @package alaha/template-parts/portfolio
 * @since 1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<header class="entry-header">

	<?php
	/**
	 * Hook: alaha_portfolio_loop_header.
	 *
	 * @hooked alaha_template_portfolio_loop_categories - 10
	 * @hooked alaha_template_portfolio_loop_title - 20
	 */
	do_action( 'alaha_portfolio_loop_header' );
	?>
	
</header><!-- .entry-header -->