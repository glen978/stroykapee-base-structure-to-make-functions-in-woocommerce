<?php
/**
 * Portfolio loop stat
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 		stroykas
 * @package 	Stroyka/template-parts/portfolio
 * @since 	1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="<?php alaha_portfolio_wrapper_classes();?>">