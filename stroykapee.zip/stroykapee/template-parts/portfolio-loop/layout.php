<?php
/**
 * Template part for displaying portfolio layout
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @author 	stroykas
 * @package alaha/template-parts/portfolio
 * @since 1.0
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if( alaha_get_loop_prop('name') == 'related-portfolios') {
	$classes[] = 'portfolio-post-loop';
	$classes[] = 'related-portfolio';
}elseif( alaha_get_loop_prop('name') == 'portfolios-slider-shortcode') {
	$classes[] = 'portfolio-post-loop';
	$classes[] = 'portfolios-slider-shortcode';
}else{
	$classes[] = 'portfolio-post-loop';
	$classes[] = 'col-12 col-sm-6 col-md-6 col-lg-'. 12 / alaha_get_loop_prop( 'portfolio-grid-columns' ) ;
}
?>
<?php do_action( 'alaha_before_portfolio_loop_entry' ); ?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $classes ) ?> > 
	
	<?php
	/**
	 * alaha_portfolio_loop_entry_top hook.
	 *
	 * @hooked alaha_post_wrapper - 10
	 */
	do_action( 'alaha_portfolio_loop_entry_top' );
	?>
	
	<div class="entry-thumbnail-wrapper">
		<?php 
		/**
		 * alaha_portfolio_loop_thumbnail hook.
		 *
		 * @hooked alaha_template_portfolio_loop_thumbnail - 10
		 * @hooked alaha_template_portfolio_loop_action_icon - 20
		 */
		do_action( 'alaha_portfolio_loop_thumbnail' );
		?>
	</div>
	
	<div class="entry-content-wrapper">
		<?php	
		/**
		 * alaha_portfolio_loop_content hook.
		 *
		 * @hooked alaha_portfolio_loop_header 	- 10
		 * @hooked alaha_portfolio_loop_content 	- 20
		 * @hooked alaha_portfolio_loop_footer 	- 30
		 */
		do_action( 'alaha_portfolio_loop_content' );
		?>
	</div>
	
	<?php	
	/**
	 * alaha_portfolio_loop_entry_bottom hook.
	 *
	 * @hooked alaha_post_wrapper_end - 10
	 */
	do_action( 'alaha_portfolio_loop_entry_bottom' );
	?>
		
</article>

<?php
do_action( 'alaha_after_portfolio_loop_entry' ); 
