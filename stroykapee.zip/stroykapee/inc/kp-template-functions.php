<?php
/**
 * Functions to allow styling of the templating system
 *
 * @author 		stroykas
 * @package 	alaha/inc
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Sets up the alaha_loop global from the passed args.
 */
function alaha_setup_loop( $args = array() ) {
	
	$default_args = array(
		'name'          						=> 'posts-loop',
		//Blog
		'post-fancy-date'          				=> alaha_get_option( 'post-fancy-date', 1 ),
		'fancy-date-style'          			=> alaha_get_option( 'fancy-date-style','fancy-square-date' ),
		'sticky-post-icon'          			=> alaha_get_option( 'sticky-post-icon', 1 ),
		'post-format-icon'          			=> alaha_get_option( 'post-format-icon', 0 ),
		'post-meta'          					=> alaha_get_option( 'post-meta', 1 ),
		'specific-post-meta'          			=> alaha_get_option( 'specific-post-meta', array( 'post-author', 'post-category', 'post-comments', 'post-share' ) ),
		'post-meta-icon'          				=> alaha_get_option( 'post-meta-icon', 1 ),
		'post-meta-separator'          			=> alaha_get_option( 'post-meta-separator', 'meta-separator-colon' ),
		//Blog Archive
		'blog-post-style'          				=> alaha_get_option( 'blog-post-style', 'blog-bottom-overlap' ),
		'blog-grid-layout'          			=> alaha_get_option( 'blog-grid-layout', 'simple-grid' ),
		'blog-grid-post-style'          		=> alaha_get_option( 'blog-grid-post-style', 'blog-grid-bottom-overlap' ),
		'blog-grid-columns'          			=> alaha_get_option( 'blog-grid-columns', '2' ),
		'blog-post-thumbnail'          			=> alaha_get_option( 'blog-post-thumbnail', 1 ),
		'blog-post-title'          				=> alaha_get_option( 'blog-post-title', 1 ),
		'blog-post-content'          			=> alaha_get_option( 'blog-post-content', 'full-content' ),
		'blog-excerpt-length'          			=> alaha_get_option( 'blog-excerpt-length', 30 ),
		'read-more-button'          			=> alaha_get_option( 'read-more-button', 1 ),
		'read-more-button-style'          		=> alaha_get_option( 'read-more-button-style', 'read-more-link' ),
		'read-more-text'          				=> alaha_get_option( 'read-more-text', 'Continue Reading' ),
		'blog-pagination-style'          		=> alaha_get_option( 'blog-pagination-style', 'default' ),
		'blog-pagination-load-more-button-text'	=> alaha_get_option( 'blog-pagination-load-more-button-text', 'Load More Posts' ),
		'blog-pagination-finished-message'		=> alaha_get_option( 'blog-pagination-finished-message', 'No More Posts Available...' ),
		/* Portfolio options */
		'portfolio-post-thumbnail'          	=> alaha_get_option( 'portfolio-post-thumbnail', 1 ),
		'portfolio-style'          				=> alaha_get_option( 'portfolio-style', 'portfolio-style-1' ),
		'portfolio-grid-layout'          		=> alaha_get_option( 'portfolio-grid-layout', 'masonry-grid' ),
		'portfolio-grid-gap'          			=> alaha_get_option( 'portfolio-grid-gap', 15 ),
		'portfolio-grid-columns'          		=> alaha_get_option( 'portfolio-grid-columns', 3 ),
		'portfolio-filter'          			=> alaha_get_option( 'portfolio-filter', 1 ),
		'portfolio-per-page'          			=> alaha_get_option( 'portfolio-per-page', 9 ),
		'portfolio-button-icon'          		=> alaha_get_option( 'portfolio-button-icon', 1 ),
		'portfolio-link-icon'          			=> alaha_get_option( 'portfolio-link-icon', 1 ),
		'portfolio-zoom-icon'          			=> alaha_get_option( 'portfolio-zoom-icon', 1 ),
		'portfolio-content-part'          		=> alaha_get_option( 'portfolio-content-part', 1 ),
		'portfolio-category'          			=> alaha_get_option( 'portfolio-category',1 ),
		'portfolio-title'          				=> alaha_get_option( 'portfolio-title', 1 ),
		'portfolio-pagination-style'          	=> alaha_get_option( 'portfolio-pagination-style','default'),
		'portfolio-pagination-load-more-button-text'=> alaha_get_option( 'portfolio-pagination-load-more-button-text','Load More Portfolios' ),
		'portfolio-pagination-finished-message'	=> alaha_get_option( 'portfolio-pagination-finished-message', 'No More Portfolios Available...' ),
		/* woocommerce */
		'product-labels'        				=> alaha_get_option( 'product-labels', 1 ),
		'sale-product-label'        			=> alaha_get_option( 'sale-product-label', 1 ),
		'sale-product-label-after-price'        => alaha_get_option( 'sale-product-label-after-price', 'after-price'),
		'sale-single-product-label-after-price' => alaha_get_option( 'sale-single-product-label-after-price', 'after-price'),
		'sale-product-label-text-options'       => alaha_get_option( 'sale-product-label-text-options', 'percentage' ),
		'sale-product-label-percentage-text'    => alaha_get_option( 'sale-product-label-percentage-text', 'Off' ),
		'sale-product-label-text'        		=> alaha_get_option( 'sale-product-label-text', 'Sale' ),
		'sale-product-label-color'        		=> alaha_get_option( 'sale-product-label-color','#82B440' ),
		'product-new-label'        				=> alaha_get_option( 'product-new-label', 1 ),
		'new-product-label-text'        		=> alaha_get_option( 'new-product-label-text','New' ),
		'product-newness-days'        			=> alaha_get_option( 'product-newness-days', 30 ),
		'new-product-label-color'        		=> alaha_get_option( 'new-product-label-color', '#388e3c' ),
		'featured-product-label'        		=> alaha_get_option( 'featured-product-label', 1 ),
		'featured-product-label-text'        	=> alaha_get_option( 'featured-product-label-text', 'Featured' ),
		'featured-product-label-color'        	=> alaha_get_option( 'featured-product-label-color', '#ff9f00' ),
		'outofstock-product-label'        		=> alaha_get_option( 'outofstock-product-label', 1 ),
		'outofstock-product-label-text'        	=> alaha_get_option( 'outofstock-product-label-text', 'Out Of Stock' ),
		'outofstock-product-label-color'        => alaha_get_option( 'outofstock-product-label-color','#ff6161'),
		'outofstock-product-opacity'        	=> alaha_get_option( 'outofstock-product-opacity', .6 ),
		'products-default-view'          		=> alaha_get_option( 'products-default-view', 'grid-view' ),
		'products-columns'          			=> alaha_get_option( 'products-columns', 4 ),
		'products-element'          			=> '',
		'products-columns-mobile'          		=> alaha_get_option( 'products-columns-mobile', 2 ),
		'products-pagination-style'          	=> alaha_get_option( 'products-pagination-style', 'default' ),
		'products-pagination-load-more-button-text'	=> alaha_get_option( 'products-pagination-load-more-button-text', 'Load More Products' ),
		'products-pagination-finished-message'	=> alaha_get_option( 'products-pagination-finished-message', 'No More Products Available...' ),
		'products-countdown'          			=> alaha_get_option( 'products-countdown', 0 ),
		'product-style'          				=> alaha_get_option( 'product-style','product-style-1' ),
		'product-action-buttons-style'    		=> '',
		'products-hover-image'          		=> alaha_get_option( 'products-hover-image', 1 ),
		'products-category'          			=> alaha_get_option( 'products-category', 1 ),
		'products-title'          				=> alaha_get_option( 'products-title', 1 ),
		'products-rating'          				=> alaha_get_option( 'products-rating', 1 ),
		'products-rating-style'          		=> alaha_get_option( 'products-rating-style', 'fancy-rating' ),
		'products-rating-count'          		=> alaha_get_option( 'products-rating-count', 1 ),
		'products-rating-histogram'          	=> alaha_get_option( 'products-rating-histogram', 1 ),
		'products-price'          				=> alaha_get_option( 'products-price', 1 ),
		'products-variations'          			=> alaha_get_option( 'products-variations', 1 ),
		'products-short-description'          	=> alaha_get_option( 'products-short-description', 1 ),
		'products_view'							=> function_exists ( 'alaha_get_products_view' ) ? alaha_get_products_view() : 'grid-view',
		'category-style'						=> alaha_get_option('category-style', 'category-style-1' ),
	);
	
	// Merge any existing values.
	if ( isset( $GLOBALS['alaha_loop'] ) ) {
		$default_args = array_merge( $default_args, $GLOBALS['alaha_loop'] );
	}

	$GLOBALS['alaha_loop'] = wp_parse_args( $args, $default_args );
}
add_action( 'woocommerce_before_shop_loop', 'alaha_setup_loop' );
add_action( 'wp', 'alaha_setup_loop', 10 );

/**
 * Sets a property in the alaha_loop global.
 */
function alaha_set_loop_prop( $prop, $value = '' ) {
	if ( ! isset( $GLOBALS['alaha_loop'] ) ) {
		alaha_setup_loop();
	}
	$GLOBALS['alaha_loop'][ $prop ] = $value;
}

/**
 * Resets the alaha_loop global.
 */
function alaha_reset_loop() {
	unset( $GLOBALS['alaha_loop'] );
}
add_action( 'woocommerce_after_shop_loop', 'woocommerce_reset_loop', 999 );
//add_action( 'loop_end', 'alaha_reset_loop', 999 );

/**
 * Gets a property from the alaha_loop global.
 */
if ( ! function_exists( 'alaha_get_loop_prop' ) ) {
	function alaha_get_loop_prop( $prop, $default = '' ) {

		alaha_setup_loop(); // Ensure post loop is setup.

		$value = isset( $GLOBALS['alaha_loop'], $GLOBALS['alaha_loop'][ $prop ] ) ? $GLOBALS['alaha_loop'][ $prop ] : $default;
		$value = apply_filters( 'alaha_get_loop_prop' , $value, $prop, $GLOBALS['alaha_loop']);
		return apply_filters( 'alaha_get_loop_prop_' . $prop, $value, $prop,$GLOBALS['alaha_loop']) ;
	}
}

/**
 * Adds custom classes to the array of body classes.
 */
function alaha_body_classes( $classes ) {
	
	$classes[] 			= 'wrapper-' . alaha_get_option( 'theme-layout', 'full' );
	
	// Owl nav style
	$classes[] 			= alaha_get_option( 'slider-nav-style', 'owl-nav-rectangle' );
	$classes[] 			= alaha_get_option( 'slider-nav-position', 'owl-nav-middle' );	
	$classes[] 			= alaha_get_option( 'widget-title-style', 'widget-title-bordered-full' );
	$layout 			= alaha_get_layout();
	
	if( alaha_get_option( 'open-categories-menu', 0 ) && is_front_page()){
		$classes[] = 'open-categories-menu';
	}
	
	if( $layout != 'full-width' ){
		$classes[] = 'has-sidebar';
	}else{
		$classes[] = 'no-sidebar';
	}
	
	if( alaha_get_option( 'ajax-filter', 0 ) && alaha_is_catalog() ){
		$classes[] = 'alaha-catalog-ajax-filter';
	}
	
	if( alaha_get_option( 'widget-toggle', 0 ) ){
		$classes[] = 'has-widget-toggle';
	}
	
	if( alaha_get_option( 'widget-menu-toggle', 0 ) ){
		$classes[] = 'has-widget-menu-toggle';
	}
	
	if( alaha_get_option('sidebar-canvas-mobile', 0 ) ){
		$classes[] = 'has-mobile-canvas-sidebar';
	}		

	return $classes;
}

/**
 * Adds custom class to the array of posts classes.
 */
function alaha_post_classes( $classes, $class, $post_id ) {
	//$classes[] = 'entry';

	return $classes;
}

/**
 * Display classes for primary div
 */
if ( ! function_exists( 'alaha_primary_class' ) ) :
	function alaha_primary_class( $class = '' ) {
		echo 'class="' . esc_attr( join( ' ', alaha_get_primary_class( $class ) ) ) . '"';
	}
endif;

/**
 * Retrieve the classes for the primary element as an array.
 */
if ( ! function_exists( 'alaha_get_primary_class' ) ) :
	function alaha_get_primary_class( $class = '' ) {
		$classes 		= array();
		$page_id 		= get_the_ID();
		$page_layout 	= get_post_meta( $page_id, ALAHA_PREFIX.'page_sidebar_position', true );
		
		$classes[] = 'content-area';
		
		$content_columns = alaha_get_content_columns();
		if(!empty($content_columns)){
			$classes = array_merge($classes,$content_columns);
		}
		
		if ( ! empty( $class ) ) {
			if ( ! is_array( $class ) ) {
				$class = preg_split( '#\s+#', $class );
			}
			$classes = array_merge( $classes, $class );
		} else {
			$class = array();
		}
		
		$classes = apply_filters( 'alaha_primary_class', $classes, $class );
		$classes = array_map( 'sanitize_html_class', $classes );

		return array_unique( $classes );
	}
endif;


/**
 * Display classes for sidebar div
 */
if ( ! function_exists( 'alaha_sidebar_class' ) ) :
	function alaha_sidebar_class( $class = '' ) {
		echo 'class="' . esc_attr( join( ' ', alaha_get_sidebar_class( $class ) ) ) . '"';
	}
endif;

/**
 * Retrieve the classes for the sidebar as an array.
 */
if ( ! function_exists( 'alaha_get_sidebar_class' ) ) :
	function alaha_get_sidebar_class( $class = '' ) {
		$classes 		= array();
		$classes[] = 'widget-area';
		
		$sidebar_columns = alaha_get_sidebar_columns();		
		if(!empty($sidebar_columns)){
			$classes = array_merge($classes,$sidebar_columns);
		}
		
		if ( ! empty( $class ) ) {
			if ( ! is_array( $class ) ) {
				$class = preg_split( '#\s+#', $class );
			}
			$classes = array_merge( $classes, $class );
		} else {
			$class = array();
		}
		
		$classes = apply_filters( 'alaha_sidebar_class', $classes, $class );

		return array_unique( $classes );
	}
endif;

/**
 * Blog wrapper classes
 */
if( !function_exists( 'alaha_blog_wrapper_classes' ) ):
	function alaha_blog_wrapper_classes() {			
		$classes = array();
		if( alaha_get_loop_prop('name') == 'related-posts'){
			$classes[] = 'blog-grid-bottom-overlap';
			
			if(alaha_get_option('related-posts-display', 'slider') =='slider') {
				$classes[] = 'alaha-carousel';
				$classes[] = 'owl-carousel';
			}else{
				$classes[] = 'items-grid';
			}
			$classes[] = ( alaha_get_option('read-more-button-style', 1) ) ? alaha_get_option('read-more-button-style', 'read-more-link') : '';
		}else{
			$blog_post_style	= alaha_get_loop_prop( 'blog-post-style' );
			$blog_grid_layout	= alaha_get_loop_prop( 'blog-grid-layout' );		
			
			$classes[] ='articles-list';
			if($blog_post_style == 'blog-grid' && alaha_get_loop_prop('name') != 'posts-slider-shortcode'){
				$classes[] ='row';
			}
			
			
			if( $blog_grid_layout == 'masonry-grid'){
				wp_enqueue_script('masonry');
			}	
			
			$classes[] = $blog_post_style;
			if($blog_post_style == 'blog-grid'){
				$classes[] = alaha_get_loop_prop( 'blog-grid-post-style' );
				$classes[] = $blog_grid_layout;
			}
			if(alaha_get_loop_prop('name') == 'posts-slider-shortcode'){
				$classes[] = 'alaha-carousel';
				$classes[] = 'owl-carousel';
			}
			$classes[] = ( alaha_get_loop_prop( 'read-more-button-style' ) ) ? alaha_get_loop_prop( 'read-more-button-style' ) : '';
		}			
				
		$classes = apply_filters( 'alaha_blog_wrapper_classes', $classes );
		
		if ( is_array( $classes ) ) {
			$classes = implode( ' ', $classes );
		}
		
		echo esc_attr( $classes );
	}
endif;
 
/**
 * Portfolio wrapper classes
 */
if( !function_exists( 'alaha_portfolio_wrapper_classes' ) ):
	function alaha_portfolio_wrapper_classes() {
		
		$classes = array();
		$portfolio_style		= alaha_get_loop_prop( 'portfolio-style' );
		$portfolio_grid_layout	= alaha_get_loop_prop( 'portfolio-grid-layout' );		
		
		if( alaha_get_loop_prop('name') == 'related-portfolios'){			
			$classes[] = 'portfolio-style-1';			
			if(alaha_get_option('related-portfolios-display', 'slider') =='slider') {
				$classes[] = 'alaha-carousel';
				$classes[] = 'owl-carousel';
			}else{
				$classes[] = 'items-grid';
			}
		}else{			
			
			if( alaha_get_loop_prop('name') == 'portfolios-slider-shortcode'){
				$classes[] = 'alaha-carousel';
				$classes[] = 'owl-carousel';
				$classes[] = 'items-grid';
			}else{
				$classes[] = 'portfolios-list';
				$classes[] = 'row';
			}
			if(  $portfolio_style != 'portfolio-style-1' && $portfolio_style != 'portfolio-style-2' ){
				$classes[] ='gutters-space-'.alaha_get_loop_prop( 'portfolio-grid-gap' );		
			}
			if( !alaha_get_loop_prop( 'portfolio-content-part' )){
				$classes[] ='no-content-part';
			}
			
			if( $portfolio_grid_layout == 'masonry-grid'){
				wp_enqueue_script('masonry');
			}		
			$classes[] = $portfolio_grid_layout;
			$classes[] = alaha_get_loop_prop( 'portfolio-style' );
			if(alaha_get_loop_prop('portfolio-filter')){
				$classes[] = 'portfolio-filter-enabled';
			}
			
		}
		
		$classes = apply_filters( 'alaha_portfolio_wrapper_classes', $classes );
		
		if ( is_array( $classes ) ) {
			$classes = implode( ' ', $classes );
		}
		
		echo esc_attr( $classes );
	}
endif;

/**
 * Checks to see if we're on the homepage or not.
 */
function alaha_is_frontpage() {
	return ( is_front_page() && ! is_home() );
}

/**
 * Checks to see if we're on the homepage or not.
 */
function alaha_site_loader() {
	
	if( ! alaha_get_option( 'site-preloader', 0 ) ) return;
	
	if( 'predefine-loader' == alaha_get_option('preloader-image', 'predefine-loader' ) ){
		$preloader_style = alaha_get_option('predefine-loader-style', '1' );
		$html = '';
		switch ( $preloader_style ) {
			case '1':
				$html ='<div class="spinner style-'.$preloader_style.'">
					<div class="bounce1"></div>
					<div class="bounce2"></div>
					<div class="bounce3"></div>
				</div>';
				break;
			case '2':
				$html ='<div class="sk-folding-cube style-'.$preloader_style.'">
						<div class="sk-cube1 sk-cube"></div>
						<div class="sk-cube2 sk-cube"></div>
						<div class="sk-cube4 sk-cube"></div>
						<div class="sk-cube3 sk-cube"></div>
					</div>';
				break;
			case '3':
				$html ='<div class="spinner style-'.$preloader_style.'"></div>';
				break;
			case '4':
				$html ='<div class="spinner style-'.$preloader_style.'">						
						<div class="double-bounce1"></div>
						<div class="double-bounce2"></div>
					</div>';
				break;
			case '5':
				$html ='<div class="spinner style-'.$preloader_style.'">						
						<div class="rect1"></div>
						<div class="rect2"></div>
						<div class="rect3"></div>
						<div class="rect4"></div>
						<div class="rect5"></div>
					</div>';
				break;
		}
		$html = '<div class="alaha-site-preloader">'.$html.'</div>';
	}else{		
		$html = '<div class="alaha-site-preloader"></div>';
	}
	
	echo apply_filters( 'alaha_site_preloader', $html, $preloader_style );
}

/**
 * Global
 */
if ( ! function_exists( 'alaha_output_content_wrapper' ) ) {

	/**
	 * Output the start of the page wrapper.
	 */
	function alaha_output_content_wrapper() {
		alaha_get_template( 'template-parts/global/wrapper-start.php' );		
	}
}
if ( ! function_exists( 'alaha_output_content_wrapper_end' ) ) {

	/**
	 * Output the end of the page wrapper.
	 */
	function alaha_output_content_wrapper_end() {
		alaha_get_template( 'template-parts/global/wrapper-end.php' );
	}
}
if( ! function_exists( 'alaha_mobile_menu' ) ) {
	/**
	 * Header Mobile menu
	 */
	function alaha_mobile_menu() {
		$mobile_menu = 'mobile-menu';
		if ( !has_nav_menu( $mobile_menu ) ) {	
			$mobile_menu = 'primary';
		}
		$location 			= apply_filters( 'alaha_mobile_menu_location', $mobile_menu );		
		$mobile_signup_text	= apply_filters( 'alaha_mobile_signup_text', esc_html__('Login & Signup','alaha') );
		$mobile_menu_text	= apply_filters( 'alaha_mobile_menu_text', esc_html__('Menu','alaha') );
		$mobile_categories_text	= apply_filters( 'alaha_mobile_categories_text', esc_html__('Categories','alaha') );
		$menu_link 			= get_admin_url( null, 'nav-menus.php' );		
		$user_data 			= wp_get_current_user();
		$current_user 		= apply_filters('alaha_myaccount_username',$user_data->user_login );	?>		
		<div id="mobile-menu-wrapper" class="mobile-menu-wrapper">
			<?php
			if( ALAHA_WOOCOMMERCE_ACTIVE ){
				$dashboard_url	= apply_filters('alaha_myaccount_dashboard_url', wc_get_page_permalink( 'myaccount' ) ); ?>
				<div class="mobile-menu-header">
					<?php if( ! is_user_logged_in() ):?>
						<a class="customer-signinup" href="<?php echo ( alaha_get_option('login-signin-popup', 1) ) ? 'javaScript:void(0)' : esc_url($dashboard_url);?>"><?php echo esc_html($mobile_signup_text);?></a>
					<?php else:?>
						<a class="user-myaccount" href="<?php echo esc_url($dashboard_url);?>"><?php echo esc_html($current_user);?></a>
					<?php endif;?>
				</div>
			<?php } ?>
			
			<?php if( has_nav_menu( $location ) || has_nav_menu( 'categories-menu' ) ){ ?>
				<div class="mobile-nav-tabs">
					<ul>
						<li class="primary active" data-menu="primary"><span><?php echo esc_html( $mobile_menu_text );?></span></li>
						<?php if ( alaha_get_option('show-categories-menu', 1 ) && has_nav_menu( 'categories-menu' ) ) { ?>
							<li class="categories" data-menu="categories"><span><?php echo esc_html($mobile_categories_text);?></span></li>
						<?php } ?>
					</ul>
				</div>
			<?php } ?>
			
			<?php
			// Mobile Primary Menu
			$admin_menu_link = get_admin_url( null, 'nav-menus.php' );
			if ( has_nav_menu( $location ) ) {
				wp_nav_menu( array( 
					'theme_location' 	=> $location,
					'menu_class'      	=> 'mobile-main-menu',
					'container_class'	=> 'mobile-primary-menu mobile-nav-content active',
					'fallback_cb' 		=> '',
					'walker' 			=> new Stroyka_Menu_Walker()
				) ); 			
			}else{ ?>
				<div class="mobile-primary-menu mobile-nav-content active">
					<span class="add-navigation-message">
						<?php printf( wp_kses( __('Add your <a href="%s">navigation menu here</a>', 'alaha' ),array( 'a' => array( 'href' => array() )	) )	, $admin_menu_link );	?>
					</span>
				</div>
			<?php }
			
			// Mobile Categories Menu
			if ( alaha_get_option('show-categories-menu', 1 ) && has_nav_menu( 'categories-menu' ) ) {
				wp_nav_menu( array( 
					'theme_location' 	=> 'categories-menu',
					'menu_class'      	=> 'mobile-main-menu',
					'container_class'   => 'mobile-categories-menu mobile-nav-content',
					'fallback_cb' 		=> '',
					'walker' 			=> new Stroyka_Menu_Walker()
				) );
			}?>
			
			<div class="mobile-topbar">
				<?php 
				alaha_get_template( 'template-parts/header/elements/language-switcher' );
				alaha_get_template( 'template-parts/header/elements/currency-switcher' );
				alaha_get_template( 'template-parts/header/elements/social-profile' );
				?>
			</div>			
		</div>
		<?php
	}
	add_action( 'alaha_body_bottom', 'alaha_mobile_menu', 100 );
}
/**
 * Header
 */
if ( ! function_exists( 'alaha_template_header' ) ) {

	/**
	 * Stroyka template header.
	 */
	function alaha_template_header() {

		$args = $class = array();
		
		$header_style 			= alaha_get_post_meta('header_style');
		if(!$header_style || $header_style == 'default'){
			if( alaha_get_option( 'header-select', 'style' ) == 'style' ){
				$header_style 	= alaha_get_option( 'header-style', '1' );
			}else{
				$header_style 	= alaha_get_option( 'header-select', 'builder' );
			}
		}	
		$header_style 			= apply_filters( 'alaha_header_style', $header_style );
		$class[]				= 'header-'.$header_style;
		
		$header_top 			= alaha_get_post_meta('header_top');
		$header 				= alaha_get_post_meta('header');
		$header_transparent 	= alaha_get_post_meta('header_transparent');

		if(!$header_top || $header_top == 'default'){
			$header_top = alaha_get_option( 'header-topbar', 1 );				
		}elseif($header_top == 'enable'){
			$header_top = 1;
		}elseif($header_top == 'disable'){
				$header_top = 0;
		}

		if( ! $header || $header == 'default' ){
			$header = 1;				
		}elseif($header == 'enable'){
			$header = 1;
		}elseif($header == 'disable'){
				$header = 0;
		}

		if( ! $header_transparent || 'default' == $header_transparent ){
			$header_transparent = 0;
			if( alaha_get_option( 'header-transparent', 0 ) ){
				if ( is_front_page() && 'front-page' == alaha_get_option( 'header-transparent-on', 'front-page' ) ) {
					$header_transparent = 1;
				}elseif( 'all-pages' == alaha_get_option( 'header-transparent-on', 'front-page' ) ){
					$header_transparent = 1;
				}
			}
		}elseif( 'enable' == $header_transparent ){
			$header_transparent = 1;
		}elseif( 'disable' == $header_transparent ){
			$header_transparent = 0;
		}
		
		if( ALAHA_WOOCOMMERCE_ACTIVE && is_product() ){
			$header_transparent = 0;
		}
		
		if( $header_transparent ){
			$class[]	= 'header-overlay';
			$class[]	= 'header-color-'.alaha_get_option( 'header-transparent-color', 'dark' );
		}
		
		$args['header_style'] 	= 'header-'.$header_style;
		$args['class']	 		= implode( ' ', array_filter( $class ) );
		$args['header_top'] 	= $header_top;
		$args['header'] 		= $header;
		
		if( ! $header ) return;
		
		alaha_get_template( 'template-parts/header/header',$args );
	}
}

function alaha_is_empty_column( $col ){
	return empty( array_filter( $col ) );
}
function alaha_is_empty_elements( $el ){
	
}
if ( ! function_exists( 'alaha_header_topbar_left' ) ) {

	/**
	 * Output header topbar left.
	 */
	function alaha_header_topbar_left() {
		$elements = alaha_get_option( 'header-topbar-manager', array ( 'left' => array ( 'language-switcher' => 'Language Switcher', 'currency-switcher' => 'Currency Switcher' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_topbar_right' ) ) {

	/**
	 * Output header topbar right.
	 */
	function alaha_header_topbar_right() {
		$elements = alaha_get_option( 'header-topbar-manager', array ( 'right' => array ( 'topbar-menu' => 'Topbar Menu' ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_main_left' ) ) {

	/**
	 * Output header main left.
	 */
	function alaha_header_main_left() {
		$elements = alaha_get_option( 'header-main-manager', array ( 'left' => array ( 'logo' => 'Logo' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_main_center' ) ) {

	/**
	 * Output header main center.
	 */
	function alaha_header_main_center() {
		$elements = alaha_get_option( 'header-main-manager', array ( 'center' => array ( 'ajax-search' => 'Ajax Search' ) ) );
		
		if ( isset( $elements['center']['placebo'] ) ) {
			unset( $elements['center']['placebo'] );
		}
				
		if ($elements['center']): 
			foreach ($elements['center'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_main_right' ) ) {

	/**
	 * Output header main right.
	 */
	function alaha_header_main_right() {
		$elements = alaha_get_option( 'header-main-manager', array ( 'right' => array ( 'myaccount' => 'My Account', 'cart' => 'Cart' ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_navigation_left' ) ) {

	/**
	 * Output header navigation left.
	 */
	function alaha_header_navigation_left() {
		$elements = alaha_get_option( 'header-navigation-manager', array ( 'left' => array ( 'category-menu' => 'Category Menu' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_navigation_center' ) ) {

	/**
	 * Output header navigation center.
	 */
	function alaha_header_navigation_center() {
		$elements = alaha_get_option( 'header-navigation-manager', array ( 'center' => array ( 'primary-menu' => 'Primary Menu' ) ) );
		
		if ( isset( $elements['center']['placebo'] ) ) {
			unset( $elements['center']['placebo'] );
		}
				
		if ($elements['center']): 
			foreach ($elements['center'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_navigation_right' ) ) {

	/**
	 * Output header navigation right.
	 */
	function alaha_header_navigation_right() {
		$elements = alaha_get_option( 'header-navigation-manager', array ( 'right' => array ( ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_sticky_left' ) ) {

	/**
	 * Output header sticky left.
	 */
	function alaha_header_sticky_left() {
		$elements = alaha_get_option( 'header-sticky-manager', array ( 'left' => array ( 'logo' => 'Logo' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_sticky_center' ) ) {

	/**
	 * Output header sticky center.
	 */
	function alaha_header_sticky_center() {
		$elements = alaha_get_option( 'header-sticky-manager', array ( 'center' => array ( 'primary-menu' => 'Primary Menu' ) ) );
		
		if ( isset( $elements['center']['placebo'] ) ) {
			unset( $elements['center']['placebo'] );
		}
				
		if ($elements['center']): 
			foreach ($elements['center'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_sticky_right' ) ) {

	/**
	 * Output header sticky right.
	 */
	function alaha_header_sticky_right() {
		$elements = alaha_get_option( 'header-sticky-manager', array ( 'right' => array ( 'myaccount' => 'My Account','wishlist' => 'Wishlist', 'cart' => 'Cart' ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_left' ) ) {

	/**
	 * Output header mobile left.
	 */
	function alaha_header_mobile_left() {
		$elements = alaha_get_option( 'header-mobile-manager', array ( 'left' => array ( 'mobile-navbar'=> 'Mobile Nav', 'logo' => 'Logo' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_center' ) ) {

	/**
	 * Output header mobile center.
	 */
	function alaha_header_mobile_center() {
		$elements = alaha_get_option( 'header-mobile-manager', array () );
		
		if ( isset( $elements['center']['placebo'] ) ) {
			unset( $elements['center']['placebo'] );
		}
				
		if ($elements['center']): 
			foreach ($elements['center'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_right' ) ) {

	/**
	 * Output header mobile right.
	 */
	function alaha_header_mobile_right() {
		$elements = alaha_get_option( 'header-mobile-manager', array ( 'right' => array ( 'myaccount'=> 'My Account', 'cart' => 'Cart' ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_sticky_left' ) ) {

	/**
	 * Output header mobile sticky left.
	 */
	function alaha_header_mobile_sticky_left() {
		$elements = alaha_get_option( 'header-mobile-sticky-manager', array ( 'left' => array ( 'mobile-navbar' => 'Mobile Nav' ) ) );
		
		if ( isset( $elements['left']['placebo'] ) ) {
			unset( $elements['left']['placebo'] );
		}
				
		if ($elements['left']): 
			foreach ($elements['left'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_sticky_center' ) ) {

	/**
	 * Output header mobile sticky center.
	 */
	function alaha_header_mobile_sticky_center() {
		$elements = alaha_get_option( 'header-mobile-sticky-manager', array ( 'center' => array ( 'ajax-search' => 'Ajax Search' ) ) );
		
		if ( isset( $elements['center']['placebo'] ) ) {
			unset( $elements['center']['placebo'] );
		}
				
		if ($elements['center']): 
			foreach ($elements['center'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_header_mobile_sticky_right' ) ) {

	/**
	 * Output header mobile sticky right.
	 */
	function alaha_header_mobile_sticky_right() {
		$elements = alaha_get_option( 'header-mobile-sticky-manager', array ( 'right' => array ( 'cart' => 'Cart' ) ) );
		
		if ( isset( $elements['right']['placebo'] ) ) {
			unset( $elements['right']['placebo'] );
		}
				
		if ($elements['right']): 
			foreach ($elements['right'] as $element=>$value) {
				alaha_get_template( 'template-parts/header/elements/'.$element );
			}
		endif;
	}
}

if ( ! function_exists( 'alaha_is_open_categories_menu' ) ) :

	/**
	 * Check categories menu is open in home page or not.
	 */
	function alaha_is_open_categories_menu() {
		
		$return_value = false;
		
		if( is_front_page() && alaha_get_option( 'open-categories-menu', 0 ) ){
			$return_value = true;
		}
		
		return apply_filters('alaha_open_categories_menu', $return_value );
	}
endif;


/**
 * Page Title
 */
if ( ! function_exists( 'alaha_page_title' ) ) :

	/**
	 * Stroyka page title.
	 */
	function alaha_page_title() {
		
		// Return if page title disable
		if( (is_front_page() && !is_home())
			|| ( function_exists( 'is_product' ) && is_product() ) 
			|| ( alaha_is_catalog() && !alaha_get_option( 'shop-page-title', 1 )) ) {
			return;
		} 
		
		if( alaha_is_vendor_page() ){
			return;
			
		}
		$prefix 					= ALAHA_PREFIX; // Taking metabox prefix
		$page_title_section 		= alaha_get_post_meta('page_title_section');
		$page_title_style 			= alaha_get_post_meta('page_title_style');
		$title_font_size 			= alaha_get_post_meta('title_font_size');
		$page_heading 				= alaha_get_post_meta('page_heading');
		$breadcrumb 				= alaha_get_post_meta('breadcrumb');
		
		/* Style Param*/
		$title_padding_top 			= alaha_get_post_meta('title_padding_top');
		$title_padding_bottom 		= alaha_get_post_meta('title_padding_bottom');
		$title_bg_color 			= alaha_get_post_meta('title_bg_color');
		$title_color 				= alaha_get_post_meta('title_color'); /* Dark/Light */
		$title_bg_img 				= alaha_get_post_meta('title_bg_img');
		$title_bg_position 			= alaha_get_post_meta('title_bg_position');
		$title_bg_attachment 		= alaha_get_post_meta('title_bg_attachment'); /* Scroll/Fixed */
		$title_bg_repeat 			= alaha_get_post_meta('title_bg_repeat');
		$title_bg_size 				= alaha_get_post_meta('title_bg_size');
		$title_bg_opacity 			= alaha_get_post_meta('title_bg_opacity');
		
		if ( function_exists( 'is_product_category' ) && is_product_category() ) {				
			$queried_object = get_queried_object();
			$term_id        = $queried_object->term_id;				
			$cat_title_bg_img    = get_term_meta( $term_id, $prefix.'alaha_attachment_id', true );
			$cat_ancestors  = get_ancestors( $term_id, 'product_cat' );
			if ( empty( $cat_title_bg_img ) && count( $cat_ancestors ) > 0 ) {
				$parent_id   = $cat_ancestors[0];
				$cat_title_bg_img = get_term_meta( $parent_id, $prefix.'alaha_attachment_id', true );
			}
			if( !empty( $cat_title_bg_img ) ){
				$title_bg_img 	= $cat_title_bg_img;
				$title_color 	= 'light';
			}
		}
			
		if( ! $page_title_section || $page_title_section == 'default' ){
			$page_title_section = alaha_get_option( 'page-title-layout', 'center' );				
		}elseif( $page_title_section == 'enable' ){
			$page_title_section = true;
		}elseif( $page_title_section == 'disable' ){
				$page_title_section = false;
		}
		
		if( is_tax() || is_tag() || is_category() || is_date() || is_author() ){
			if( !alaha_get_option( 'blog-page-title', 1 ) && !alaha_get_option( 'blog-page-breadcrumb', 1 )){
				$page_title_section = false;
			}
			
		}
		
		// Return if disabled page title
		if( ! $page_title_section 
			|| 'disable' == $page_title_section ) {
			return;
		}
		
		if( !$page_title_style || $page_title_style == 'default' ){
			$page_title_style = alaha_get_option( 'page-title-layout', 'center' );				
		}
		if( !$title_font_size || $title_font_size == 'default' ){
			$title_font_size = alaha_get_option( 'page-title-size', 'default' );				
		}
		
		if( !$page_heading || $page_heading == 'default' ){
			$page_heading = alaha_get_option( 'page-title', 1 );				
		}elseif( $page_heading == 'enable' ){
			$page_heading = true;
		}elseif( $page_heading == 'disable' ){
			$page_heading = false;
		}
		
		if( ! $breadcrumb || 'default' == $breadcrumb ){
			$breadcrumb = alaha_get_option( 'page-breadcrumbs', 1 );				
		}elseif( 'enable' == $breadcrumb ){
			$breadcrumb = true;
		}elseif( 'disable' == $breadcrumb ){
			$breadcrumb = false;
		}
		if ( is_home() ) {
			$page_heading = (int)alaha_get_option( 'blog-page-title', 1 );			
			$breadcrumb = alaha_get_option( 'blog-page-breadcrumb', 1 );
		}
		$custom_css = array();
		$custom_style = '';
		if( ! empty( $title_padding_top ) ){
			$custom_css[] = 'padding-top:'.$title_padding_top.'px;';
		}
		if( ! empty( $title_padding_bottom ) ){
			$custom_css[] = 'padding-bottom:'.$title_padding_bottom.'px;';
		}
		
		if( !$title_color || $title_color == 'default' ){
			$title_color = alaha_get_option( 'page-title-color', 'dark' );				
		}
		
		if( ! empty( $title_bg_img ) ){
			$image_src = alaha_get_image_src( $title_bg_img, 'full' );
			$custom_css[] = 'background-image:url('.$image_src.');';
			if( ! empty($title_bg_position) && $title_bg_position != 'default' ){
				$title_bg_position =  str_replace('-',' ',$title_bg_position);
				$custom_css[] = 'background-position:'.$title_bg_position.';';
			}
			if( ! empty($title_bg_attachment) && $title_bg_attachment != 'default' ){
				$custom_css[] = 'background-attachment:'.$title_bg_attachment.';';
			}
			if( ! empty($title_bg_repeat) && $title_bg_repeat != 'default' ){
				$custom_css[] = 'background-repeat:'.$title_bg_repeat.';';
			}
			if( ! empty($title_bg_size) && $title_bg_size != 'default' ){
				$custom_css[] = 'background-size:'.$title_bg_size.';';
			}
		}
		if( ! empty( $custom_css ) ){
			$custom_style .= '.page-title-wrapper {';
			$custom_style .= implode(' ',$custom_css);
			$custom_style .= '}';
		}
		if( ! empty( $title_bg_color ) ){
			$custom_css[] = 'background-color:'.$title_bg_color.';';
		}
		
		if( $page_heading || $breadcrumb  ) {
			$args 				= array();
			$class[]			= 'text-'.$page_title_style;
			$class[]			= 'title-size-'.$title_font_size;
			$class[]			= 'color-scheme-'.$title_color;
			$args['class']	 	= implode( ' ', array_filter( $class ) );
			$args['custom_css'] = '';
			$args['custom_css']	= implode( ' ', array_filter( $custom_css ) );
			alaha_get_template( 'template-parts/page-title/page-title', $args );
		}
	}
endif;

if ( ! function_exists( 'alaha_template_page_title' ) ) :

	/**
	 * Stroyka template title.
	 */
	function alaha_template_page_title() {
		$page_heading 				= alaha_get_post_meta('page_heading');
		
		if(!$page_heading || $page_heading == 'default'){
			$page_heading = alaha_get_option( 'page-title', 1 );				
		}elseif($page_heading == 'enable'){
			$page_heading = 1;
		}elseif($page_heading == 'disable'){
				$page_heading = 0;
		}
		
		if( ! $page_heading ) return;

		alaha_get_template( 'template-parts/page-title/title');
	}
endif;

if ( ! function_exists( 'alaha_template_breadcrumbs' ) ) :
	/**
	 * Stroyka template page breadcrumbs.
	 */
	function alaha_template_breadcrumbs( $args = array() ) {
		
		$breadcrumb	= alaha_get_post_meta('breadcrumb');
		
		if(!$breadcrumb || $breadcrumb == 'default'){
			$breadcrumb = alaha_get_option( 'page-breadcrumbs', 1 );				
		}elseif($breadcrumb == 'enable'){
			$breadcrumb = 1;
		}elseif($breadcrumb == 'disable'){
				$breadcrumb = 0;
		}
		if(alaha_is_portfolio()){
			$breadcrumb = alaha_get_option( 'portfolio-page-breadcrumb', 1 );
		}
		if( is_tax() || is_tag() || is_category() || is_date() || is_author() ){
			$breadcrumb = alaha_get_option( 'blog-page-breadcrumb', 1 );
		}
		if ( is_home()) {
			$breadcrumb = alaha_get_option( 'blog-page-breadcrumb', 1 );
		}
		if( ! $breadcrumb ) return;

		$delimiter = alaha_get_option( 'breadcrumbs-delimiter', 'forward-slash' );
		// use yoast breadcrumbs if enabled
		if ( function_exists( 'yoast_breadcrumb' ) ) {
			$yoast_breadcrumbs = yoast_breadcrumb( '', '', false );
			if ( $yoast_breadcrumbs ) {
				return $yoast_breadcrumbs;
			}
		}
		
		$args = wp_parse_args( $args, apply_filters( 'alaha_breadcrumb_defaults', array(
			'wrap_before' 		=> '<nav class="alaha-breadcrumb">',
			'wrap_after'  		=> '</nav>',
			'delimiter_before'	=> '<span class="delimiter-sep '.$delimiter.'">',
			'delimiter_after'	=> '</span>',
			'delimiter'   		=> '',
			'before'      		=> '',
			'after'       		=> '',
		) ) );
		$breadcrumbs = new Stroyka_Breadcrumb();
		 

		$args['breadcrumb'] = $breadcrumbs->generate();

		/**
		 * WooCommerce Breadcrumb hook
		 *
		 * @hooked WC_Structured_Data::generate_breadcrumblist_data() - 10
		 */
		do_action( 'alaha_breadcrumb', $breadcrumbs, $args );

		alaha_get_template( 'template-parts/page-title/breadcrumbs',$args );
	}
endif;

/**
 * Footer
 */
if ( ! function_exists( 'alaha_template_footer' ) ) :

	/**
	 * Stroyka template footer.
	 */
	function alaha_template_footer() {	
		
		$footer_layout 					= alaha_get_option( 'footer-layout', '2' );
		$footer_layout_data 			= alaha_get_footer_layout($footer_layout);
		$site_footer 					= alaha_get_post_meta('site_footer');
		$footer_copyright 				= alaha_get_post_meta('footer_copyright');
		
		if( !$site_footer || $site_footer == 'default' ){
			$site_footer = alaha_get_option( 'site-footer', 1 );				
		}elseif( $site_footer == 'enable' ){
			$site_footer = 1;
		}elseif( $site_footer == 'disable' ){
				$site_footer = 0;
		}
		if( !$footer_copyright || $footer_copyright == 'default' ){
			$footer_copyright = alaha_get_option( 'footer-copyright', 1 );				
		}elseif( $footer_copyright == 'enable' ){
			$footer_copyright = 1;
		}elseif( $footer_copyright == 'disable' ){
				$footer_copyright = 0;
		}
		if(!alaha_footer_widget_active()){
			$site_footer = 0;
		}
		$args['site_footer'] 	= $site_footer;
		$args['footer_copyright'] 	= $footer_copyright;
		$args['footer_layout_data'] 	= $footer_layout_data;
		
		alaha_get_template( 'template-parts/footer/footer', $args );		
	}
endif;
if ( ! function_exists( 'alaha_footer_widget_active' ) ) :
	/**
	 * Check is footer widget active
	 */
	function alaha_footer_widget_active() {
		if ( is_active_sidebar( 'footer-area-1' ) 
			|| is_active_sidebar( 'footer-area-2' ) 
			|| is_active_sidebar( 'footer-area-3' ) 
			|| is_active_sidebar( 'footer-area-4' ) 
			|| is_active_sidebar( 'footer-area-5' ) ){
			return true;
		}
		return false;
	}
endif;
if ( ! function_exists( 'alaha_back_to_top' ) ) :

	/**
	 * Back to top button.
	 */
	function alaha_back_to_top() {
		if( ! alaha_get_option( 'back-to-top', 1 ) 
			|| ( wp_is_mobile() 
			&& ! alaha_get_option( 'back-to-top-mobile', 1 ) ) ) {
				return; 
		}?>
		
		<div class="back-to-top">
			<?php esc_html_e('Scroll To Top', 'alaha');?>
		</div>
		<?php
	}
endif;

if ( ! function_exists( 'alaha_close_popup' ) ) :

	/**
	 * Close sidebar popup.
	 */
	function alaha_close_popup() {?>
	
		<div class="alaha-mask-overaly"></div>
		
	<?php }
endif;

/**
 * Sidebar
 */
if ( ! function_exists( 'alaha_get_sidebar' ) ) :

	/**
	 * Get the alaha sidebar.
	 */
	function alaha_get_sidebar() {
		get_sidebar();
	}
endif;

/**
 * Page
 */
if ( ! function_exists( 'alaha_template_page_content' ) ) :

	/**
	 * Stroyka template page content.
	 */
	function alaha_template_page_content() {
		get_template_part( 'template-parts/page/content');
	}
endif;

if ( ! function_exists( 'alaha_template_page_comments' ) ) :

	/**
	 * Stroyka template page comments.
	 */
	function alaha_template_page_comments() {
		get_template_part( 'template-parts/page/comments');
	}
endif;

/**
 * Post Loop
 */
if ( ! function_exists( 'alaha_post_loop_start' ) ) :

	/**
	 * Post loop start.
	 */
	function alaha_post_loop_start( $echo = true ) {
				
		ob_start();
		
		alaha_get_template( 'template-parts/post-loop/loop-start.php' );

		if ( $echo ) {
			echo apply_filters( 'alaha_post_loop_start', ob_get_clean() ); // WPCS: XSS ok.
		} else {
			return apply_filters( 'alaha_post_loop_start', ob_get_clean() );
		}		
	}
endif;

if ( ! function_exists( 'alaha_post_loop_end' ) ) :

	/**
	 * Post loop end.
	 */
	function alaha_post_loop_end( $echo = true ) {
		
		ob_start();

		alaha_get_template( 'template-parts/post-loop/loop-end.php' );

		if ( $echo ) {
			echo apply_filters( 'alaha_post_loop_end', ob_get_clean() ); // WPCS: XSS ok.
		} else {
			return apply_filters( 'alaha_post_loop_end', ob_get_clean() );
		}
	}
endif;

if ( ! function_exists( 'alaha_post_wrapper' ) ) {

	/**
	 * Post wrapper.
	 */
	function alaha_post_wrapper() {
		$output='<div class="entry-post">';
		echo apply_filters('alaha_post_wrapper',$output);
	}
}

if ( ! function_exists( 'alaha_post_wrapper_end' ) ) {

	/**
	 * Post wrapper end.
	 */
	function alaha_post_wrapper_end() {
		$output='</div>';
		echo apply_filters('alaha_post_wrapper_end',$output);
	}
}

if ( ! function_exists( 'alaha_template_loop_post_fancy_date' ) ) {

	/**
	 * Loop post fancy date.
	 */
	function alaha_template_loop_post_fancy_date() {
		get_template_part( 'template-parts/post-loop/fancy-date' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_highlight' ) ) {

	/**
	 * Loop post highlight format, sticky.
	 */
	function alaha_template_loop_post_highlight() {
		get_template_part( 'template-parts/post-loop/highlight' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_thumbnail' ) ) {

	/**
	 * Loop post thumbnail.
	 */
	function alaha_template_loop_post_thumbnail() {
		get_template_part( 'template-parts/post-loop/thumbnail' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_header' ) ) {

	/**
	 * Loop post header.
	 */
	function alaha_template_loop_post_header() {
		get_template_part( 'template-parts/post-loop/header' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_title' ) ) {

	/**
	 * Loop post header title.
	 */
	function alaha_template_loop_post_title() {
		get_template_part( 'template-parts/post-loop/title' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_meta' ) ) {

	/**
	 * Loop post header meta.
	 */
	function alaha_template_loop_post_meta() {
		get_template_part( 'template-parts/post-loop/meta' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_content' ) ) {

	/**
	 * Loop post content.
	 */
	function alaha_template_loop_post_content() {
		get_template_part( 'template-parts/post-loop/content' );		
	}
}

if ( ! function_exists( 'alaha_template_loop_post_footer' ) ) {

	/**
	 * Loop post footer.
	 */
	function alaha_template_loop_post_footer() {
		get_template_part( 'template-parts/post-loop/footer' );		
	}
}

if ( ! function_exists( 'alaha_template_read_more_link' ) ) {

	/**
	 * Loop post readmore link.
	 */
	function alaha_template_read_more_link() {
		get_template_part( 'template-parts/post-loop/readmore' );		
	}
}

if ( ! function_exists( 'alaha_pagination' ) ) {

	/**
	 * Output the pagination.
	 */
	function alaha_pagination() {
		get_template_part( 'template-parts/global/pagination' );
	}
}

/**
 * Single Post
 */
if ( ! function_exists( 'alaha_template_single_post_fancy_date' ) ) {

	/**
	 * Single post fancy date.
	 */
	function alaha_template_single_post_fancy_date() {
		get_template_part( 'template-parts/single-post/fancy-date' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_highlight' ) ) {

	/**
	 * Single post highlight format, sticky.
	 */
	function alaha_template_single_post_highlight() {
		get_template_part( 'template-parts/single-post/highlight' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_thumbnail' ) ) {

	/**
	 * Single post thumbnail.
	 */
	function alaha_template_single_post_thumbnail() {
		get_template_part( 'template-parts/single-post/thumbnail/thumbnail', get_post_format() );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_header' ) ) {

	/**
	 * Single post header.
	 */
	function alaha_template_single_post_header() {
		get_template_part( 'template-parts/single-post/header' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_title' ) ) {

	/**
	 * Single post header title.
	 */
	function alaha_template_single_post_title() {
		get_template_part( 'template-parts/single-post/title' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_meta' ) ) {

	/**
	 * Single post header meta.
	 */
	function alaha_template_single_post_meta() {
		get_template_part( 'template-parts/single-post/meta' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_content' ) ) {

	/**
	 * Single post content.
	 */
	function alaha_template_single_post_content() {
		get_template_part( 'template-parts/single-post/content' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_footer' ) ) {

	/**
	 * Single post footer.
	 */
	function alaha_template_single_post_footer() {
		get_template_part( 'template-parts/single-post/footer' );		
	}
}

if ( ! function_exists( 'alaha_template_single_tag_social_share' ) ) {

	/**
	 * Single post Tags & Social share.
	 */
	function alaha_template_single_tag_social_share() {
		
		$args = array();
		$args['is_tag_enable'] 		= alaha_get_option( 'single-post-tag', 1 );
		$args['is_share_enable'] 	= alaha_get_option( 'single-post-social-share-link', 1 );
		$args['social_icons_style'] = alaha_get_option( 'social-sharing-icons-style','icons-bordered' );
		$args['social_icons_shape'] = alaha_get_option( 'sharing-icons-shape','icons-shape-circle' );
		$args['social_icons_size']  = alaha_get_option( 'sharing-icons-size','icons-size-default' );
		
		alaha_get_template( 'template-parts/single-post/tags-social-share', $args );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_author_bios' ) ) {

	/**
	 * Single post author bios.
	 */
	function alaha_template_single_post_author_bios() {
		get_template_part( 'template-parts/single-post/author-bios' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_navigation' ) ) {

	/**
	 * Single post navigation.
	 */
	function alaha_template_single_post_navigation() {
		get_template_part( 'template-parts/single-post/navigation' );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_related' ) ) {

	/**
	 * Single related posts.
	 */
	function alaha_template_single_post_related( $args = array() ) {
		
		if ( ! alaha_get_option('single-post-related', 1) ) return;
		
		$post_id = get_the_id();
		$taxonomy = alaha_get_option('related-posts-taxonomy', 'post_tag');
		
		$defaults = array (
			'post_type'     	 	=> 'post',
			'post_status' 			=> array( 'publish' ),
			'ignore_sticky_posts'	=> true,
			'post__not_in' 			=> array($post_id),
			'showposts' 			=> alaha_get_option('show-related-posts', 6),
			'orderby' 				=> alaha_get_option('related-posts-orderby', 'rand'),
			'order' 				=> alaha_get_option('related-posts-order', 'DESC'),
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$taxs = get_the_terms($post_id, $taxonomy);
		
		if ( $taxs ) {
			$tax_ids = array();
			foreach( $taxs as $tag ) $tax_ids[] = $tag->term_id;			
		}

		if( !empty($tax_ids) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => $taxonomy,
					'field' => 'id',
					'terms' => $tax_ids
				)
			);
		}
		
		$query 	= new WP_Query( apply_filters( 'alaha_related_posts_args', $args ) );
		
		$args['related_posts'] = $query;
		
		$unique_id = alaha_uniqid('section-');		
		global $alaha_owlparam;
		$slider_data = shortcode_atts( alaha_slider_options() ,array(
				'slider_margin'		=> 30,			
				'rs_extra_large'	=> 2,			
				'rs_large'     		=> 2,			
				'rs_medium'     	=> 2,
				'rs_small'     		=> 2,			
				'rs_extra_small'	=> 1,			
			));
		$alaha_owlparam['owlCarouselArg'][$unique_id] = $slider_data;
		
		$args['unique_id'] = $unique_id;

		// Set global loop values.
		alaha_set_loop_prop( 'name', 'related-posts' );
		alaha_set_loop_prop( 'blog-custom-thumbnail-size','medium');
		alaha_set_loop_prop( 'specific-post-meta', array( 'post-author', 'post-comments', 'post-share' ) );
		alaha_get_template( 'template-parts/single-post/related.php', $args );		
	}
}

if ( ! function_exists( 'alaha_template_single_post_comments' ) ) {

	/**
	 * Single post comments.
	 */
	function alaha_template_single_post_comments() {
		get_template_part( 'template-parts/single-post/comments' );		
	}
}

/**
 * Portfolio Loop
 */
if ( ! function_exists( 'alaha_portfolio_loop_start' ) ) :

	/**
	 * Portfolio loop start.
	 */
	function alaha_portfolio_loop_start( $echo = true ) {
		ob_start();

		alaha_get_template( 'template-parts/portfolio-loop/loop-start.php' );

		if ( $echo ) {
			echo apply_filters( 'alaha_portfolio_post_loop_start', ob_get_clean() ); // WPCS: XSS ok.
		} else {
			return apply_filters( 'alaha_portfolio_post_loop_start', ob_get_clean() );
		}		
	}
endif;

if ( ! function_exists( 'alaha_portfolio_loop_end' ) ) :
	/**
	 * Portfolio loop end.
	 */
	function alaha_portfolio_loop_end( $echo = true ) {
		
		ob_start();

		alaha_get_template( 'template-parts/portfolio-loop/loop-end.php' );

		if ( $echo ) {
			echo apply_filters( 'alaha_portfolio_post_loop_end', ob_get_clean() ); // WPCS: XSS ok.
		} else {
			return apply_filters( 'alaha_portfolio_post_loop_end', ob_get_clean() );
		}
	}
endif;

if ( ! function_exists( 'alaha_template_portfolio_filter' ) ) {
	/**
	 * Portfolio filter.
	 */
	function alaha_template_portfolio_filter() {
		get_template_part( 'template-parts/portfolio-loop/filter' );		
	}
}

if ( ! function_exists( 'alaha_template_portfolio_loop_thumbnail' ) ) {
	/**
	 * Portfolio loop thumbnail.
	 */
	function alaha_template_portfolio_loop_thumbnail() {
		get_template_part( 'template-parts/portfolio-loop/thumbnail' );		
	}
}

if ( ! function_exists( 'alaha_template_portfolio_loop_action_icon' ) ) {
	/**
	 * Portfolio loop action icon.
	 */
	function alaha_template_portfolio_loop_action_icon() {
		get_template_part( 'template-parts/portfolio-loop/action-icon' );		
	}
}

if ( ! function_exists( 'alaha_template_portfolio_loop_header' ) ) {
	/**
	 * Portfolio loop header.
	 */
	function alaha_template_portfolio_loop_header() {
		get_template_part( 'template-parts/portfolio-loop/header' );		
	}
}

if ( ! function_exists( 'alaha_template_portfolio_loop_categories' ) ) {
	/**
	 * Portfolio loop header category.
	 */
	function alaha_template_portfolio_loop_categories() {
		get_template_part( 'template-parts/portfolio-loop/category' );		
	}
}

if ( ! function_exists( 'alaha_template_portfolio_loop_title' ) ) {
	/**
	 * Portfolio loop header title.
	 */
	function alaha_template_portfolio_loop_title() {
		get_template_part( 'template-parts/portfolio-loop/title' );		
	}
}

if ( ! function_exists( 'alaha_portfolio_pagination' ) ) {
	/**
	 * Output the pagination.
	 */
	function alaha_portfolio_pagination() {
		get_template_part( 'template-parts/global/pagination' );
	}
}

/**
 * Single Portfolio
 */

if ( ! function_exists( 'alaha_template_single_portfolio_image' ) ) {
	/**
	 * Output the portfolio image/gallery.
	 */
	function alaha_template_single_portfolio_image() {
		$show_portfolio_gallery 	= alaha_get_post_meta('show_portfolio_gallery');
		$portfolio_gallery_style 	= alaha_get_post_meta('portfolio_gallery_style');
		$attachment_ids 	= get_post_meta( get_the_ID(), ALAHA_PREFIX.'gallery_images' );
		$is_gallery_style = 1;
		
		if(!$show_portfolio_gallery || $show_portfolio_gallery == 'default'){
			$is_gallery_style = alaha_get_option('single-portfolio-gallery', 1);				
		}elseif($show_portfolio_gallery == 'gallery'){
			$is_gallery_style = 1;
		}elseif($show_portfolio_gallery == 'thumbnail'){
			$is_gallery_style = 0;
		}
		if($is_gallery_style){
			if(!$portfolio_gallery_style || $portfolio_gallery_style == 'default'){
				$portfolio_gallery_style = alaha_get_option('single-portfolio-gallery-style', 'slider');				
			}
		}
		$thumbnail_size		= apply_filters( 'alaha_single_portfolio_image_size', ( alaha_get_option('single-portfolio-layout', '8' ) == '12' ? 'full' : 'large' ) );
		$post_thumbnail_id 	= get_post_thumbnail_id( get_the_ID() );
		
		$carousel_classes 	= array();
		if( ! empty ( $attachment_ids ) && $is_gallery_style){
			$carousel_classes	= ( ! empty ($attachment_ids ) && $portfolio_gallery_style == 'slider' ? array('alaha-gallery-carousel', 'owl-carousel') : array( 'row', 'gallery-grid' ) );
		}
		$wrapper_classes	= apply_filters( 'alaha_single_portfolio_image_classes', array_merge( array(
			'alaha-portfolio-image',
			( has_post_thumbnail() ? 'with-images' : 'without-images' ),
		), $carousel_classes) );
		$args['thumbnail_size'] 	=  $thumbnail_size;
		$args['is_gallery_style'] 	=  $is_gallery_style;
		$args['gallery_style'] 		=  $portfolio_gallery_style;
		$args['post_thumbnail_id'] 	=  $post_thumbnail_id;
		$args['attachment_ids'] 	=  $attachment_ids;
		$args['wrapper_classes'] 	=  $wrapper_classes;
		
		alaha_get_template( 'template-parts/single-portfolio/portfolio-image',$args );
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_title' ) ) {
	/**
	 * Output the portfolio title.
	 */
	function alaha_template_single_portfolio_title() {
		
		alaha_get_template( 'template-parts/single-portfolio/title' );
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_content' ) ) {
	/**
	 * Output the portfolio content.
	 */
	function alaha_template_single_portfolio_content() {
		
		alaha_get_template( 'template-parts/single-portfolio/content' );
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_preview' ) ) {
	/**
	 * Output the portfolio preview.
	 */
	function alaha_template_single_portfolio_preview() {
		
		$args['website_url']	= get_post_meta( get_the_ID(), ALAHA_PREFIX.'website_url', true );
		
		alaha_get_template( 'template-parts/single-portfolio/preview', $args );
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_client' ) ) {
	/**
	 * Output the portfolio client.
	 */
	function alaha_template_single_portfolio_client() {		
		
		$args['client']	= get_post_meta( get_the_ID(), ALAHA_PREFIX.'client_name', true );
		
		alaha_get_template( 'template-parts/single-portfolio/client', $args);
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_date' ) ) {
	/**
	 * Output the portfolio date.
	 */
	function alaha_template_single_portfolio_date() {
				
		alaha_get_template( 'template-parts/single-portfolio/date');
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_category' ) ) {
	/**
	 * Output the portfolio categories.
	 */
	function alaha_template_single_portfolio_category() {
				
		alaha_get_template( 'template-parts/single-portfolio/category');
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_skill' ) ) {
	/**
	 * Output the portfolio skill.
	 */
	function alaha_template_single_portfolio_skill() {
				
		alaha_get_template( 'template-parts/single-portfolio/skill');
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_share' ) ) {
	/**
	 * Output the portfolio share.
	 */
	function alaha_template_single_portfolio_share() {
		
		if ( ! alaha_get_option('single-portfolio-share', 1) ) return;
		
		$args = array();
		$args['social_icons_style'] = alaha_get_option( 'social-sharing-icons-style','icons-bordered' );
		$args['social_icons_shape'] = alaha_get_option( 'sharing-icons-shape','icons-shape-circle' );
		$args['social_icons_size']  = alaha_get_option( 'sharing-icons-size','icons-size-default' );		
				
		alaha_get_template( 'template-parts/single-portfolio/share', $args );
	}
}

/**
 * Get HTML for a gallery image.
 *
 * @return string
 */
function alaha_get_gallery_image_html( $attachment_id, $thumbnail_size, $gallery_style='' ) {	
	$grid_classes	='';
	if( $gallery_style == 'grid' ){
		$grid_classes = 'col-12 col-sm-6';
	}elseif( $gallery_style == 'one-column' ){
		$grid_classes = 'col-12 col-sm-12';
	}
	
	$grid_classes	= apply_filters( 'alaha_post_gallery_grid_classes', $grid_classes );
	$full_size		= apply_filters( 'alaha_post_gallery_full_size', 'full' );
	$full_src       = wp_get_attachment_image_src( $attachment_id, $full_size );
	$image     		= wp_get_attachment_image( $attachment_id, $thumbnail_size );
	
	return '<div class="alaha-post-gallery__image '.$grid_classes.'"><a href="' . esc_url( $full_src[0] ) . '">' . $image . '</a></div>';
}
 
if ( ! function_exists( 'alaha_template_single_portfolio_navigation' ) ) {
	/**
	 * Output the navigation.
	 */
	function alaha_template_single_portfolio_navigation() {
		get_template_part( 'template-parts/single-portfolio/navigation' );
	}
}

if ( ! function_exists( 'alaha_template_single_related_portfolio' ) ) {
	/**
	 * Output related the portfolio.
	 */
	function alaha_template_single_related_portfolio( $args =array() ) {
		
		if ( ! alaha_get_option( 'single-portfolio-related', 1 ) ) return;
		
		$post_id = get_the_id();
		$taxonomy = alaha_get_option('related-portfolios-taxonomy', 'post_tag');
		
		$defaults = array (
			'post_type'     	 	=> 'portfolio',
			'post_status' 			=> array( 'publish' ),
			'ignore_sticky_posts'	=> true,
			'post__not_in' 			=> array($post_id),
			'showposts' 			=> alaha_get_option('show-related-portfolios', 6),
			'orderby' 				=> alaha_get_option('related-portfolios-orderby', 'rand'),
			'order' 				=> alaha_get_option('related-portfolios-order', 'DESC'),
		);
		
		$args = wp_parse_args( $args, $defaults );
		
		$taxs = get_the_terms($post_id, $taxonomy);
		
		if ( $taxs ) {
			$tax_ids = array();
			foreach( $taxs as $tag ) $tax_ids[] = $tag->term_id;			
		}

		if( !empty($tax_ids) ){
			$args['tax_query'] = array(
				array(
					'taxonomy' => $taxonomy,
					'field' => 'id',
					'terms' => $tax_ids
				)
			);
		}
		
		$query 	= new WP_Query( apply_filters( 'alaha_related_portfolios_args', $args ) );
		
		$args['related_portfolios'] = $query;
		
		$unique_id = alaha_uniqid('section-');		
		global $alaha_owlparam;
		$slider_data = shortcode_atts(alaha_slider_options(),array(
				'slider_margin'		=> 30,		
				'rs_extra_large'	=> 3,			
				'rs_large'     		=> 3,			
				'rs_medium'     	=> 2,
				'rs_small'     		=> 2,			
				'rs_extra_small'	=> 1,		
			));
		$alaha_owlparam['owlCarouselArg'][$unique_id] = $slider_data;
		$args['unique_id'] = $unique_id;

		// Set global loop values.
		alaha_set_loop_prop( 'name', 'related-portfolios' );
		if(alaha_get_option('related-portfolios-display', 'slider') =='grid'){
			alaha_set_loop_prop( 'portfolio-grid-layout','simple-grid');
			alaha_set_loop_prop( 'portfolio-grid-columns',3);
		}
		alaha_get_template( 'template-parts/single-portfolio/related.php', $args );
	}
}

if ( ! function_exists( 'alaha_template_single_portfolio_comments' ) ) {
	/**
	 * Output portfolio the comments.
	 */
	function alaha_template_single_portfolio_comments() {
		get_template_part( 'template-parts/single-portfolio/comments' );
	}
}

if ( ! function_exists( 'alaha_newsletter_popup' ) ) {	
	/**
	 * Newsletter Popup.
	 */
	function alaha_newsletter_popup(){
		
		if( ! alaha_get_option( 'newsletter-popup', 0 ) ) return;		
		$color 				= 'color-scheme-'.alaha_get_option('newsletter-color','light');
		$content 			= alaha_get_option('newsletter-tag-line', 'Signup today for free and be the first to hear of special </br> promotions, new arrivals and designer news.');
		?>
		<div class="alaha-newsletter-popup mfp-hide <?php echo esc_attr($color);?>">		
			<div class="alaha-newsletter-inner">				
				<div class="newsletter-text">
					<h1><?php echo esc_html( alaha_get_option('newsletter-title', 'Sign Up & Get 40% Off') );?></h1>
					<p class="tag-line"><?php echo wp_kses_post( $content );?></p>
				</div>
				<div class="newsletter-form">
					<?php if( function_exists( 'mc4wp_show_form' ) ) {
						mc4wp_show_form();
					}?>
					<div class="checkbox-group form-group-top clearfix">
					  <input type="checkbox" id="newsletter-donotshow" value="do-not-show">
					  <label for="newsletter-donotshow"> 
						<span class="check"></span>
						<span class="box"></span>
						<?php echo esc_html( alaha_get_option('newsletter-dont-show', 'Don\'t show this popup again') );?>
					  </label>
					</div>
				</div>
			</div>  	  
		</div>
		<?php
	}
}

if ( ! function_exists( 'alaha_coming_soon_redirect' ) ) {	
	/**
	 *  Comming Soon
	 */
	function alaha_coming_soon_redirect(){
		
		$is_maintenance 	= alaha_get_option('maintenance-mode',0);
		$maintenance_page 	= alaha_get_option('maintenance-page',0);
		
        // Dont't show coming soon page if not coming soon mode on or  is user logged in.
        if ( is_user_logged_in() || !$is_maintenance) {
            return;
        }
		if (!is_page( $maintenance_page ) && $is_maintenance && $maintenance_page && !current_user_can('edit_posts') && !in_array( $GLOBALS['pagenow'], array( 'wp-login.php', 'wp-register.php' ))){
            wp_redirect( esc_url( home_url( 'index.php?page_id='.$maintenance_page) ) );
            exit();
        }
	}
}