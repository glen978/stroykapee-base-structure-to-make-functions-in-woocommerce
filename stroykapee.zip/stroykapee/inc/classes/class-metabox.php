<?php  
if ( ! defined('ALAHA_DIR')) exit('No direct script access allowed');
/**
 * Stroyka Loop
 * @author 		stroykas
 * @package 	alaha/inc
 * @version     1.0
 */
 
if ( ! class_exists( 'Stroyka_Metabox' ) ) :

	/**
	 * Stroyka_Metabox
	 *
	 * @since 1.0
	 */
	class Stroyka_Metabox {
		
		/**
		 * Instance
		 *
		 * @access private
		 * @var object Class object.
		 */
		private static $instance;
		
		private $prefix = ALAHA_PREFIX;
		
		public $post_types;
		
		/**
		 * Initiator
		 *
		 * @return object initialized object of class.
		 */
		public static function get_instance() {
			if ( ! isset( self::$instance ) ) {
				self::$instance = new self;
			}
			return self::$instance;
		}
		
		/**
		 * Constructor
		 */
		public function __construct() {
			$this->post_types = array('post','page','portfolio','product');	
			add_action('admin_init',array($this,'register_metaboxes'));
			add_action('admin_enqueue_scripts',array($this,'alaha_admin_js_var'));
		}
		
		
		public function alaha_meta_boxes(){
			$prefix 	= ALAHA_PREFIX;
			$meta_box 	= array();
			$size_guide = alaha_get_posts_by_post_type('kp_size_chart',esc_html__('Select Size Chart','alaha'));
			// POST FORMAT
			//--------------------------------------------------
			$meta_boxes[] = array(
				'title' 		=> esc_html__('Post Format', 'alaha'),
				'id' 			=> $prefix .'meta_box_post_format',
				'post_types' 	=> array('post'),
				'tab'   		=> true,
				'fields' 		=> array(
					array(
						'name' 				=> esc_html__('Images', 'alaha'),
						'label_description' => esc_html__( 'Upload images.This setting is used for your gallery post formats.', 'alaha' ),
						'id' 				=> $prefix . 'post_format_gallery',
						'type' 				=> 'image_advanced',
					),
					array(
						'name' 				=> esc_html__( 'Video URL or Embeded Code', 'alaha' ),
						'label_description' => esc_html__( 'Enter the URL or embed code of Vimeo.com or YouTube.com streaming services.<br>To get the code, go to the external video page, click "share" button and copy the Embed code.This setting is used for your video post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_video',
						'type' 				=> 'textarea',
					),
					array(
						'name' 				=> esc_html__( 'Audio URL or Embeded Code', 'alaha' ),
						'label_description' => esc_html__( 'Enter the URL or Embeded code of the audio.This setting is used for your audio post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_audio',
						'type' 				=> 'textarea',
					),
					array(
						'name' 				=> esc_html__( 'Quote', 'alaha' ),
						'label_description' => esc_html__( 'Enter your quote.This setting is used for your quote post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_quote',
						'type' 				=> 'textarea',
					),
					array(
						'name' 				=> esc_html__( 'Author', 'alaha' ),
						'label_description' => esc_html__( 'Enter quote author.This setting is used for your quote post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_quote_author',
						'type' 				=> 'text',
					),
					array(
						'name' 				=> esc_html__( 'Author URL', 'alaha' ),
						'label_description' => esc_html__( 'Enter quote author url.This setting is used for your quote post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_quote_author_url',
						'type' 				=> 'url',
					),
					array(
						'name' 				=> esc_html__( 'Link', 'alaha' ),
						'label_description' => esc_html__( 'Enter your external url.This setting is used for your link post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_link_url',
						'type' 				=> 'url',
					),					
					array(
						'name' 				=> esc_html__( 'Text', 'alaha' ),
						'label_description' => esc_html__( 'Enter link text for link.This setting is used for your link post formats.', 'alaha' ),
						'id'   				=> $prefix . 'post_format_link_text',
						'type' 				=> 'text',
					),
				),
			);
			if( defined( 'ALAHA_EXTENSIONS_PORTFOLIO_POST_TYPE' ) ) {
				$meta_boxes[] 	= array( 
					'id'			=> $prefix.'portfolio_gallery',
					'title'			=> esc_html__( 'Portfolio', 'alaha' ),
					'post_types' 	=> ALAHA_EXTENSIONS_PORTFOLIO_POST_TYPE,
					'tab'   		=> true,
					'fields'     	=> array(
						array(
							'name'  			=> esc_html__( 'Portfolio Layout', 'alaha' ),
							'label_description' => esc_html__( 'Select portfolio layout', 'alaha' ),
							'id'    			=> "{$prefix}portfolio_style",
							'type'  		=> 'image_set',
							'allowClear' 	=> false,
							'options' 		=> array(
								'default'	=> ALAHA_ADMIN_IMAGES . 'layout/default.png',
								'4'	  		=> ALAHA_ADMIN_IMAGES . 'layout/portfolio/4_8-layout.png',
								'6'	  		=> ALAHA_ADMIN_IMAGES . 'layout/portfolio/6_6-layout.png',
								'8'	  		=> ALAHA_ADMIN_IMAGES . 'layout/portfolio/8_4-layout.png',
								'12'		=> ALAHA_ADMIN_IMAGES . 'layout/portfolio/12_12-layout.png',
							),
							'std'			=> 'default',
							'multiple' 		=> false,							
						),
						array(
							'name'  			=> esc_html__( 'Client Name', 'alaha' ),
							'label_description' => esc_html__( 'Enter client name.', 'alaha' ),
							'id'    			=> "{$prefix}client_name",
							'type'  			=> 'text',
						),
						array(
							'name'  			=> esc_html__( 'Website', 'alaha' ),
							'label_description' => esc_html__( 'Website link.', 'alaha' ),
							'id'    			=> "{$prefix}website_url",
							'type'  			=> 'text',
						),
						array(
							'id'               	=> "{$prefix}gallery_images",
							'name'             	=> esc_html__( 'Portfolio Images Upload', 'alaha' ),
							'label_description'	=> esc_html__( 'Upload portfolio images.', 'alaha' ),
							'type'             	=> 'image_advanced',
							'force_delete'     	=> false,
						),
						array(
							'name'  			=> esc_html__( 'Thumbnail/Gallery', 'alaha' ),
							'label_description' => esc_html__( 'Show gallery Or thumbnail.', 'alaha' ),
							'id'    			=> $prefix.'show_portfolio_gallery',
							'type'     			=> 'button_group',
							'options'  			=> array(
								'default'	=> esc_html__( 'Default', 'alaha' ),
								'gallery'	=> esc_html__( 'Gallery', 'alaha' ),
								'thumbnail'	=> esc_html__( 'Thumbnail', 'alaha' ),
							),
							'inline'   			=> 	true,
							'multiple' 			=> 	false,
							'std'				=>	'default',							
						),
						array(
							'name'  			=> esc_html__( 'Gallery Style', 'alaha' ),
							'label_description' => esc_html__( 'Select portfolio gallery style.', 'alaha' ),
							'id'    			=> $prefix.'portfolio_gallery_style',
							'type'     			=> 'button_group',
							'options'  			=> array(
								'default'		=> esc_html__( 'Default', 'alaha' ),
								'slider'     	=> esc_html__( 'Slider', 'alaha' ),
								'grid'     		=> esc_html__( 'Grid', 'alaha' ),
								'one-column'    => esc_html__( 'One Column', 'alaha' ),
							),
							'inline'   			=> 	true,
							'multiple' 			=> 	false,
							'std'				=>	'default',							
						),
						
					),
				);
			}
			$meta_boxes[] = array(
				'id' 			=> $prefix . 'product_setting_meta_box',
				'title' 		=> esc_html__('Product setting', 'alaha'),
				'post_types' 	=> array('product'),
				'tab' => true,
				'fields' => array(
					array(
						'name'  			=> esc_html__( 'Product Page Layout', 'alaha' ),
						'label_description'	=> esc_html__( 'Select product page  layout.', 'alaha' ),
						'id'    			=> $prefix.'single_product_layout',
						'type'  			=> 'image_set',
						'allowClear' 		=> true,
						'options' 			=> array(
							'product-gallery-left'	  	=> ALAHA_ADMIN_IMAGES . 'layout/product-gallery-left.png',
							'product-gallery-bottom'	=> ALAHA_ADMIN_IMAGES . 'layout/product-gallery-bottom.png',
						),
						'std'				=> '',
						'multiple' 			=> false,
						'required' 			=> true,
					),
					array(
						'name' 				=> esc_html__( 'Product Video url', 'alaha' ),
						'id'   				=> $prefix . 'product_video',
						'label_description'	=> esc_html__( 'Youtube, Vimeo embaded link', 'alaha' ),
						'type' 				=> 'text',
					),
					array(
						'name' 				=> esc_html__( 'Product Size Guide', 'alaha' ),
						'label_description'	=> esc_html__( 'Select product size guide.', 'alaha' ),
						'id'   				=> $prefix . 'size_guide',
						'type' 				=> 'select',
						'options'			=> $size_guide,
						'max_file_uploads' 	=> 1,
					),
					array(
						'name'  			=> esc_html__( 'Enable Custom Tab.', 'alaha' ),
						'label_description'	=> esc_html__( 'Check this for enable custom tab.', 'alaha' ),
						'id'    			=> $prefix . 'enable_custom_tab',
						'type'  			=> 'checkbox',
						'std'				=> 0,
					),
					array (
						'name' 				=> esc_html__('Custom Tab Title', 'alaha'),
						'label_description' => esc_html__( 'Enter tab title.', 'alaha' ),
						'id' 				=> $prefix . 'product_custom_tab_heading',
						'type' 				=> 'text',
						'std' 				=> '',
						'required-field' 	=> array($prefix . 'enable_custom_tab','=',array('1')),
					),
					array(
						'name'  			=> esc_html__( 'Custom Tab Content.', 'alaha' ),
						'label_description' => esc_html__( 'Enter tab content.', 'alaha' ),
						'id'    			=> $prefix . 'product_custom_tab_content',
						'type'  			=> 'wysiwyg',
						'raw'     			=> false,
						'options' 			=> array(
							'textarea_rows' => 4,
							'teeny'         => true,
						),
						'required-field' 	=> array($prefix . 'enable_custom_tab','=',array('1')),
					), 
				)
			);
			
			/* Page  Options */
			$meta_boxes[] = array(
				'title' 		=> 	esc_html__('Page Layout', 'alaha'),
				'id' 			=> $prefix.'layout_options',
				'post_types' 	=> $this->post_types,
				'tab' 			=> 	true,
				'fields' 		=> 	array(
					array(
						'name'  		=> esc_html__( 'Page Sidebar', 'alaha' ),
						'id'    		=> $prefix.'layout',
						'type'  		=> 'image_set',
						'allowClear' 	=> true,
						'options' 		=> array(
							'full-width'	  => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
							'left-sidebar'	  => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
							'right-sidebar'	  => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
						),
						'std'			=> '',
						'multiple' 		=> false,
						'required' 		=> true,
					),
					array(
						'name'  		=> esc_html__( 'Sidebar Width', 'alaha' ),
						'id'    		=> $prefix.'sidebar_width',
						'type'     		=> 'button_group',
						'options'  		=> array(
							'default'     	=> esc_html__( 'Default', 'alaha' ),
							'3'     		=> esc_html__( 'Medium', 'alaha' ),
							'4'    			=> esc_html__( 'Large', 'alaha' ),
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std'			=>	'default',
						'required-field'=> array($prefix . 'layout','=',array('left-sidebar','right-sidebar')),
						
					),
					array (
						'name' 				=> esc_html__('Sidebar Widget', 'alaha'),
						'id' 				=> $prefix.'sidebar_widget',
						'type' 				=> 'sidebar',
						'field_type'  		=> 'select_advanced',
						'placeholder' 		=> esc_attr__('Select Sidebar','alaha'),
						'std' 				=> '',	
						'required-field' 	=> array($prefix . 'layout','=',array('left-sidebar','right-sidebar')),
						'desc' 				=> esc_html__('Select sidebar. If empty then it take value from theme options.','alaha'),																
					),										
				),
			);
			/* End Page Options */
			
			/* Header Options */
			$meta_boxes[] = array(
				'title' 		=> esc_html__('Header', 'alaha'),
				'id' 			=> $prefix .'header_options',
				'post_types' 	=> array('post','page','portfolio','product'),
				'tab' 			=> true,
				'fields' 		=> 	array(
					array(
						'name'  			=> esc_html__( 'Header Top', 'alaha' ),
						'label_description'	=> esc_html__( 'Enable or disable the top bar.', 'alaha' ),
						'id'    			=> $prefix . 'header_top',
						'type'  			=> 'button_group',
						'options' 			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std'			=> 'default',
						'multiple' 		=> false,
					),
					array(
						'name'  			=> esc_html__( 'Header', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable the header.', 'alaha' ),
						'id'    			=> $prefix . 'header',
						'type'  			=> 'button_group',
						'options' 			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std'			=> 'default',
						'multiple' 		=> false,
					),
					array(
						'name'  			=> esc_html__( 'Select Header Style', 'alaha' ),
						'label_description' => esc_html__( 'Select header style.', 'alaha' ),
						'id'    			=> $prefix.'header_style',
						'type'     			=> 'select',
						'options'  			=> array(
							'default'		=> esc_html__( 'Default', 'alaha' ),
							'1'      		=> esc_html__( 'Header 1', 'alaha' ),
							'2'   			=> esc_html__( 'Header 2', 'alaha' ),
							'3' 			=> esc_html__( 'Header 3', 'alaha' ),
							'4'				=> esc_html__( 'Header 4', 'alaha' ),
							'5'				=> esc_html__( 'Header 5', 'alaha' ),
						),
						'inline'   			=> 	true,
						'multiple' 			=> 	false,
						'std'				=>	'default',
					),
					array(
						'name'  			=> esc_html__( 'Header Transparent', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable the header transparent/overlay.', 'alaha' ),
						'id'    			=> $prefix . 'header_transparent',
						'type'  			=> 'button_group',
						'options' 			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std'			=> 'default',
						'multiple' 		=> false,
					),
				),
			);
			/* End Header Options */
			
			/* Title Options */
			$meta_boxes[] = array(
				'title' 		=> esc_html__('Page Title', 'alaha'),
				'id' 			=> $prefix.'page_title_options',
				'post_types' 	=> array('post','page','portfolio','product'),
				'tab' 			=> true,
				'fields' 		=> 	array(
					array(
						'name'  			=> esc_html__( 'Page Title', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable the page title.', 'alaha' ),
						'id'    			=> $prefix.'page_title_section',
						'type'     			=> 'button_group',
						'options'  			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable'	=> esc_html__('Enable','alaha'),
							'disable'	=> esc_html__('Disable','alaha'),
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std' 			=> 'default',
					),
					array(
						'name'  			=> esc_html__( 'Heading', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable the heading.', 'alaha' ),
						'id'    			=> $prefix.'page_heading',
						'type'     			=> 'button_group',
						'options'  			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std' 			=> 'default',
					),
					array(
					   'name' 				=> esc_html__( 'Custom Header Title', 'alaha' ),
					   'label_description'  => esc_html__( 'Alter the main title display.', 'alaha' ),
					   'desc' 				=> '',
					   'id' 				=> $prefix . 'custom_page_title',
					   'type' 				=> 'text',
					),
					array(
						'name'  			=> esc_html__( 'Title Style', 'alaha' ),
						'label_description' => esc_html__( 'Select a page title style.', 'alaha' ),
						'id'    			=> $prefix.'page_title_style',
						'type'     			=> 'button_group',
						'options'  			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'left' 		=> esc_html__('Left','alaha'),
							'center'	=> esc_html__('Centered','alaha'),							
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std' 			=> 'default',
					),
					array(
						'name'  			=> esc_html__( 'Header Font Size', 'alaha' ),
						'label_description' => esc_html__( 'Select page title font size.', 'alaha' ),
						'id'    			=> $prefix.'title_font_size',
						'type'     			=> 'button_group',
						'options'  			=> array(
							'default'	=> esc_html__( 'Default', 'alaha' ),
							'small'    	=> esc_html__( 'Small', 'alaha' ),
							'large'		=> esc_html__( 'Large', 'alaha' ),						
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std'			=> 'default',
					),
					array(
					   'name' 				=> esc_html__( 'Padding Top', 'alaha' ),
					   'desc' 				=> '',
					   'id' 				=> $prefix.'title_padding_top',
					   'type' 				=> 'number',
					),
					array(
					   'name' 				=> esc_html__( 'Padding Bottom', 'alaha' ),
					   'desc' 				=> '',
					   'id' 				=> $prefix.'title_padding_bottom',
					   'type' 				=> 'number',
					),
					array(
						'name'  			=> esc_html__( 'Background Color', 'alaha' ),
						'label_description' => esc_html__( 'Select a background color for title.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_color',
						'type'  			=> 'color',
					),
					array(
					   'name' 				=> esc_html__( 'Color', 'alaha' ),
					   'label_description'  => esc_html__( 'Select a title color.', 'alaha' ),
					   'desc' 				=> '',
					   'id' 				=> $prefix.'title_color',
					   'type'     			=> 'button_group',
					   'options'  			=> array(
							'default'	=> esc_html__( 'Default', 'alaha' ),
							'light'    	=> esc_html__( 'Light', 'alaha' ),
							'dark' 		=> esc_html__( 'Dark', 'alaha' ),
						),
						'inline'   		=> 	true,
						'multiple' 		=> 	false,
						'std' 			=> 'default',
					),
					array(
						'name'  			=> esc_html__( 'Background Image', 'alaha' ),
						'label_description' => esc_html__( 'Select a custom image for your main title.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_img',
						'type'  			=> 'single_image',
					),
					array(
						'name'  			=> esc_html__( 'Position', 'alaha' ),
						'label_description' => esc_html__( 'Select your background image position.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_position',
						'type'     			=> 'select',
						'options'  			=> array(
							'default'		=> esc_html__( 'Default', 'alaha' ),
							'left-top'      => esc_html__( 'Left Top', 'alaha' ),
							'left-center'   => esc_html__( 'Left Center', 'alaha' ),
							'left-bottom' 	=> esc_html__( 'Left Bottom', 'alaha' ),
							'right-top'		=> esc_html__( 'Right Top', 'alaha' ),
							'right-center'	=> esc_html__( 'Right Center', 'alaha' ),
							'right-bottom'	=> esc_html__( 'Right Bottom', 'alaha' ),
							'center-top'	=> esc_html__( 'Center Top', 'alaha' ),
							'center-center'	=> esc_html__( 'Center Center', 'alaha' ),
							'center-bottom'	=> esc_html__( 'Center Bottom', 'alaha' ),
						),
						'inline'   			=> 	true,
						'multiple' 			=> 	false,
						'std'				=>	'default',
					),
					array(
						'name'  			=> esc_html__( 'Attachment', 'alaha' ),
						'label_description' => esc_html__( 'Select your background image attachment.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_attachment',
						'type'     			=> 'select',
						'options'  			=> array(
							'default'	=> esc_html__( 'Default', 'alaha' ),
							'scroll'    => esc_html__( 'Scroll', 'alaha' ),
							'fixed' 	=> esc_html__( 'Fixed', 'alaha' ),
						),
						'inline'   			=> 	true,
						'multiple' 			=> 	false,
						'std'				=>	'default',
					),
					array(
						'name'  			=> esc_html__( 'Repeat', 'alaha' ),
						'label_description' => esc_html__( 'Select your background image repeat.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_repeat',
						'type'     			=> 'select',
						'options'  			=> array(
							'default'	=> esc_html__( 'Default', 'alaha' ),
							'no-repeat'	=> esc_html__( 'No-Repeat', 'alaha' ),
							'repeat'    => esc_html__( 'Repeat', 'alaha' ),
							'repeat-x'  => esc_html__( 'Repeat-X', 'alaha' ),
							'repeat-y' 	=> esc_html__( 'Repeat-Y', 'alaha' ),
							
						),
						'inline'   			=> 	true,
						'multiple' 			=> 	false,
						'std'				=>	'default',
					),
					array(
						'name'  			=> esc_html__( 'Size', 'alaha' ),
						'label_description' => esc_html__( 'Select your background image size.', 'alaha' ),
						'id'    			=> $prefix.'title_bg_size',
						'type'     			=> 'select',
						'options'  			=> array(
							'default'	=> esc_html__( 'Default', 'alaha' ),
							'auto'		=> esc_html__( 'Auto', 'alaha' ),
							'cover'     => esc_html__( 'Cover', 'alaha' ),
							'contain'   => esc_html__( 'contain', 'alaha' ),
							
						),
						'inline'   			=> 	true,
						'multiple' 			=> 	false,
						'std'				=>	'default',
					),
					array(
						'name' 				=> esc_html__( 'Background Opacity', 'alaha' ),
						'label_description' => esc_html__( 'Enter a number between 0.1 to 1. Default is 0.5.', 'alaha' ),
						'desc' 				=> '',
						'id' 				=> $prefix . 'title_bg_opacity',
						'type' 				=> 'range',
						'min'  				=> 0,
						'max'  				=> 1,
						'step' 				=> 0.1,
					),
					array(
						'type'     			=> 'button_group',
						'id'    			=> $prefix.'breadcrumb',
						'name'  			=> esc_html__( 'Show Breadcrubm', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable the page title breadcrumbs.', 'alaha' ),
						'options'  			=> array(
							'default'   => esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std' 				=> 'default',
					),	
				),
			);
			/* End Title Options */
			
			/* Footer Options */
			$meta_boxes[] = array(
				'title' 		=> esc_html__('Footer', 'alaha'),
				'id' 			=> $prefix .'footer_options',
				'post_types' 	=> array('post','page','portfolio','product'),
				'tab' 			=> true,
				'fields' 		=> 	array(
					array(
						'name'  			=> esc_html__( 'Footer', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable footer.', 'alaha' ),
						'id'    			=> $prefix . 'site_footer',
						'type'  			=> 'button_group',
						'options' 			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std'				=> 'default',
						'multiple' 			=> false,
					),
					array(
						'name'  			=> esc_html__( 'Copyright', 'alaha' ),
						'label_description' => esc_html__( 'Enable or disable copyright.', 'alaha' ),
						'id'    			=> $prefix.'footer_copyright',
						'type'  			=> 'button_group',
						'options' 			=> array(
							'default'	=> esc_html__('Default','alaha'),
							'enable' 	=> esc_html__('Enable','alaha'),
							'disable'  	=> esc_html__('Disable','alaha'),
						),
						'std'				=> 'default',
					),
				),
			);
			/* End Footer Options */
			
			return $meta_boxes;
			
		}
		public function register_metaboxes(){
			$meta_boxes = $this->alaha_meta_boxes();
			// Make sure there's no errors when the plugin is deactivated or during upgrade
			if (class_exists('RW_Meta_Box')) {
					foreach ($meta_boxes as $meta_box) {
							new RW_Meta_Box($meta_box);
					}
			}
		}
		public function alaha_admin_js_var(){
			$meta_boxes = $this->alaha_meta_boxes();
			$meta_box_id = '';
			foreach ($meta_boxes as $box) {
				if (!isset($box['tab'])) {
					continue;
				}
				if (!empty($meta_box_id)) {
					$meta_box_id .= ',';
				}
				$meta_box_id .= '#' . $box['id'];
			}
			wp_enqueue_script( 'alaha-meta-box', ALAHA_INC_DIR_URI . '/admin/assets/js/meta-box.js');
			wp_localize_script( 'alaha-meta-box' , 'kp_meta_box_ids' , $meta_box_id);
			wp_localize_script( 'alaha-meta-box' , 'kp_meta_box_title' , esc_html__('Stroyka Options','alaha'));
		}		
	}

	/**
	 * Initialize class object with 'get_instance()' method
	 */
	Stroyka_Metabox::get_instance();

endif;