<?php
/**
 * Stroyka Dashboard
 *
 * Handles the about us page HTML
 *
 * @package Stroyka
 * @since 1.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

$alaha_tabs = apply_filters('alaha_dashboard_tabs', array(
					'alaha-theme' 			=> esc_html__("Dashboard", 'alaha'),
					'alaha-system-status' 	=> esc_html__("System Status", 'alaha'),
					'alaha-theme-option' 	=> esc_html__("Theme Options", 'alaha'),
				));
$active_tab 	= isset($_GET['page']) ? $_GET['page'] : 'alaha-theme';
?>
<div class="wrap about-wrap alaha-admin-wrap alaha-dashboard-wrap">
	<h1><?php echo esc_html__('Welcome to', 'alaha').' Stroyka'; ?></h1>
	<div class="about-text">
		<?php echo sprintf( esc_html__('Thank you for purchasing our premium Stroyka theme. Here you are able
            to start creating your awesome web store by importing our dummy content and theme options.', 'alaha')); ?>
	</div>
	<div class="wp-badge alaha-page-logo"><?php echo esc_html__('Version', 'alaha') .' '.ALAHA_VERSION; ?></div>
	<p class="alaha-actions">
		<a href="https://docs.stroykas.com/alaha/" target="_blank" class="btn-docs button"><?php esc_html_e('Documentation','alaha');?></a>
		<a href="https://themeforest.net/downloads" class="btn-rate button" target="_blank"><?php esc_html_e('Rate our theme','alaha');?></a>
    </p>
	<?php if( !empty( $alaha_tabs ) ) { ?>
		<h2 class="nav-tab-wrapper">
			<?php foreach ($alaha_tabs as $tab_key => $tab_val) { 

				if( empty($tab_key) ) {
					continue;
				}
				if( !defined( 'ALAHA_EXTENSIONS_VERSION' ) && $tab_key == 'alaha-theme-option') {
					continue;
				}
				$active_tab_cls	= ( $active_tab == $tab_key ) ? ' nav-tab-active' : '';
				$tab_link 		= add_query_arg( array( 'page' => $tab_key ), admin_url('admin.php') );
				?>
				<a class="nav-tab<?php echo esc_attr( $active_tab_cls ); ?>" href="<?php echo esc_url( $tab_link ); ?>"><?php echo esc_html( $tab_val ); ?></a>
			<?php } ?>
		</h2>
	<?php } ?>
	<div id="alaha-dashboard" class="alaha-dashboard wp-clearfix">
	