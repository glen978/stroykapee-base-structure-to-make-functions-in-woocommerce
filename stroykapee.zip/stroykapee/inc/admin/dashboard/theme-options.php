<?php
/**
 * Stroyka Welcome Tab
 *
 * Handles the about us page HTML
 *
 * @package Stroyka
 * @since 1.0
 */
 require_once ALAHA_INC_DIR.'admin/dashboard-pages/header.php';

?>

<div class="alaha-cnt-wrap">
	<?php esc_html_e('Pleaes Activete theme license','alaha');?>
</div> <!-- .alaha-cnt-wrap -->
<?php 
require_once ALAHA_INC_DIR.'admin/dashboard-pages/footer.php';
?>