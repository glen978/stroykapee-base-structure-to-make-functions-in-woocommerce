<?php 
	/**
	Dashhoard footer
	*/
?>
	</div> <!-- .alaha-nav-tab-cnt-wrap -->
</div> <!-- .alaha-dashboard-wrap -->