<?php
/**
 * Stroyka Theme Options
 */
	
if ( ! class_exists( 'Redux' ) ) {
	return;
}

    $opt_name = "alaha_options";

    /*SET ARGUMENTS */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name'             		=> $opt_name,
        'display_name'         		=> $theme->get( 'Name' ),
        'display_version'      		=> $theme->get( 'Version' ),
        'menu_type'            		=> 'submenu',
        'allow_sub_menu'       		=> true,
        'menu_title'           		=> esc_html__( 'Theme Options', 'alaha' ),
        'page_title'           		=> esc_html__( 'Theme Options', 'alaha' ),
        'google_api_key'       		=> '',
        'google_update_weekly' 		=> false,
        'async_typography'     		=> false,
        'global_variable'      		=> '',
        'dev_mode'             		=> false,
        'customizer'          		=> true,
        'page_priority'       		=> null,
        'page_parent'          		=> 'alaha-theme',
        'page_permissions'     		=> 'manage_options',
        'menu_icon'            		=> '',
        'page_icon'            		=> 'icon-themes',
        'page_slug'            		=> 'alaha-theme-option',
        'save_defaults'        		=> true,
        'default_show'         		=> false,
        'default_mark'         		=> '',
        'show_import_export'   		=> true,
        'transient_time'       		=> 60 * MINUTE_IN_SECONDS,
        'output'               		=> true,
        'output_tag'           		=> true,
    );
	
    Redux::setArgs( $opt_name, $args );

    /* END ARGUMENTS */

	
    /* START SECTIONS  */

    // -> START Basic Fields
	
	/*
	* General
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'General', 'alaha' ),
        'id'         => 'general-options',
		'icon'		 => 'el el-home',
        'fields'     => array(	
			array(
                'id'       		=> 'theme-layout',
                'type'     		=> 'image_select',
                'title'    		=> esc_html__( 'Theme Layout', 'alaha' ),
				'subtitle' 		=> esc_html__( 'Select layout of site.', 'alaha' ),
                'options'  		=> array(
					'wide' => array(
                        'title' 	=> esc_html__('Wide', 'alaha' ),
                        'alt' 		=> esc_html__('Wide', 'alaha' ),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/wide.png',
                    ),  
					'full' => array(
                        'title' 	=> esc_html__('Full', 'alaha' ),
                        'alt' 		=> esc_html__('Full', 'alaha' ),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/wide.png',
                    ),                   
                    'boxed' => array(
                        'title' 	=>  esc_html__('Boxed', 'alaha' ),
                        'alt' 		=>  esc_html__('Boxed', 'alaha' ),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/box.png',
                    ),
                ),
                'default'  		=> 'full',
            ),
			array(
                'id'            	=> 'theme-container-width',
                'type'          	=> 'slider',
                'title'         	=> esc_html__('Container Width (px)','alaha'),
				'subtitle'          => esc_html__('Theme Container width in pixels','alaha'),
                'default'       	=> 1200,
                'min'           	=> 1025,
                'step'          	=> 1,
                'max'           	=> 1920,
				'required' 			=> array( 'theme-layout', '=', array( 'full', 'boxed' ) ),
            ),
			array(
                'id'       			=> 'header-logo',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Logo', 'alaha' ),
				'subtitle'          => esc_html__('Upload header logo.','alaha'),
                'compiler' 			=> 'true',
                'default'  			=> array(),
			),
			array(
                'id'       			=> 'header-logo-light',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Logo Light Version', 'alaha' ),
				'subtitle'          => esc_html__('Upload an alternative light logo that will be used on dark and transparent header.','alaha'),
                'compiler' 			=> 'true',
               'default'  			=> array(),
			),
			array(
                'id'            	=> 'header-logo-width',
                'type'          	=> 'slider',
                'title'         	=> esc_html__('Logo Width','alaha'),
				'subtitle'          	=> esc_html__('Logo width in pixels','alaha'),
                'default'       	=> 126,
                'min'           	=> 50,
                'step'          	=> 1,
                'max'           	=> 500,
                'display_value' 	=> 'text',
            ),
			array(
                'id'      			=> 'sticky-header-logo',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Sticky Header Logo', 'alaha' ),
				'subtitle'          => esc_html__('Upload sticky header logo','alaha'),
                'compiler' 			=> 'true',
				'default'  			=> array(),
			),
			array(
                'id'            	=> 'sticky-header-logo-width',
                'type'          	=> 'slider',
                'title'         	=> esc_html__('Sticky Header Logo Width','alaha'),				
				'subtitle'          => esc_html__('Logo max width in pixels','alaha'),
                'default'       	=> 98,
                'min'           	=> 50,
                'step'          	=> 1,
                'max'           	=> 500,
                'display_value' 	=> 'text',
            ),
			array(
                'id'      			=> 'mobile-header-logo',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Mobile Header Logo', 'alaha' ),
				'subtitle'          => esc_html__('Upload mobile header logo','alaha'),
                'compiler' 			=> 'true',
				'default'  			=> array(),
			),
			array(
                'id'            	=> 'mobile-header-logo-width',
                'type'          	=> 'slider',
                'title'         	=> esc_html__('Mobile Header Logo Width','alaha'),				
				'subtitle'          => esc_html__('Logo max width in pixels','alaha'),
                'default'       	=> 90,
                'min'           	=> 86,
                'step'          	=> 1,
                'max'           	=> 500,
                'display_value' 	=> 'text',
            ),	
			array(
                'id'       			=> 'theme-favicon',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Favicon', 'alaha' ),
				'subtitle'     		=> esc_html__('Upload favicon.Optimal dimension: 32px x 32px','alaha'),
                'compiler' 			=> 'true',
                'default'  			=> array(),
			),
			array(
                'id'       			=> 'theme-favicon-appple-touch',
                'type'     			=> 'media',
                'url'      			=> false,
                'title'    			=> esc_html__( 'Apple Touch Icon', 'alaha' ),
				'subtitle'     		=> esc_html__('The Apple Touch Icon is a file used for a web page icon on the Apple iPhone, iPod Touch, and iPad. When someone bookmarks your web page or adds your web page to their home screen this icon is used.Optimal dimension: 152px x 152px','alaha'),
                'compiler' 			=> 'true',
				'default'  			=> array(),
			),
		),
	) );
	
	/*
	* Google Map API
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Google Map API', 'alaha' ),
        'id'         		=> 'section-google-map-api',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'   				=> 'google-map-api',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'API Key', 'alaha' ),
				'subtitle'			=> wp_kses( __('You should create an API for yourself and put code here. read below link to more info: <a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">here</a>.', 'alaha'), array( 'a' => array( 'href' => true, 'target' => true, ), 'br' => array(), 'strong' => array() ) ),
				'default'  			=> '',
            ),
		),
	) );
	
	/**
	* Site Preloader
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Site Preloader', 'alaha' ),
        'id'         		=> 'section-site-preloader',
		'subsection'		=> true,
        'fields'     => array(
			array(
                'id'       		=> 'site-preloader',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Site Preloader', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Enable/disable preloader on your website', 'alaha' ),
                'on'       		=> esc_html__('Enable','alaha'),
                'off'      		=> esc_html__('Disable','alaha'),
                'default'  		=> 0,
            ),
			array(
                'id'       		=> 'preloader-background',
                'type'    => 'color',
				'title'   => esc_html__('Preloader Background', 'alaha' ),
				'subtitle'=> esc_html__('Set preloader background color.', 'alaha' ),				
				'transparent'=> false,
				'default'    => '#2370f4',
				'required' => array( 'site-preloader', '=', 1 ),
            ),
			array(
				'id'      => 'preloader-image',
				'type'    => 'button_set',
				'title'   => esc_html__('Preloader Image', 'alaha' ),
				'subtitle'=> esc_html__('Set preloader type as per your need.', 'alaha' ),
				'options' => array(
					'predefine-loader'=> esc_html__('Predefined Loader', 'alaha' ),
					'custom'          => esc_html__('Custom', 'alaha' ),
				),
				'default' => 'predefine-loader',
				'required' => array( 'site-preloader', '=', 1 ),
			),
			array(
                'id'       => 'predefine-loader-style',
                'type'     => 'select',
				'title'   => esc_html__('Choose Preloader Style', 'alaha' ),
				'subtitle'=> esc_html__('Set preloader type as per your need.', 'alaha' ),
                'options'  => array(
                    '1' => 'Style 1',
                    '2' => 'Style 2',
                    '3' => 'Style 3',
                    '4' => 'Style 4',
                    '5' => 'Style 5',
                ),
                'default'  => '1',
				'required' => array( 'site-preloader', '=', 1 ),
            ),
			array(
				'id'      		=> 'preloader-custom-image',
				'type'    		=> 'media',
				'url'     		=> false,
				'title'   		=> esc_html__('Upload Preloader Image', 'alaha' ),   
				'subtitle'		=> esc_html__('Upload preloader image.', 'alaha' ),
				'library_filter'=> array('gif','jpg','jpeg','png'),
				'required'      => array( 'preloader-image', '=', 'custom' ),
			),
		)
	) );
	
	/*
	* Back to top options
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Back To Top Button', 'alaha' ),
        'id'         		=> 'section-back-to-top',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       		=> 'back-to-top',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Button', 'alaha' ),
				'subtitle'		=> esc_html__('Enable/disable back to top button.', 'alaha' ),
                'default'  		=> 1,
                'on'       		=> esc_html__('Enable','alaha'),
                'off'      		=> esc_html__('Disable','alaha'),
            ),
			array(
                'id'       		=> 'back-to-top-mobile',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Button In Mobile', 'alaha' ),
				'subtitle'		=> esc_html__('Enable/disable back to top button in mobile device.', 'alaha' ),
                'default'  		=> 1,
                'on'       		=> esc_html__('Enable','alaha'),
                'off'      		=> esc_html__('Disable','alaha'),
            ),
		)
	) );
	
	/*
	* Lazyload Options
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Lazy Load Images', 'alaha' ),
        'id'         		=> 'section-lazy-load',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       		=> 'lazy-load',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Lazy Load Images', 'alaha' ),
				'subtitle'		=> esc_html__('Enables lazy load to reduce page requests.', 'alaha' ),
                'on'       		=> esc_html__('Enable','alaha'),
                'off'      		=> esc_html__('Disable','alaha'),
                'default'  		=> 0,
            ),
		)
	) );
	
	/*
	* Theme Typography
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Typography', 'alaha' ),
        'id'         => 'section-typography',
		'icon'		 => 'el el-font',
        'fields'     => array(
			array(
				'id'          		=> 'body-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('Body Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'color'  			=> false,
				'letter-spacing' 	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all body text.', 'alaha'),
				'output' 			=> array('body'),
				'default'     		=> array(
					'font-weight'  		=> '400', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '14px',
					'letter-spacing'	=> '',
				),
			),
			array(
				'id'          		=> 'paragraph-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('(P)Paragraph Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'color'  			=> false,
				'letter-spacing' 	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all (P) Paragraph.', 'alaha'),
				'output' 			=> array('p'),
				'default'     		=> array(
					'font-weight'  		=> '400', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '14px', 
					'letter-spacing'	=> '',
				),
			),			
			array(
				'id'          		=> 'h1-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H1 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H1 Headings.', 'alaha'),
				'output' 			=> array('h1, .h1'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '28px',
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'h2-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H2 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H2 Headings.', 'alaha'),
				'output' 			=> array('h2, .h2'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '26px',
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'h3-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H3 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H3 Headings.', 'alaha'),
				'output' 			=> array('h3, .h3'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '24px',
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'h4-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H4 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H4 Headings.', 'alaha'),
				'output' 			=> array('h4, .h4'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '20px',
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'h5-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H5 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H5 Headings.', 'alaha'),
				'output' 			=> array('h5, .h5'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '16px', 
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'h6-headings-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('H6 Headings Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for all H6 Headings.', 'alaha'),
				'output' 			=> array('h6, .h6'),
				'default'     		=> array(
					'color'       		=> '#333333', 
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '14px', 
					'letter-spacing'	=> '',
					'text-transform'	=> 'inherit'
				),
			),
			array(
				'id'          		=> 'main-menu-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('Main Menu Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'color'				=> false,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for header main navigation.', 'alaha'),
				'output' 			=> array('.main-navigation ul.menu > li > a'),
				'default'     		=> array(
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '13px', 
					'letter-spacing'	=> '.2px',
					'text-transform'	=> 'uppercase'
				),
			),
			array(
				'id'          		=> 'categories-menu-font',
				'type'        		=> 'typography',
				'title'       		=> esc_html__('Categories Menu Font', 'alaha'),
				'all_styles'  		=> true,
				'font-backup' 		=> true,
				'color'				=> false,
				'text-align'  		=> false,
				'line-height' 		=> false,
				'letter-spacing' 	=> true,
				'text-transform'	=> true,
				'units'       		=>'px',
				'subtitle'    		=> esc_html__('These settings control the typography for categories menu.', 'alaha'),
				'output' 			=> array('.categories-menu ul.menu > li > a'),
				'default'     		=> array(
					'font-weight'  		=> '700', 
					'font-family' 		=> 'Lato', 
					'google'      		=> true,
					'font-backup' 		=> 'Arial, Helvetica, sans-serif',
					'font-size'   		=> '14px', 
					'letter-spacing'	=> '.2px',
					'text-transform'	=> 'inherit'
				),
			),
		),
	) );
	
	/*
	* Custom Fonts
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Custom Fonts', 'alaha' ),
        'id'         	=> 'section-custom-font',
		'desc'  		=> esc_html__( 'After uploading your fonts,you will have to save Theme Settings and RELOAD this page , Then you should select font family (custom font family)from dropdown list in (Body/Paragraph/Headings/Navigation) Typography section.', 'alaha' ),
        'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'       			=> 'custom-font1',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Custom Font1','alaha'),
                'subtitle' 	   		=> esc_html__('Please enable this option to use Custom Font 1.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'type'      		=> 'text',
                'id'        		=> 'custom-font1-name',
                'title'     		=> esc_html__( 'Font1 Name', 'alaha' ),
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font1-woff',
                'title'     		=> esc_html__( 'Font1 (.woff)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font1-woff2',
                'title'     		=> esc_html__( 'Font1 (.woff2)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font1-ttf',
                'title'     		=> esc_html__( 'Font1 (.ttf)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font1-svg',
                'title'     		=> esc_html__( 'Font1 (.svg)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font1-eot',
                'title'     		=> esc_html__( 'Font1 (.eot)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font1', '=', '1' ),
            ),
			array(
                'id'       			=> 'custom-font2',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Custom Font2','alaha'),
                'subtitle' 	   		=> esc_html__('Please enable this option to use Custom Font 2.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'type'      		=> 'text',
                'id'        		=> 'custom-font2-name',
                'title'     		=> esc_html__( 'Font2 Name', 'alaha' ),
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font2-woff',
                'title'     		=> esc_html__( 'Font2 (.woff)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font2-woff2',
                'title'     		=> esc_html__( 'Font2 (.woff2)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font2-ttf',
                'title'     		=> esc_html__( 'Font2 (.ttf)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font2-svg',
                'title'     		=> esc_html__( 'Font2 (.svg)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font2-eot',
                'title'     		=> esc_html__( 'Font2 (.eot)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font2', '=', '1' ),
            ),
			array(
                'id'       			=> 'custom-font3',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Custom Font3','alaha'),
                'subtitle' 	   		=> esc_html__('Please enable this option to use Custom Font 3.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'type'      		=> 'text',
                'id'        		=> 'custom-font3-name',
                'title'     		=> esc_html__( 'Font3 Name', 'alaha' ),
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font3-woff',
                'title'     		=> esc_html__( 'Font3 (.woff)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font3-woff2',
                'title'     		=> esc_html__( 'Font3 (.woff2)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font3-ttf',
                'title'     		=> esc_html__( 'Font3 (.ttf)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font3-svg',
                'title'     		=> esc_html__( 'Font3 (.svg)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
			array(
                'type'      		=> 'media',
                'id'        		=> 'custom-font3-eot',
                'title'     		=> esc_html__( 'Font3 (.eot)', 'alaha' ),
                'mode'       		=> false,
                'preview'  			=> false,
                'url'       		=> true,
                'required'  		=> array( 'custom-font3', '=', '1' ),
            ),
		),
	) );
	
	/*
	* Typekit Font
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Adobe Typekit Font', 'alaha' ),
        'id'         	=> 'section-typekit-font',
        'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'       			=> 'typekit-font',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Adobe Typekit Font','alaha'),
                'subtitle' 	   		=> esc_html__('Please enable this option to use Adobe Typekit.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'id'   				=> 'typekit-kit-id',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Typekit Kit ID', 'alaha' ),
				'subtitle' 			=> esc_html__('Enter your ', 'alaha') . '<a target="_blank" href="https://typekit.com/account/kits">Typekit Kit ID</a>.',
				'required'  		=> array( 'typekit-font', '=', '1' ),
            ),
			array(
                'id'   				=> 'typekit-kit-family',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Typekit Font Family', 'alaha' ),
				'subtitle' 			=> esc_html__('Enter all custom fonts you will use separated with coma.', 'alaha'),
				'required'  		=> array( 'typekit-font', '=', '1' ),
            ),
		),
	) );
	
	/*
	* Theme Styling and colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Styling and Colors', 'alaha' ),
        'id'         	=> 'section-styling-colors',
		'icon'		 	=> 'el el-brush',
        'fields'     	=> array(			
		),
	) );
	
	/*
	* Body colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Body', 'alaha' ),
        'id'         	=> 'section-body-color',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
				'id'       		=> 'primary-color',
				'type'     		=> 'color',
				'title'    		=> esc_html__('Primary Color', 'alaha'),
				'validate' 		=> 'color',
				'default'  		=> '#2370F4'
			),
			array(
				'id'       		=> 'primary-inverse-color',
				'type'     		=> 'color',
				'title'    		=> esc_html__( 'Primary Inverse Color', 'alaha' ), 
				'validate' 		=> 'color',
				'default'  		=> '#ffffff'
			),
			array(
				'id'       		=> 'theme-hover-background-color',
				'type'     		=> 'color',
				'title'    		=> esc_html__( 'Hover Background Color', 'alaha' ), 
				'subtitle' 		=> esc_html__( 'Apply theme hover background color for ul li menu, list, etc....', 'alaha' ),
				'validate' 		=> 'color',
				'default'  		=> '#f5faff'
			),
			array (
				'id'       		=> 'site-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Body Background', 'alaha'),
				'subtitle' 		=> esc_html__('Body background image or color. Only for work in Boxed layout', 'alaha'),
				'output' 		=> array('body'),
				'default'  		=> array(
					'background-color'	 	=> '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array (
				'id'       		=> 'site-wrapper-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Wrapper Background', 'alaha'),
				'output' 		=> array('.site-wrapper'),
				'default'  		=> array(
					'background-color'	 	=> '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'site-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Site text color', 'alaha'),
                'default'  		=> '#555555',
            ),			
			array(
                'id'       		=> 'site-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Site link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'       		=> 'site-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Site border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'site-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'site-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),			
		),
	) );
	
	/*
	* Topbar colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Topbar', 'alaha' ),
        'id'         	=> 'section-topbar',
		'subsection'   	=> true,
        'fields'     	=> array(
			array (
				'id'       		=> 'topbar-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Topbar background image or color.', 'alaha'),
				'output' 		=> array('.header-topbar'),
				'default'  		=> array(
					'background-color'	 	=> '#2370F4',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'topbar-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Topbar text color', 'alaha'),
                'default'  		=> '#FFFFFF',
            ),			
			array(
                'id'       		=> 'topbar-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Topbar link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#FFFFFF',
                    'hover'   	=> '#F1F1F1',
                )
            ),
			array(
                'id'       		=> 'topbar-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Topbar border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#3885fe',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'topbar-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'topbar-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
			array(
                'id'          		=> 'topbar-max-height',
                'type'          	=> 'dimensions',
                'title'          	=> esc_html__( 'Max Height', 'alaha' ),
				'subtitle'    		=> esc_html__( 'Set max height for topbar.', 'alaha' ),
                'units_extended'	=> false,
                'width'        	 	=> false,
                'default'        	=> array(
                    'height' 		=> 42,
                )
            ),
		),
	) );
	
	/*
	* Header colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Header & Sticky', 'alaha' ),
        'id'         	=> 'section-header',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'    => 'header-notice1',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Header Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'header-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Header background image or color', 'alaha'),
				'output' 		=> array('.header-main'),
				'default'  		=> array(
					'background-color'	 	=> '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'header-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Header text color', 'alaha'),
                'default'  		=> '#555555',
            ),			
			array(
                'id'       		=> 'header-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Header link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370f4',
                )
            ),
			array(
                'id'       		=> 'header-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Header border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'header-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'header-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
			array(
                'id'          		=> 'header-min-height',
                'type'          	=> 'dimensions',
                'title'          	=> esc_html__( 'Min Height', 'alaha' ),
				'subtitle'    		=> esc_html__( 'Set min height for header.', 'alaha' ),
				'units_extended'	=> false,
                'width'        	 	=> false,
                'default'        	=> array(
                    'height' 		=> 100,
                )
            ),
			array(
                'id'    => 'header-notice2',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Header Transparent Colors', 'alaha' ),
            ),
			array(
                'id'       			=> 'header-transparent-color',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__('Header Transparent Color','alaha'),
                'subtitle' 	   		=> esc_html__('This color will work when header transparent/overlay enable.','alaha'),
                'options'  			=> array(
                    'light' 	=> esc_html__('Light', 'alaha' ),
                    'dark' 		=> esc_html__('Dark', 'alaha' ),
                ),
                'default'  			=> 'light',
            ),
			
			array(
                'id'    => 'header-notice3',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Header Sticky Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'header-sticky-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Header Sticky background image or color', 'alaha'),
				'output' 		=> array('.header-sticky'),
				'default'  		=> array(
					'background-color'	 => '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'header-sticky-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Header Sticky text color', 'alaha'),
                'default'  		=> '#555555',
            ),			
			array(
                'id'       		=> 'header-sticky-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Header Sticky link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370f4',
                )
            ),
			array(
                'id'       		=> 'header-sticky-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Header Sticky border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'header-sticky-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'header-sticky-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
		),
	) );
	
	/*
	* Navigation Bar Colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Navigation Bar', 'alaha' ),
        'id'         	=> 'section-navigation-bar',
		'subsection'   	=> true,
        'fields'     	=> array(			
			array (
				'id'       		=> 'navigation-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Navigation bar background image or color', 'alaha'),
				'output' 		=> array('.header-navigation'),
				'default'  		=> array(
					'background-color'	 => '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'navigation-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Navigation bar text color', 'alaha'),
                'default'  		=> '#555555',
            ),			
			array(
                'id'       		=> 'navigation-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Navigation bar link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'       		=> 'navigation-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Navigation bar border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'navigation-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'navigation-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
			array(
                'id'          		=> 'navigation-min-height',
                'type'          	=> 'dimensions',
                'title'          	=> esc_html__( 'Min Height', 'alaha' ),
				'subtitle'    		=> esc_html__( 'Set min height for navigation bar.', 'alaha' ),
                'units_extended'	=> false,
                'width'        	 	=> false,
                'default'        	=> array(
                    'height' 		=> 48,
                )
            ),
		),
	) );
	
	/*
	* Menu Colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Menu & Categories menu', 'alaha' ),
        'id'         	=> 'section-menu',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'    => 'frist-level-menu-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'First Level Menu Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'first-level-menu-background-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Hover Background Color','alaha'),
				'subtitle' 		=> esc_html__('First level menu hover background color', 'alaha'),
                'default'  		=> 'transparent',
            ),		
			array(
                'id'       		=> 'first-level-menu-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('First level menu link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'    => 'frist-level-sticky-menu-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'First Level Header Sticky Menu Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'first-level-sticky-menu-background-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Hover Background Color','alaha'),
				'subtitle' 		=> esc_html__('First level sticky header menu hover background color', 'alaha'),
                'validate' 		=> 'color',
                'default' 		=> 'transparent',
            ),		
			array(
                'id'       		=> 'first-level-sticky-menu-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('First level sticky header menu link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'    => 'categories-menu-title-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Categories Menu Title Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'categories-menu-title-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Background Color','alaha'),
				'subtitle' 		=> esc_html__('Categories menu title background color', 'alaha'),
                'validate' 		=> 'color',
                'default' 		=> '#2370F4',
            ),		
			array(
                'id'       		=> 'categories-menu-title-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Title Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Categories menu title color.','alaha'),
                'active'    	=> false,
                'default' 		=> '#ffffff',
            ),
			array(
                'id'    => 'categories-menu-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Categories Area & Menu Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'categories-menu-wrapper-background',
				'type'     		=> 'color',
				'title'    		=> esc_html__('Background Color', 'alaha'),
				'subtitle' 		=> esc_html__('Categories menu wrapper/area background color', 'alaha'),
				'default'  		=> '#ffffff',
			),
			array(
                'id'       		=> 'categories-menu-hover-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Hover Background Color','alaha'),
				'subtitle' 		=> esc_html__('Categories menu hover background color', 'alaha'),
                'validate' 		=> 'color',
                'default' 		=> '#f5faff',
            ),
			array(
                'id'       		=> 'categories-menu-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Categories menu link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'       		=> 'categories-menu-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Categories menu border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'    => 'menu-popup-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Main & Categories menu Popup Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'popup-menu-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Popup menu background image or color', 'alaha'),
				'output' 		=> array('.alaha-navigation ul.menu ul.sub-menu, .alaha-navigation .alaha-megamenu-wrapper'),
				'default'  		=> array(
					'background-color'	 => '#ffffff',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'popup-menu-hover-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Hover Background Color','alaha'),
				'subtitle' 		=> esc_html__('Popup menu hover background color', 'alaha'),
                'validate' 		=> 'color',
                'default' 		=> '#f5faff',
            ),
			array(
                'id'       		=> 'popup-menu-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Popup menu text color', 'alaha'),
                'default'  		=> '#555555',
            ),			
			array(
                'id'       		=> 'popup-menu-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Popup menu link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#333333',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'       		=> 'popup-menu-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Popup menu border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#e9e9e9',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
		),
	) );
	
	/*
	* Page Title colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Page Title', 'alaha' ),
        'id'         	=> 'section-page-title',
		'subsection'   	=> true,
        'fields'     	=> array(			
			array (
				'id'       		=> 'page-title-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Page title background image or color', 'alaha'),
				'output' 		=> array('#page-title'),
				'default'  		=> array(
					'background-color'	 => '#f8f8f8',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> 'cover',
					'background-attachment' => '',
					'background-position' 	=> 'center center'
				),
			),
			array(
                'id'       			=> 'page-title-color',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__('Title Color','alaha'),
                'subtitle' 	   		=> esc_html__('Page title color.','alaha'),
                'options'  			=> array(
                    'default' 	=> esc_html__('Default', 'alaha' ),
                    'light' 	=> esc_html__('Light', 'alaha' ),
                    'dark' 		=> esc_html__('Dark', 'alaha' ),
                ),
                'default'  			=> 'dark',
            ),
			array(
                'id'       			=> 'page-title-size',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__('Title Size','alaha'),
                'subtitle' 	   		=> esc_html__('Page title size.','alaha'),
                'options'  			=> array(
                    'default' 		=> esc_html__('Default', 'alaha' ),
                    'small' 		=> esc_html__('Small', 'alaha' ),
                    'large' 		=> esc_html__('Large', 'alaha' ),
                ),
                'default'  			=> 'default',
            ),
			array(
				'id'             	=> 'page-title-padding',
				'type'           	=> 'spacing',
				'title'          	=> esc_html__('Padding', 'alaha'),
				'subtitle'       	=> esc_html__('Set top bottom padding for page title.', 'alaha'),
				'mode'           	=> 'padding',
				'units_extended' 	=> 'false',
				'left'        	 	=> false,
                'right'        	 	=> false,
				'default'            => array(
					'padding-top'     	=> '50', 
					'padding-bottom'  	=> '50',
					'units'          	=> 'px', 
				)
			)
		),
	) );
	
	/*
	* Footer colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Footer', 'alaha' ),
        'id'         	=> 'section-footer',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'    => 'footer-notice1',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Footer Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'footer-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Footer background image or color', 'alaha'),
				'output' 		=> array('.site-footer .footer-main'),
				'default'  		=> array(
					'background-color'	 => '#172337',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'footer-title-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Title Color','alaha'),
				'subtitle' 		=> esc_html__('Footer title color like widget, etc', 'alaha'),
                'default'  		=> '#ffffff',
            ),
			array(
                'id'       		=> 'footer-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Footer text color', 'alaha'),
                'default'  		=> '#f1f1f1',
            ),
			array(
                'id'       		=> 'footer-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Footer link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#f1f1f1',
                )
            ),
			array(
                'id'       		=> 'footer-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Footer border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#454d5e',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
			array(
                'id'       		=> 'footer-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'footer-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
			array(
                'id'    => 'copyright-notice1',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Copyright Colors', 'alaha' ),
            ),
			array (
				'id'       		=> 'copyright-background',
				'type'     		=> 'background',
				'title'    		=> esc_html__('Background', 'alaha'),
				'subtitle' 		=> esc_html__('Copyright background image or color', 'alaha'),
				'output' 		=> array('.site-footer .footer-copyright'),
				'default'  		=> array(
					'background-color'	 => '#172337',
					'background-image' 		=> '',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> ''
				),
			),
			array(
                'id'       		=> 'copyright-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Copyright text color', 'alaha'),
                'default'  		=> '#f1f1f1',
            ),			
			array(
                'id'       		=> 'copyright-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Copyright link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#f1f1f1',
                )
            ),
			array(
                'id'       		=> 'copyright-border',
                'type'     		=> 'border',
                'title'   	 	=> esc_html__( 'Border', 'alaha' ),
                'subtitle' 		=> esc_html__('Copyright border color, style and width.','alaha'),
                'default'  		=> array(
                    'border-color'  => '#454d5e',
                    'border-style'  => 'solid',
					'border-top'    => '1px',
					'border-right'  => '1px',
					'border-bottom' => '1px',
					'border-left'   => '1px'
                )
            ),
		),
	) );
	
	/*
	* Buttons colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Buttons', 'alaha' ),
        'id'         	=> 'section-buttons',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'    => 'site-button-color-info',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Site Buttons Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'button-background',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Button Background', 'alaha' ),
                'subtitle' 		=> esc_html__('Set button background and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#2370F4',
                    'hover'   	=> '#2370F4',
                )
            ),
			array(
                'id'       		=> 'button-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Button Color', 'alaha' ),
                'subtitle' 		=> esc_html__( 'Set button text color and hover color.', 'alaha' ),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#fcfcfc',
                )
            ),
			array(
                'id'    => 'product-page-button-color-info',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Product Page Buttons Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'product-cart-button-background',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Add To Cart Background', 'alaha' ),
                'subtitle' 		=> esc_html__('Set add to cart button background and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ff9f00',
                    'hover'   	=> '#ff9f00',
                )
            ),
			array(
                'id'       		=> 'product-cart-button-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Add To Cart Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Set add to cart button text color and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#fcfcfc',
                )
            ),
			array(
                'id'       		=> 'buy-now-button-background',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Buy Now Background', 'alaha' ),
                'subtitle' 		=> esc_html__('Set buy now button background and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#FB641B',
                    'hover'   	=> '#FB641B',
                )
            ),
			array(
                'id'       		=> 'buy-now-button-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Buy Now Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Set buy now button text color and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#fcfcfc',
                )
            ),
			array(
                'id'    => 'checkout-button-color-info',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Checkout Buttons Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'checkout-button-background',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Checkout & Place Order Background', 'alaha' ),
                'subtitle' 		=> esc_html__('Set checkout button background and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#FB641B',
                    'hover'   	=> '#FB641B',
                )
            ),
			array(
                'id'       		=> 'checkout-button-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Checkout & Place Order Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Set checkout button text color and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#fcfcfc',
                )
            ),
			
		),
	) );
	
	/*
	* Mobile colors
	*/
	Redux::setSection( $opt_name, array(
        'title'      	=> esc_html__( 'Mobile', 'alaha' ),
        'id'         	=> 'section-mobile',
		'subsection'   	=> true,
        'fields'     	=> array(
			array(
                'id'    => 'header-mobile-notice',
                'type'   => 'info',
                'notice' => false,
                'title' => esc_html__( 'Mobile Header Colors', 'alaha' ),
            ),
			array(
                'id'       		=> 'header-mobile-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Background','alaha'),
				'subtitle' 		=> esc_html__('Mobile header background color', 'alaha'),
                'default'  		=> '#2370F4',
            ),	
			array(
                'id'       		=> 'header-mobile-text-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__('Text Color','alaha'),
				'subtitle' 		=> esc_html__('Mobile header text color', 'alaha'),
                'default'  		=> '#FFFFFF',
            ),			
			array(
                'id'       		=> 'header-mobile-link-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Link Color', 'alaha' ),
                'subtitle' 		=> esc_html__('Mobile header link and hover color.','alaha'),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#FFFFFF',
                    'hover'   	=> '#F1F1F1',
                )
            ),
			array(
                'id'       		=> 'header-mobile-input-color',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Color', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set color input field like TextBox, Textarea, SelectBox, etc..', 'alaha'),
                'default'  		=> '#555555',
            ),
			array(
                'id'       		=> 'header-mobile-input-background',
                'type'     		=> 'color',
                'title'    		=> esc_html__( 'Input Field Background', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Set background input field like TextBox, Textarea, SelectBox, etc..', 'alaha' ),
                'default'  		=> '#ffffff',
            ),
			array(
				'id'       		=> 'google-theme-color',
				'type'     		=> 'color',
				'title'    		=> esc_html__( 'Google Theme Color', 'alaha' ), 				
				'subtitle'   		=> wp_kses( sprintf( __( 'Applied only on mobile devices Android on chrome browser toolbar, <a href="%s" target="_blank">click here</a> plugin.', 'alaha' ), esc_url( 'http://updates.html5rocks.com/2014/11/Support-for-theme-color-in-Chrome-39-for-Android/' ) ),
				array(
						'a' => array(
							'href'   => array(),
							'target' => array(),
						),
					) 
				),
				'validate' 		=> 'color',
				'default'  		=> '#2370F4'
			),			
		),
	) );
	
	/*
	* Header
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Header', 'alaha' ),
        'id'         => 'header',
		'icon'		 => 'el el-photo',
        'fields'     => array(						
			array(
                'id'   				=> 'header-phone-number',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Phone Number', 'alaha' ),
				'default'  			=> '+(123) 4567 890',
            ),			
			array(
                'id'   				=> 'header-email',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Email Address', 'alaha' ),
				'default'  			=> 'sales@alaha.com',
            ),
			array(
                'id'   				=> 'header-location',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Store Location', 'alaha' ),
				'default'  			=> '123 Street, New York, US',
            ),
			array(
                'id'   				=> 'header-welcome-message',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Welcome Message', 'alaha' ),
				'default'  			=> 'Welcome to Our Store!',
            ),
			array(
                'id'   				=> 'header-newsletter',
                'type'      		=> 'text',
                'title'     		=> esc_html__( 'Newsletter', 'alaha' ),
				'default'  			=> 'Newsletter',
            ),
			array(
                'id'      			=> 'header-language-switcher-style',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__( 'Language Switcher Style', 'alaha' ),
				'subtitle'   		=> wp_kses( sprintf( __( 'This option will work if you have used <a href="%s" target="_blank">Polylang</a> plugin.', 'alaha' ), esc_url( 'https://wordpress.org/plugins/polylang/' ) ), array(
						'a' => array(
							'href'   => array(),
							'target' => array(),
						),
					) 
				),
                'options'  			=> array(
					'dropdown'		=> esc_html__('Dropdown', 'alaha' ),
                    'horizontal' 	=> esc_html__('Horizontal List', 'alaha' ),
                ),
                'default'  			=> 'dropdown',
            ),
			array(
                'id'       			=> 'header-language-switcher-view',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__( 'Language Country', 'alaha' ),
				'subtitle'   		=> wp_kses( sprintf( __( 'This option will work if you have used <a href="%s" target="_blank">Polylang</a> plugin.', 'alaha' ), esc_url( 'https://wordpress.org/plugins/polylang/' ) ), array(
						'a' => array(
							'href'   => array(),
							'target' => array(),
						),
					) 
				),
                'options'  			=> array(
					'both'		=> esc_html__('Flag & Name', 'alaha' ),
                    'name' 		=> esc_html__('Name', 'alaha' ),
                    'flag' 		=> esc_html__('Flag', 'alaha' ),
                ),
                'default'  			=> 'both',
            ),
			array(
                'id'       			=> 'login-register-popup',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Login/Register Popup','alaha'),
                'subtitle' 	   		=> esc_html__('Enable/disable header login/register popup.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 1,
            ),
			array(
                'id'       			=> 'header-myaccount-style',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'My Account Style', 'alaha' ),
				'subtitle' 	   		=> esc_html__('Select myaccount style.','alaha'),
                'options'  			=> array(
					1 		=> array(
                        'alt' 	=> '1',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/myaccount/1.jpg'
                    ), 
					2 		=> array(
                        'alt' 	=> '2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/myaccount/2.jpg'
                    ), 
                ),
                'default'  			=> 1,
            ),
			array(
                'id'       			=> 'header-minicart-popup',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Mini Cart Popup','alaha'),
                'subtitle' 	   		=> esc_html__('Enable/disable header minicart popup.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 1,
            ),
			array(
                'id'       			=> 'header-cart-style',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'Cart Style', 'alaha' ),
				'subtitle' 	   		=> esc_html__('Select cart style.','alaha'),
                'options'  			=> array(
					1 		=> array(
                        'alt' 	=> '1',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/1.jpg'
                    ), 
					2 		=> array(
                        'alt' 	=> '2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/2.jpg'
                    ), 
					3 		=> array(
                        'alt' 	=> '3',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/3.jpg'
                    ),
                    4	=> array(
                        'alt' 	=> '4',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/4.jpg'
                    ),
					5	=> array(
                        'alt' 	=> '5',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/5.jpg'
                    ),
					6	=> array(
                        'alt' 	=> '6',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/6.jpg'
                    ),
                ),
                'default'  			=> 1,
            ),
			array(
                'id'       			=> 'header-cart-icon',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'Cart Icon', 'alaha' ),
				'subtitle' 	   		=> esc_html__('Select cart icon.','alaha'),
                'options'  			=> array(					
					'bag-icon' 		=> array(
                        'alt' 		=> 'Icon Bag',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/icon-1.jpg'
                    ),
					 'cart-icon'	=> array(
                        'alt' 		=> 'Icon Cart',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/icon-2.jpg'
                    ),
                    'bag-icon-2'	=> array(
                        'alt' 		=> 'Icon Bag 2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/cart/icon-3.jpg'
                    ),                   					
                ),
                'default'  			=> 'bag-icon',
            ),
			array(
                'id'       => 'shop-by-categories-title',
                'type'     => 'text',
                'title'    => esc_html__('Shop By Categories Title','alaha'),
				'subtitle' => esc_html__('Enter shop by categories menu title.','alaha'),
				'default'  => 'Shop By Categories',
            ),
			array(
                'id'       => 'open-categories-menu',
                'type'     => 'switch',
                'title'    => esc_html__('Open Categories(Vertical) Menu In Front Page','alaha'),
                'subtitle' => esc_html__('Categories(Vertical) menu open in front page.On other page open with hover.','alaha'),
                'on'       => esc_html__('Open','alaha'),
				'off'      => esc_html__('Close','alaha'),
				'default'  => 0,
            ),
		),
	) );
	
	/*
	* Header Manager options
	*/
    Redux::setSection( $opt_name, array(
        'title'     	 	=> esc_html__( 'Header Manager', 'alaha' ),
        'id'         		=> 'header-manager',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       			=> 'header-topbar',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Topbar','alaha'),
                'subtitle' 	   		=> esc_html__('Enable/disable topbar.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 1,
            ),
			array(
                'id'       			=> 'header-transparent',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Header Transparent','alaha'),
                'subtitle' 	   		=> esc_html__('Make the header transparent/overlay the content.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 0,
            ),
			array(
                'id'       			=> 'header-transparent-on',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__('Header Transparent On','alaha'),
                'subtitle' 	   		=> esc_html__('Make the header transparent/overlay the content on front page or all pages.','alaha'),
                'options'  			=> array(
                    'front-page' 	=> esc_html__('Front Page', 'alaha' ),
                    'all-pages' 	=> esc_html__('All Pages', 'alaha' ),
                ),
                'default'  			=> 'front-page',
				'required' 			=> array( 'header-transparent', '=', 1 ),
            ),
			array(
                'id'       		=> 'header-select',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Select Header', 'alaha' ),
				//'desc'       	=> esc_html__( 'Show/hide specific meta.', 'alaha' ),
                'options'  		=> array(
                    'style' 	=> esc_html__('Header Style', 'alaha' ),
                    'builder' 	=> esc_html__('Header Builder', 'alaha' ),
                ),
                'default'  		=> 'style',
            ),
			array(
                'id'       			=> 'header-style',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'Header Style', 'alaha' ),
                'subtitle' 			=> esc_html__( 'Select a header style.', 'alaha' ),
				'full_width' 		=> true,
				'options'  			=> array(
					'1' => array( 'title' => '1', 'alt' => 'Header 1', 'img' => ALAHA_ADMIN_IMAGES.'header/header-1.png' ),
                    '2' => array( 'title' => '2', 'alt' => 'Header 2', 'img' => ALAHA_ADMIN_IMAGES.'header/header-2.png' ),
                    '3' => array( 'title' => '3', 'alt' => 'Header 3', 'img' => ALAHA_ADMIN_IMAGES.'header/header-3.png' ),
                    '4' => array( 'title' => '4', 'alt' => 'Header 4', 'img' => ALAHA_ADMIN_IMAGES.'header/header-4.png' ),
                    '5' => array( 'title' => '5', 'alt' => 'Header 5', 'img' => ALAHA_ADMIN_IMAGES.'header/header-5.png' ),
                    '6' => array( 'title' => '6', 'alt' => 'Header 6', 'img' => ALAHA_ADMIN_IMAGES.'header/header-6.png' ),
                    '7' => array( 'title' => '7', 'alt' => 'Header 7', 'img' => ALAHA_ADMIN_IMAGES.'header/header-7.png' ),
                ),
                'default'  			=> '1',				
				'required' 			=> array( 'header-select', '=', 'style' ),
            ),
			array(
                'id'    			=> 'header-topbar-info1',
                'type'  			=> 'info',
				'notice' 			=> false,
                'title' 			=> esc_html__( 'Header Topbar Manager', 'alaha' ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),			
			array(
                'id'       			=> 'header-topbar-manager',
                'type'     			=> 'sorter',
                'title'    			=> esc_html__( 'Topbar Manager', 'alaha' ),
				'description'		=> esc_html__('Organize how you want the layout to appear on the header topbar', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                    'left'  	=> array(
						'language-switcher'	=> esc_html__( 'Language Switcher', 'alaha' ),
						'currency-switcher'	=> esc_html__( 'Currency Switcher', 'alaha' ),						
                    ),
					'right' 	=> array(
						'welcome-message'	=> esc_html__( 'Welcome Message', 'alaha' ),
						'topbar-menu'		=> esc_html__( 'Topbar Menu', 'alaha' ),
					),
					'disabled' 	=> array(						
                        'phone-number'		=> esc_html__( 'Phone Number', 'alaha' ),
						'email' 			=> esc_html__( 'Email', 'alaha' ),
						'social-profile'	=> esc_html__( 'Social Profile', 'alaha' ),
						'location'			=> esc_html__( 'Location', 'alaha' ),
						'newletter'			=> esc_html__( 'Newsletter', 'alaha' ),
						'min-search'		=> esc_html__( 'Mini Search', 'alaha' ),
						/* 'topbar-widget'		=> 'Widget', */
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-topbar-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Topbar Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '5',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
				'id'       			=> 'header-topbar-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Topbar Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '7',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'    			=> 'header-main-info1',
                'type'  			=> 'info',
				'notice' 			=> false,
                'title' 			=> esc_html__( 'Header Main Manager', 'alaha' ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
                'id'       			=> 'header-main-manager',
                'type'     			=> 'sorter',
                'title'    			=> 'Header Main Manager',
				'subtitle'			=> esc_html__('Organize how you want the layout to appear on the header main', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                    'left'  	=> array(
                        'logo' 			=> esc_html__( 'Logo', 'alaha' ),
                    ),
                    'center' 	=> array(
						'ajax-search'	=> esc_html__( 'Ajax Search', 'alaha' ),
					),
					'right' 	=> array(
						'myaccount'			=> esc_html__( 'My Account', 'alaha' ),						
						'wishlist'			=> esc_html__( 'Wishlist', 'alaha' ),
						'cart'				=> esc_html__( 'Cart', 'alaha' ),						
					),
					'disabled' 	=> array(
						'primary-menu'		=> esc_html__( 'Primary Menu', 'alaha' ),
						'secondary-menu'	=> esc_html__( 'Secondary Menu', 'alaha' ),
						'min-search'		=> esc_html__( 'Mini Search', 'alaha' ),
						'currency-switcher'	=> esc_html__( 'Currency Switcher', 'alaha' ),
						'language-switcher'	=> esc_html__( 'Language Switcher', 'alaha' ),
						'customer-support'	=> esc_html__( 'Customer Support', 'alaha' ),
						//'middle-widget'		=> esc_html__( 'Widget', 'alaha' ),
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-main-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Main Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '3',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
				'id'       			=> 'header-main-center',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Main Center', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '6',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-main-align',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Alignment Center','alaha'),
                'subtitle' 	   		=> esc_html__('Alignment center for above section.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 0,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-main-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Main Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '3',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'    			=> 'header-navigation-info1',
                'type'  			=> 'info',
				'notice' 			=> false,
                'title' 			=> esc_html__( 'Header Navigation Manager', 'alaha' ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
                'id'       			=> 'header-navigation',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Header Navigation','alaha'),
                'subtitle' 	   		=> esc_html__('Enable/disable navigation.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 1,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
                'id'       			=> 'header-navigation-manager',
                'type'     			=> 'sorter',
                'title'    			=> esc_html__( 'Header Navigation Manager', 'alaha' ),
                'subtitle'			=> esc_html__('Organize how you want the layout to appear on the header navigation', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                   'left'  		=> array(
                       'category-menu'		=> esc_html__( 'Category Menu', 'alaha' ),
                    ),
                    'center' 	=> array(
						'primary-menu'			=> esc_html__( 'Primary Menu', 'alaha' ),
					),
					'right' 	=> array(
					),
					'disabled' => array(
						'secondary-menu'	=> esc_html__( 'Secondary Menu', 'alaha' ),	
						'ajax-search'		=> esc_html__( 'Ajax Search', 'alaha' ),
						'myaccount'			=> esc_html__( 'My Account', 'alaha' ),
						'cart'				=> esc_html__( 'Cart', 'alaha' ),					
						'wishlist'			=> esc_html__( 'Wishlist', 'alaha' ),
						'customer-support'	=> esc_html__( 'Customer Support', 'alaha' ),
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-navigation-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Navigation Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '3',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
				'id'       			=> 'header-navigation-center',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Navigation Center', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '9',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-navigation-align',
				'type'     			=> 'switch',
                'title'    			=> esc_html__('Alignment Center','alaha'),
                'subtitle' 	   		=> esc_html__('Alignment center for above section.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 0,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-navigation-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Navigation Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
		)
	) );

	/*
	* Header Sticky Manager options
	*/
    Redux::setSection( $opt_name, array(
        'title'     	 	=> esc_html__( 'Header Sticky Manager', 'alaha' ),
        'id'         		=> 'header-sticky-manager',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       			=> 'sticky-header',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Sticky Header','alaha'),
                'subtitle' 	   		=> esc_html__('Enable sticky header desktop or disable.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'id'       			=> 'header-sticky-manager',
                'type'     			=> 'sorter',
                'title'    			=> esc_html__( 'Header Sticky Manager', 'alaha' ),
				'subtitle'			=> esc_html__('Organize how you want the layout to appear on the header sticky', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                    'left'  	=> array(
                        'logo' 			=> esc_html__( 'Logo', 'alaha' ),
                    ),
                    'center' 	=> array(
						'primary-menu'		=> esc_html__( 'Primary Menu', 'alaha' ),
					),
					'right' 	=> array(
						'myaccount'		=> esc_html__( 'My Account', 'alaha' ),
						'cart'			=> esc_html__( 'Cart', 'alaha' ),						
					),
					'disabled' 	=> array(
                       'category-menu'		=> esc_html__( 'Category Menu', 'alaha' ),
						'ajax-search'		=> esc_html__( 'Ajax Search', 'alaha' ),
						'secondary-menu'	=> esc_html__( 'Secondary Menu', 'alaha' ),	
						'wishlist'			=> esc_html__( 'Wishlist', 'alaha' ),
						'min-search'		=> esc_html__( 'Mini Search', 'alaha' ),
						'currency-switcher'	=> esc_html__( 'Currency Switcher', 'alaha' ),
						'language-switcher'	=> esc_html__( 'Language Switcher', 'alaha' ),
						'customer-support'	=> esc_html__( 'Customer Support', 'alaha' ),
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-sticky-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Sticky Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '3',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
				'id'       			=> 'header-sticky-center',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Sticky Center', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '6',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-sticky-align',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Alignment Center','alaha'),
                'subtitle' 	   		=> esc_html__('Alignment center for above section.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 0,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-sticky-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Sticky Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '3',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
		)
	) );
	
	/*
	* Header Mobile Manager options
	*/
    Redux::setSection( $opt_name, array(
        'title'     	 	=> esc_html__( 'Header Mobile Manager', 'alaha' ),
        'id'         		=> 'header-mobile',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'    			=> 'header-mobile-info',
                'type'  			=> 'info',
				'notice' 			=> false,
                'title' 			=> esc_html__( 'Header Mobile Manager', 'alaha' ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),			
			array(
                'id'       			=> 'header-mobile-manager',
                'type'     			=> 'sorter',
                'title'    			=> esc_html__( 'Header Mobile Manager', 'alaha' ),
				'subtitle'			=> esc_html__('Organize how you want the layout to appear on the header mobile', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                    'left'  	=> array(
						'mobile-navbar'		=> esc_html__( 'Mobile Nav', 'alaha' ),
						'logo'				=> esc_html__( 'Logo', 'alaha' ),						
                    ),
					'center' 	=> array(
					),
					'right' 	=> array(
						'myaccount'			=> esc_html__( 'My Account', 'alaha' ),
						'cart'				=> esc_html__( 'Cart', 'alaha' ),
					),
					'disabled' 	=> array(						
                        'wishlist'			=> esc_html__( 'Wishlist', 'alaha' ),
						'min-search'		=> esc_html__( 'Mini Search', 'alaha' ),
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-mobile-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '6',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			
			array(
				'id'       			=> 'header-mobile-center',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Center', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-mobile-align',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Alignment Center','alaha'),
                'subtitle' 	   		=> esc_html__('Alignment center for above section.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 1,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-mobile-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '6',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-mobile-search',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Ajax Search','alaha'),
                'subtitle' 			=> esc_html__('Show ajax search in mobile header.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 1,
            ),
			array(
                'id'    			=> 'header-mobile-sticky-info',
                'type'  			=> 'info',
				'notice' 			=> false,
                'title' 			=> esc_html__( 'Header Mobile Sticky Manager', 'alaha' ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			
			array(
                'id'       			=> 'sticky-header-tablet',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('On Tablet ( width < 992px )','alaha'),
                'subtitle' 	  		=> esc_html__('Enable sticky header on tablet width < 992px or disable.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'id'       			=> 'sticky-header-mobile',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('On Mobile ( width < 480px )','alaha'),
                'subtitle' 	 		=> esc_html__('Enable sticky header mobile width < 480px or disable.','alaha'),
                'on'       			=> esc_html__('Enable','alaha'),
				'off'      			=> esc_html__('Disable','alaha'),
				'default'  			=> 0,
            ),
			array(
                'id'       			=> 'header-mobile-sticky-manager',
                'type'     			=> 'sorter',
                'title'    			=> esc_html__( 'Header Mobile Sticky Manager', 'alaha' ),
				'description'		=> esc_html__('Organize how you want the layout to appear on the header mobile sticky', 'alaha'),
				'full_width' 		=> true,
                'options'  			=> array(
                    'left'  	=> array(
						'mobile-navbar'		=> esc_html__( 'Mobile Nav', 'alaha' ),					
                    ),
                    'center' 	=> array(
						'ajax-search'		=> esc_html__( 'Ajax Search', 'alaha' ),
					),
					'right' 	=> array(
						'cart'				=> esc_html__( 'Cart', 'alaha' ),
					),
					'disabled' 	=> array(						
						'logo'				=> esc_html__( 'Logo', 'alaha' ),	
						'myaccount'			=> esc_html__( 'My Account', 'alaha' ),
                        'wishlist'			=> esc_html__( 'Wishlist', 'alaha' ),
						'min-search'		=> esc_html__( 'Mini Search', 'alaha' ),
					),
                ),
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-mobile-sticky-left',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Sticky Left', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '2',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
				'id'       			=> 'header-mobile-sticky-center',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Sticky Center', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '8',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
			array(
                'id'       			=> 'header-mobile-sticky-align',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Alignment Center','alaha'),
                'subtitle' 	   		=> esc_html__('Alignment center for above section.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 1,
				'required' 			=> array( 'header-select', '=', 'builder' ),
            ),
			array(
				'id'       			=> 'header-mobile-sticky-right',
				'type'     			=> 'select',
				'title'    			=> esc_html__( 'Header Mobile Sticky Right', 'alaha' ),
				'options' 			=> array(
					'1'  => esc_html__( '1 column - 1/12', 'alaha' ),
					'2'  => esc_html__( '2 columns - 1/6', 'alaha' ),
					'3'  => esc_html__( '3 columns - 1/4', 'alaha' ),
					'4'  => esc_html__( '4 columns - 1/3', 'alaha' ),
					'5'  => esc_html__( '5 columns - 5/12', 'alaha' ),
					'6'  => esc_html__( '6 columns - 1/2', 'alaha' ),
					'7'  => esc_html__( '7 columns - 7/12', 'alaha' ),
					'8'  => esc_html__( '8 columns - 2/3', 'alaha' ),
					'9'  => esc_html__( '9 columns - 3/4', 'alaha' ),
					'10' => esc_html__( '10 columns - 5/6', 'alaha' ),
					'11' => esc_html__( '11 columns - 11/12)', 'alaha' ),
					'12' => esc_html__( '12 columns - 1/1', 'alaha' ),
				),
				'default'  			=> '2',
				'required' 			=> array( 'header-select', '=', 'builder' ),
			),
		)
	) );
	/*
	* Header Styles
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Ajax Search', 'alaha' ),
        'id'         		=> 'header-ajax-search',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       			=> 'header-ajax-search-style',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'Ajax Search Style', 'alaha' ),
				'subtitle' 	   		=> esc_html__('Select ajax search box style.','alaha'),
                'options'  			=> array(
					'ajax-search-style-1' 	=> array(
                        'alt' 	=> '1',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/search/1.jpg'
                    ), 
					'ajax-search-style-2' 	=> array(
                        'alt' 	=> '2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/search/2.jpg'
                    ), 
					'ajax-search-style-3' 	=> array(
                        'alt' 	=> '2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/search/3.jpg'
                    ), 
					'ajax-search-style-4' 	=> array(
                        'alt' 	=> '2',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/search/4.jpg'
                    ), 
                ),
                'default'  			=> 'ajax-search-style-1',
            ),
			array(
                'id'       			=> 'ajax-search-shape',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__( 'Ajax Search Shape', 'alaha' ),
				'subtitle' 			=> esc_html__('Select ajax search box shape.','alaha'),
                'options'  			=> array(
                    'ajax-search-square'	=> esc_html__('Square', 'alaha' ),
                    'ajax-search-radius' 	=> esc_html__('Radius', 'alaha' ),
                ),
                'default'  			=> 'ajax-search-square',
            ),
			array(
                'id'       			=> 'search-content-type',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__( 'Search Content Type', 'alaha' ),
				'subtitle'     		=> esc_html__('Select content type you want to use in the search box.','alaha'),
                'options'  			=> array(
                    'all'			=> esc_html__('All', 'alaha' ),
                    'product' 		=> esc_html__('Product', 'alaha' ),
                    'post' 			=> esc_html__('Post', 'alaha' ),
                    'portfolio' 	=> esc_html__('Portfolio', 'alaha' ),
                ),
                'default'  			=> 'product',
            ),
			array(
                'id'       			=> 'categories-dropdow',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Categories Dropdown','alaha'),
                'subtitle' 			=> esc_html__('Show categories dropdow in search form.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 1,
            ),
			array(
                'id'       			=> 'search-categories',
                'type'     			=> 'radio',
                'title'    			=> esc_html__('Search Categories Dropdown','alaha'),
                'subtitle'     		=> esc_html__('Display categories in search categories dropdow.','alaha'),
                'options'  			=> array(
					'all' 	 	=> esc_html__('Show All Categories','alaha'),
					'parent' 	=> esc_html__('Only Parent(top level) Categories','alaha'),
				),
				'default'  			=> 'all',
				'required' 			=> array( 'categories-dropdow', '=', 1 ),
            ),
			array(
                'id'       			=> 'categories-hierarchical',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Show Categories Hierarchical','alaha'),
                'subtitle' 	   		=> esc_html__('Show categories in hierarchical (Must be need to select above option Show All Categories).','alaha'),
                'on'       			=> esc_html__('On','alaha'),
				'off'      			=> esc_html__('Off','alaha'),
				'default'  			=> 0,
				'required' 			=> array( 'search-categories', '=', 'all' )
            ),
			array(
                'id'       			=> 'search-placeholder-text',
                'type'     			=> 'text',
                'title'    			=> esc_html__('Search Palceholder Text','alaha'),
                'subtitle'     		=> esc_html__('Enter search palceholder text','alaha'),
				'default'  			=> 'Search for products, categories, brands, sku...',
            ),
			array(
                'id'       			=> 'search-trending',
                'type'     			=> 'switch',
                'title'    			=> esc_html__('Trending Search','alaha'),
                'subtitle' 	   		=> esc_html__('Enable trending search.It will show when focus on search box.','alaha'),
                'on'       			=> esc_html__('Yes','alaha'),
				'off'      			=> esc_html__('No','alaha'),
				'default'  			=> 0,
            ),
			array(
				'id'       			=> 'search-trending-categories',
				'type'     			=> 'select',
				'multi'    			=> true,
				'data' 	   			=> 'terms',
				'args' 				=> array( 'taxonomies'=>'product_cat','args'=> array( 'hide_empty' => 1,'parent' => 0 ) ),
				'title'    			=> esc_html__('Trending Categories', 'alaha'),
				'subtitle'     		=> esc_html__( 'Select your trending search categories.', 'alaha' ),
				'placeholder' 		=> esc_attr__('Choose product categories','alaha'),
				'required' 			=> array( 'search-trending', '=', 1),
			),
		),
	) );

	/*
	* Page Title
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page Title', 'alaha' ),
        'id'         => 'page-title',
		'icon'		 => 'el el-icon-website',
        'fields'     => array(
			array(
                'id'       		=> 'page-title-layout',
                'type'     		=> 'image_select',
                'title'    		=> esc_html__( 'Page Title Layout', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Select page title layout.Disable for hide title area', 'alaha' ),
                'options'  		=> array(
                    'left' => array(
                        'title' => 'Default',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/page-title-default.png',
                    ),
					'center' => array(
                        'title' => 'Centered',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/page-title-centered.png',
                    ),
					'disable' => array(
                        'title' => 'Disable',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/page-title-none.png',
                    )
                ),
                'default'  		=> 'center',
            ),
			array(
                'id'       		=> 'page-title',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Page Title', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Show/Hide page title.', 'alaha' ),
                'default'  		=> 1,
                'on'       		=> esc_html__('Show','alaha'),
                'off'      		=> esc_html__('Hide','alaha'),
            ),
			array(
                'id'       		=> 'page-breadcrumbs',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Breadcrumbs', 'alaha' ),
                'subtitle'    	=> esc_html__( 'Show/Hide the breadcrumbs.', 'alaha' ),
                'default'  		=> 1,
                'on'      		=> esc_html__('Show','alaha'),
                'off'      		=> esc_html__('Hide','alaha'),
            ),
			array(
                'id'       		=> 'breadcrumbs-delimiter',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Breadcrumbs Delimiter', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Select breadcrumb seperator', 'alaha' ),
                'options'  		=> array(
                    'forward-slash' 	=> esc_html__('/', 'alaha' ),
                    'greater-than'		=> esc_html__('>', 'alaha' ),
                ),
                'default'  		=> 'forward-slash',
            ),
		)
	) );
			
	/*
	* Footer
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Footer', 'alaha' ),
        'id'         		=> 'footer',
		'icon'		 		=> 'el el-photo',
        'fields'     		=> array(
			array(
                'id'       		=> 'site-footer',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Footer','alaha'),
				'subtitle'    	=> esc_html__( 'Show/Hide website footer.', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'footer-layout',
                'type'     		=> 'image_select',
                'title'    		=> esc_html__( 'Footer Layout', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Select footer layout.', 'alaha' ),
                'options'  		=> array(
                    '1' => array(
                        'title' 	=> esc_html__( 'Layout 1', 'alaha'),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/footer-1.png',
                    ),
					'2' => array(
                        'title' 	=> esc_html__( 'Layout 2', 'alaha'),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/footer-2.png',
                    ),
					'3' => array(
                        'title' 	=> esc_html__( 'Layout 3', 'alaha'),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/footer-3.png',
                    ),					
					'4' => array(
                        'title' 	=> esc_html__( 'Layout 4', 'alaha'),
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/footer-4.png',
                    )
                ),
                'default'  			=> '2',
				'required'			=> array( 'site-footer', '=', 1 )
            ),
			array(
                'id'       		=> 'footer-widget-collapse',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Collapse Widgets on Mobile', 'alaha'),
				'subtitle'    	=> esc_html__( 'Yes/No collapse footer widgets on mobile device.', 'alaha' ),
                'on'       		=> esc_html__( 'Yes', 'alaha' ),
				'off'      		=> esc_html__( 'No', 'alaha' ),
				'default'  		=> 0,
				'required'		=> array( 'site-footer', '=', 1 )
            ),
		)
	) );
	
	/*
	* Footer Copyright
	*/
	Redux::setSection( $opt_name, array(
        'title'      		=> esc_html__( 'Footer Copyright', 'alaha' ),
        'id'         		=> 'section-footer-copyright',
		'subsection'		=> true,
        'fields'     		=> array(
			array(
                'id'       		=> 'footer-copyright',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Copyright','alaha'),
				'subtitle'    	=> esc_html__( 'Show/Hide website copyright.', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1
            ),
			array(
                'id'       		=> 'copyright-layout',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Copyright Layout', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Select copyright layout.', 'alaha' ),
                'options'  		=> array(
                    'columns' 		=> esc_html__('Columns', 'alaha' ),
                    'centered'		=> esc_html__('Centered', 'alaha' ),
                ),
                'default'  		=> 'columns',
				'required'		=> array( 'footer-copyright', '=', 1 )
            ),
			array(
                'id'       		=> 'copyright-text',
                'type'     		=> 'textarea',
				'title'    		=> esc_html__( 'Copyright Text', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Enter copyright text.', 'alaha' ),
				'default'  		=> wp_kses_post('Stroyka &copy; 2019 by <a href="https://stroykas.com/" target="_blank">stroykas</a> All Rights Reserved.'),
				'required'		=> array( 'footer-copyright', '=', 1 )
            ),
			array(
                'id'       		=> 'payment-logo',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Payment Logo','alaha'),
				'subtitle'    	=> esc_html__( 'Show/Hide payment logo.', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 0,
				'required'		=> array( 'footer-copyright', '=', 1 )
				
            ),
			array(
                'id'      		=> 'payment-logo-img',
                'type'     		=> 'media',
                'url'      		=> false,
                'title'    		=> esc_html__( 'Payment Logo Image', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Upload payment logo image.', 'alaha' ),
                'compiler' 		=> 'true',
				'default'  		=> array(),
				'required' 		=> array( 'payment-logo', '=', 1 )
			),
		)
	) );

	/*
	* Woocommerce
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Woocommerce', 'alaha' ),
        'id'         => 'woocommerce',
		'icon'		 => 'el el-shopping-cart',
        'fields'     => array(
			array(
                'id'       		=> 'order-tracking-page',
                'type'     		=> 'select',
                'data'     		=> 'pages',
                'title'    		=> esc_html__( 'Order Tracking Page', 'alaha' ),
                'subtitle' 		=> esc_html__( 'Set your order tracking page.', 'alaha' ),
            ),
			array(
                'id'       		=> 'product-search-by-sku',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Search By Product SKU','alaha'),
				'subtitle'     	=> esc_html__( 'Ajax search product by  sku.', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'manage-password-strength',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Manage Password Strength','alaha'),
				'subtitle'     	=> esc_html__( 'Reduce the strength requirement on the woocommerce user login/signup password ', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 0,
            ),
			array(
                'id'       		=> 'user-password-strength',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'User Password Strength', 'alaha' ),
                'options'  		=> array(
                    '3' 	=> esc_html__('Strong (default)', 'alaha' ),
                    '2' 	=> esc_html__('Medium', 'alaha' ),
					'1' 	=> esc_html__('Weak', 'alaha' ),
					'0' 	=> esc_html__('Very Weak', 'alaha' ),
                ),
                'default'  		=> '3',
				'required'		=> array( 'manage-password-strength', '=', 1 )
            ),
			array(
                'id'       		=> 'single-line-product-title',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Single Line Title','alaha'),
				'subtitle' 	   	=> esc_html__( 'Show product/category/widget  title in single line.', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'product-labels',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Product Labels','alaha'),
				'subtitle' 	   	=> esc_html__( 'Show labels sale, featured, new and out of stock on product.', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'sale-product-label',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Sale Product Label','alaha'),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'product-labels', '=', 1 )
            ),
			array(
                'id'      		=> 'sale-product-label-after-price',
                'type'     		=> 'button_set',
				'desc' 			=> esc_html__( 'Show sale product label after price or on product image in shop/listing page.', 'alaha' ),
                'options'  		=> array(
                    'after-price' 		=> esc_html__('After Price','alaha'),
                    'on-product-image'	=> esc_html__('On Product Image','alaha'),
                ),
                'default'  		=> 'after-price',
				'required' 		=> array( 'sale-product-label', '=', 1 )
            ),
			array(
                'id'      		=> 'sale-product-label-text-options',
                'type'     		=> 'button_set',
				'desc' 			=> esc_html__( 'sale product label in percentage or text.', 'alaha' ),
                'options'  		=> array(
                    'percentage' 	=> esc_html__('Percentage','alaha'),
                    'text' 			=> esc_html__('Text','alaha'),
                ),
                'default'  		=> 'percentage',
				'required' 		=> array( 'sale-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'sale-product-label-percentage-text',
                'type'     		=> 'text',
				'desc'   		=> esc_html__('Sale label percentage text.','alaha'),
				'default'  		=> esc_html__('Off','alaha'),
				'required' 		=> array( 'sale-product-label-text-options', '=', 'percentage' )
            ),
			array(
                'id'       		=> 'sale-product-label-text',
                'type'     		=> 'text',
                'desc'    		=> esc_html__('Sale product label text.','alaha'),
				'default'  		=> esc_html__('Sale','alaha'),
				'required' 		=> array( 'sale-product-label-text-options', '=', 'text' )
            ),
			array(
                'id'       		=> 'sale-product-label-color',
                'type'     		=> 'color',
                'desc'    		=> esc_html__( 'Sale product label color.', 'alaha' ),
                'default'  		=> '#82B440',
				'required' 		=> array( 'sale-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'product-new-label',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('New Product Label','alaha'),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'product-labels', '=', 1 )
            ),
			array(
                'id'       		=> 'new-product-label-text',
                'type'     		=> 'text',
                'desc'    		=> esc_html__('New product label text.','alaha'),
				'default'  		=> esc_html__('New','alaha'),
				'required' 		=> array( 'product-new-label', '=', 1 )
            ),
			array(
                'id'        	=> 'product-newness-days',
                'type'      	=> 'slider',
                'desc'      	=> esc_html__( 'Enter number of days to newness.', 'alaha' ),
                'default'   	=> 30,
                'min'       	=> 1,
                'step'      	=> 1,
                'max'       	=> 90,
                'display_value' => 'text',
				'required' 		=> array( 'product-new-label', '=', 1 )
            ),
			array(
                'id'      		=> 'new-product-label-color',
                'type'     		=> 'color',
                'desc'    		=> esc_html__( 'New product label color.', 'alaha' ),
                'default'  		=> '#388e3c',
				'required' 		=> array( 'new-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'featured-product-label',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Featured Product Label','alaha'),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'product-labels', '=', 1 )
            ),
			array(
                'id'       		=> 'featured-product-label-text',
                'type'     		=> 'text',
                'desc'    		=> esc_html__('Featured product label text.','alaha'),
				'default'  		=> esc_html__('Featured','alaha'),
				'required' 		=> array( 'featured-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'featured-product-label-color',
                'type'     		=> 'color',
                'desc'     		=> esc_html__( 'Featured product label color.', 'alaha' ),
                'default'  		=> '#ff9f00',
				'required' 		=> array( 'featured-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'outofstock-product-label',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Out Of Stock Product Label','alaha'),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'product-labels', '=', 1 )
            ),
			array(
                'id'       		=> 'outofstock-product-label-text',
                'type'     		=> 'text',
                'desc'     		=> esc_html__('out of stock product label text.','alaha'),
				'default'  		=> esc_html__('Out Of Stock','alaha'),
				'required' 		=> array( 'outofstock-product-label', '=', 1 )
            ),
			array(
                'id'       		=> 'outofstock-product-label-color',
                'type'     		=> 'color',
                'desc'    		=> esc_html__( 'Out of stock product label color.', 'alaha' ),
                'default'  		=> '#ff6161',
				'required' 		=> array( 'outofstock-product-label', '=', 1 )
            ),
			array(
                'id'        	=> 'outofstock-product-opacity',
                'type'     		=> 'slider',
                'desc'      	=> esc_html__( 'Apply opacity on out of stock product.', 'alaha' ),
                'default'   	=> .6,
                'min'       	=> .4,
                'step'      	=> .1,
                'max'       	=> 1,
                'resolution' 	=> 0.1,
                'display_value' => 'text',
				'required' 		=> array( 'outofstock-product-label', '=', 1 )
            ),
		),
	) );
	
	/*
	* Woocommerce Shop Page
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Shop Page', 'alaha' ),
        'id'         => 'shop-page',
		'icon'		 => 'el el-shopping-cart',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       	=> 'shop-page-layout',
                'type'     	=> 'image_select',
                'title'    	=> esc_html__( 'Page Layout', 'alaha' ),
                'subtitle' 	=> esc_html__( 'Select shop/listing page layout with sidebar postion.', 'alaha' ),
                'options'  	=> array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => 'Left Sidebar',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => 'Right Sidebar',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  	=> 'left-sidebar'
            ),
			array(
                'id'       	=> 'shop-page-sidebar-width',
                'type'     	=> 'button_set',
                'title'    	=> esc_html__( 'Sidebar Width', 'alaha' ),
                'subtitle'  => esc_html__( 'Select sidebar size.', 'alaha' ),
                'options'  	=> array(
					'3'	=> esc_html__('Medium','alaha'),
					'4'	=> esc_html__('Large','alaha'),
				),
                'default'  	=> '3',
				'required' 	=> array( 'shop-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       	=> 'shop-page-sidebar-widget',
                'type'     	=> 'select',
                'title'    	=> esc_html__('Sidebar Widget Area','alaha'),
				'subtitle'  => esc_html__( 'Select sidebar for shop page.', 'alaha' ),
                'data'     	=> 'sidebars',
                'default'  	=> 'shop-page-sidebar',
                'required' 	=> array( 'shop-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       		=> 'shop-page-title',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Page Title', 'alaha' ),
				'subtitle'    	=> esc_html__( 'Show/Hide shop page title.', 'alaha' ),
                'default'  		=> 1,
                'on'       		=> esc_html__('Show','alaha'),
                'off'      		=> esc_html__('Hide','alaha'),
            ),
			array(
                'id'       		=> 'products-view-icon',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products View Mode Icon','alaha'),
				'subtitle'      => esc_html__( 'Products view mode icon show or hide on product header', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-default-view',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Products Default View', 'alaha' ),
                'options'  		=> array(
                    'grid-view'		=> esc_html__('Grid', 'alaha' ),
                    'list-view' 	=> esc_html__('List', 'alaha' ),
                ),
                'default'  		=> 'grid-view',
            ),
			array(
                'id'            => 'products-per-page',
                'type'          => 'slider',
                'title'         => esc_html__('Products Per Page','alaha'),
                'subtitle'      => esc_html__('Show number of products per page.','alaha'),
                'default'       => 12,
                'min'           => 6,
                'step'          => 1,
                'max'           => 120,
                'display_value' => 'text',
            ),
			array(
                'id'       		=> 'products-per-page-dropdown',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Per Page Dropdown','alaha'),
				'subtitle'     	=> esc_html__( 'Show products per page dropdown on products header', 'alaha' ),
                'on'       		=> esc_html__('Show','alaha'),
				'off'      		=> esc_html__('Hide','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-per-page-number',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Products Per Page Variations', 'alaha' ),
				'subtitle'     	=> esc_html__('Add product variations by comma. Ex. 9,12,24,36,48','alaha'),
                'default'  		=> '6,9,12,24,36,48',
				'required' 		=> array( 'products-per-page-dropdown', '=', 1 )
            ),			
			array(
                'id'       		=> 'ajax-filter',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Ajax Filter','alaha'),
				'subtitle' 	   	=> esc_html__( 'Enable ajax filter on shop and product archive pages.', 'alaha' ),
                'on'       		=> esc_html__('Enable','alaha'),
				'off'      		=> esc_html__('Disable','alaha'),
				'default'  		=> 0,
            ),
			array(
                'id'       		=> 'shop-top-filter',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Shop Top Filter','alaha'),
				'subtitle' 	   	=> esc_html__( 'Enable shop filters on products top.', 'alaha' ),
                'on'       		=> esc_html__('Enable','alaha'),
				'off'      		=> esc_html__('Disable','alaha'),
				'default'  		=> 0,
            ),
			array(
                'id'       		=> 'products-columns',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Products Columns', 'alaha' ),
				'subtitle'      => esc_html__( 'How many products you want to show per row?', 'alaha' ),
                'options'  		=> array(
                    2		=> esc_html__('2', 'alaha' ),
                    3	 	=> esc_html__('3', 'alaha' ),
					4	 	=> esc_html__('4', 'alaha' ),
					5	 	=> esc_html__('5 In full width', 'alaha' ),
					6	 	=> esc_html__('6 In full width', 'alaha' ),
                ),
                'default'  		=> 3,
            ),
			array(
                'id'       		=> 'products-columns-mobile',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Products Columns On Mobile', 'alaha' ),
				'subtitle'      => esc_html__( 'How many products you want to show per row on mobile?', 'alaha' ),
                'options'  		=> array(
                    1		=> esc_html__('1', 'alaha' ),
                    2	 	=> esc_html__('2', 'alaha' ),
                ),
                'default'  		=> 2,
            ),
			array(
                'id'       => 'products-pagination-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Products Pagination', 'alaha' ),
				'subtitle' => esc_html__('Select product pagination type.','alaha'),
                'options'  => array(
					'default'			=> esc_html__('Default','alaha'),
					'infinity-scroll'	=> esc_html__('Infinity Scroll','alaha'),
					'load-more-button'	=> esc_html__('Load More','alaha'),
				),
                'default'  => 'default',
            ),
			array(
                'id'       => 'products-pagination-load-more-button-text',
                'type'     => 'text',
                'title'    => esc_html__( 'Load More Button Text', 'alaha' ),
				'subtitle' => esc_html__('Enter load more button text.','alaha'),
                'default'  => 'Load More Products',
				'required' => array( 'products-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
			array(
                'id'       => 'products-pagination-finished-message',
                'type'     => 'text',
                'title'    => esc_html__( 'Finished Message', 'alaha' ),
				'subtitle' => esc_html__('Text to display when no additional products are available.','alaha'),
                'default'  => 'No More Products Available',
				'required' => array( 'products-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
			
		),
	) );
	
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Product Styles', 'alaha' ),
        'id'         => 'product-styles',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       		=> 'product-style',
                'type'     		=> 'image_select',
				'full_width' 	=> true,
                'title'    	=> esc_html__( 'Products Hover Style', 'alaha' ),
                'options'  	=> array(
                    'product-style-1' => array(
                        'alt' 	=> 'Products Hover Style 1',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-1-hover.jpg',
                    ),
					'product-style-2' => array(
                        'alt' 	=> 'Products Hover Style 2',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-2-hover.jpg',
                    ),
                    'product-style-3' => array(
                        'alt' 	=> 'Products Hover Style 3',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-3-hover.jpg',
                    ), 
					'product-style-4' => array(
                        'alt' 	=> 'Products Hover Style 4',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-4-hover.jpg',
                    ),
					'product-style-5' => array(
                        'alt' 	=> 'Products Hover Style 5',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-5-hover.jpg',
                    ),
                ),
                'default'  	=> 'product-style-1',
            ),
			array(
                'id'       		=> 'products-hover-image',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Hover Image','alaha'),
				'subtitle'      => esc_html__( 'Show product hover image on products.', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-category',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Category','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-title',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products title','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-rating',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Rating','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-rating-style',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Products Rating Style', 'alaha' ),
                'options'  		=> array(					
                    'fancy-rating'	 	=> esc_html__('Fancy', 'alaha' ),
                    'simple-rating'		=> esc_html__('Simple', 'alaha' ),
                ),
                'default'  		=> 'fancy-rating',
				'required' 		=> array( 'products-rating', '=', 1 )
            ),
			array(
                'id'       		=> 'products-rating-count',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Rating Count','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'products-rating', '=', 1 )
            ),
			array(
                'id'       		=> 'products-rating-histogram',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Rating Histogram','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
				'required' 		=> array( 'products-rating', '=', 1 )
            ),
			array(
                'id'       		=> 'products-price',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Price','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-variations',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Hover Variations','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'products-short-description',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Products Short Description','alaha'),
				'subtitle'      => esc_html__( 'Show product short description in list view.', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
		),
	) );
	
	/*
	* Product Catalog Mode
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Catalog Mode', 'alaha' ),
        'id'         => 'product-catalog-mode',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       		=> 'catalog-mode',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Catalog Mode','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 0,
            ),
			array(
                'id'       		=> 'product-cart-button',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Cart Button','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'open-product-page-new-tab',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Open Product In New Tab','alaha'),
				'subtitle'      => esc_html__( 'Open product page in new tab.', 'alaha' ),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 0,
            ),
			array(
                'id'       		=> 'product-wishlist-button',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Wishlist Button','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'product-compare-button',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Compare Button','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'product-quickview-button',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Quickview Button','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'single-product-quick-buy',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Quick Buy Button','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 0,
            ),
			array(
                'type'      		=> 'text',
                'id'        		=> 'product-quickbuy-button-text',
                'title'     		=> esc_html__( 'Quick Buy Button Text', 'alaha' ),
                'default'     		=> 'Buy Now',
                'required'  		=> array( 'single-product-quick-buy', '=', '1' ),
            ),
		),
	) );
	
	/*
	* Product category Page
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Categories Page', 'alaha' ),
        'id'         => 'product-categories-page',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       		=> 'category-style',
                'type'     		=> 'image_select',
                'title'    		=> esc_html__( 'Category Style', 'alaha' ),
                'subtitle'  	=> esc_html__( 'Select category style', 'alaha' ),
                'options'  		=> array(                    
                    'category-style-1' => array(
                        'alt' 	=> 'Category Style 1',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/category-1-hover.jpg',
                    ),
					'category-style-2' => array(
                        'alt' 	=> 'Category Style 2',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/category-2-hover.jpg',
                    ),
                ),
                'default'  	=> 'category-style-1',
            ),
		),
	) );

	/*
	* Product login to see prices
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Login To See Price', 'alaha' ),
        'id'         => 'section-login-to-see-price',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'login-to-see-price',
                'type'     => 'switch',
                'title'    => esc_html__( 'Login To See Price', 'alaha' ),
				'subtitle' => esc_html__('Only logged in users can see the pricing.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
                'default'  => 0,
            ),
		),
	) );
	
	/*
	* Single Product Page
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Product Page', 'alaha' ),
        'id'         => 'single-product-page',
		'icon'		 => 'el el-shopping-cart',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       	=> 'product-page-layout',
                'type'     	=> 'image_select',
                'title'    	=> esc_html__( 'Page Layout', 'alaha' ),
                'subtitle' 	=> esc_html__( 'Select product page layout with sidebar postion.', 'alaha' ),
                'options'  	=> array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  	=> 'full-width'
            ),
			array(
                'id'       	=> 'product-page-sidebar-width',
                'type'     	=> 'button_set',
                'title'    	=> esc_html__( 'Sidebar Width', 'alaha' ),
				'subtitle' 	=> esc_html__('Select sidebar size.','alaha'),
                'options'  	=> array(
					'3'	=> esc_html__('Medium','alaha'),
					'4'	=> esc_html__('Large','alaha'),
				),
                'default'  	=> '3',
				'required' 	=> array( 'product-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       	=> 'product-page-sidebar-widget',
                'type'     	=> 'select',
                'title'    	=> esc_html__('Sidebar Widget Area','alaha'),
				'subtitle' 	=> esc_html__('Select sidebar for product page.','alaha'),
                'data'     	=> 'sidebars',
                'default'  	=> 'product-page-sidebar',
                'required' 	=> array( 'product-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'sticky-product-image',
                'type'     => 'switch',
                'title'    => esc_html__( 'Sticky Product Image', 'alaha' ),
				'subtitle' => esc_html__('When you scroll the product page at this time you want to stick product image part or not.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
                'default'  => 1,
            ),
			array(
                'id'       => 'sticky-product-summary',
                'type'     => 'switch',
                'title'    => esc_html__( 'Sticky Product Summary', 'alaha' ),
				'subtitle' => esc_html__('When you scroll the product page at this time you want to stick product summary part or not.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
                'default'  => 1,
            ),
		),
	) );
	
	/*
	* Product Images/Gallery
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Images/Gallery', 'alaha' ),
        'id'         => 'product-images-gallery',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       	=> 'product-gallery-style',
                'type'     	=> 'image_select',
                'title'    	=> esc_html__( 'Gallery Style', 'alaha' ),
                'options'  	=> array(
                    'product-gallery-left' 	=> array(
                        'title' 	=> 'Gallery Left',
                        'alt' 	=> 'Gallery Left',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-gallery-left.png',
                    ),                   
                    'product-gallery-bottom' 	=> array(
                        'title' 	=> 'Gallery Bottom',
                        'alt' 	=> 'Gallery Bottom',
                        'img' 	=> ALAHA_ADMIN_IMAGES . 'layout/product-gallery-bottom.png',
                    ), 
                ),
                'default'  	=> 'product-gallery-left'
            ),
			array(
                'id'       => 'product-gallery-zoom',
                'type'     => 'switch',
                'title'    => esc_html__( 'Product Gallery Zoom', 'alaha' ),
                'on'       => esc_html__('Enable','alaha'),
				'off'      => esc_html__('Disable','alaha'),
                'default'  => 1,
            ),
		),
	) );
	
	/*
	* Product Summary
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Summary', 'alaha' ),
        'id'         => 'product-summary',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'single-product-breadcrumbs',
                'type'     => 'switch',
                'title'    => esc_html__('Product Breadcrumbs','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Product Navigation','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-rating',
                'type'     => 'switch',
                'title'    => esc_html__('Product Rating','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-countdown',
                'type'     => 'switch',
                'title'    => esc_html__('Product Countdown','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-countdown-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Countdown Style', 'alaha' ),
                'options'  => array(
					'countdown-box'		=> esc_html__('Box','alaha'),
					'countdown-text'  	=> esc_html__('Text','alaha'),					
				),
                'default'  => 'countdown-box',
				'required' => array( 'single-product-countdown', '=', 1 )
            ),
			array(
                'id'        => 'single-product-countdown-tag',
                'type'      => 'text',
                'title'     => esc_html__( 'Countdown Tag', 'alaha' ),
                'default' 	=> 'Special price ends in less than',
				'required' 	=> array( 'single-product-countdown-style', '=', 'countdown-text' )
            ),
			array(
                'id'      		=> 'sale-single-product-label-after-price',
                'type'     		=> 'button_set',
				'title'     	=> esc_html__( 'Sale Product Label', 'alaha' ),
				'desc' 			=> esc_html__( 'Show sale product label after price or on product image in product page.', 'alaha' ),
                'options'  		=> array(
                    'after-price' 		=> esc_html__('After Price','alaha'),
                    'on-product-image'	=> esc_html__('On Product Image','alaha'),
                ),
                'default'  		=> 'after-price',
            ),
			array(
                'id'       => 'single-product-price-summary',
                'type'     => 'switch',
                'title'    => esc_html__('Product Price Summary','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       		=> 'single-product-availability',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Product Availability','alaha'),
				'subtitle'     	=> esc_html__('Show Product availability message like In Stock, Out Of Stock, Hurry left, etc...','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'        	=> 'single-product-availability-instock-msg',
                'type'      	=> 'text',
                'title'     	=> esc_html__( 'In Stock Message', 'alaha' ),
                'default' 		=> 'In Stock',
				'required' 		=> array( 'single-product-availability', '=', 1 )
            ),
			array(
                'id'            => 'single-product-availability-lowstock-qty',
                'type'          => 'slider',
                'title'         => esc_html__('Low Stock Qty','alaha'),
                'subtitle'		=> esc_html__('How many numbers you want to display below low stock messages. like Hurry, Only {qty} left.','alaha'),
                'default'       => 5,
                'min'           => 1,
                'step'          => 1,
                'max'           => 25,
                'display_value' => 'text',
				'required' 		=> array( 'single-product-availability', '=', 1 )
            ),
			array(
                'id'        	=> 'single-product-availability-hurry-left-msg',
                'type'      	=> 'text',
                'title'     	=> esc_html__( 'Stock Hurry Left Message', 'alaha' ),
				'subtitle'		=> esc_html__('Default template is: Hurry, Only {qty} left.Here {qty} is number of item available in stock','alaha'),
                'default' 		=> 'Hurry, Only {qty} left.',
				'required' 		=> array( 'single-product-availability', '=', 1 )
            ),
			array(
                'id'        	=> 'single-product-availability-outstock-msg',
                'type'      	=> 'text',
                'title'     	=> esc_html__( 'Out of Stock Message', 'alaha' ),
                'default' 		=> 'Out of Stock',
				'required' 		=> array( 'single-product-availability', '=', 1 )
            ),
			array(
                'id'       => 'single-product-offers',
                'type'     => 'switch',
                'title'    => esc_html__('Product Offers','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-services',
                'type'     => 'switch',
                'title'    => esc_html__('Product Services','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-brands',
                'type'     => 'switch',
                'title'    => esc_html__('Product Brands','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-short-description',
                'type'     => 'switch',
                'title'    => esc_html__('Product Short Description','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       		=> 'product_add_to_cart_ajax',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Enable AJAX Add To Cart','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'single-product-size-chart',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Size chart','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       		=> 'single-product-meta',
                'type'     		=> 'switch',
                'title'    		=> esc_html__('Product Meta','alaha'),
				'subtitle'     	=> esc_html__('Show or hide product SKU, category, tag, etc...','alaha'),
                'on'       		=> esc_html__('Yes','alaha'),
				'off'      		=> esc_html__('No','alaha'),
				'default'  		=> 1,
            ),
			array(
                'id'       => 'single-product-share',
                'type'     => 'switch',
                'title'    => esc_html__('Product Share','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'product-share-location',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Product Share Location', 'alaha' ),
                'options'  => array(
					'summary-top'		=> esc_html__('Summary Top','alaha'),
					'summary-bottom'  	=> esc_html__('Summary Bottom','alaha'),					
				),
                'default'  => 'summary-top',
				'required' => array( 'single-product-share', '=', 1 )
            ),
		),
	) );

	/*
	* Product Bought Together
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Bought Together', 'alaha' ),
        'id'         => 'product-bought-together',
		'subsection' => true,
        'fields'     => array(
			
			array(
                'id'       => 'single-product-bought-together',
                'type'     => 'switch',
                'title'    => esc_html__('Product Bought Together','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'type'     	=> 'text',
                'id'		=> 'product-bought-together-title',
                'title'		=> esc_html__( 'Bought Together Title', 'alaha' ),
				'default'  	=> 'Frequently Bought Together',
                'required' 	=> array( 'single-product-bought-together', '=', 1 )
            ),
			array(
                'id'       => 'product-bought-together-location',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Bought Together Location', 'alaha' ),
                'options'  => array(
					'summary-bottom'  	=> esc_html__('Summary Bottom','alaha'),
					'after-summary'		=> esc_html__('After Summary','alaha'),					
					'in-tab'  			=> esc_html__('In Tab','alaha'),
				),
                'default'  => 'summary-bottom',
				'required' => array( 'single-product-bought-together', '=', 1 )
            ),			
		),
	) );
	
	/*
	* Product Tags
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Tabs', 'alaha' ),
        'id'         => 'product-tabs',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'single-product-tabs',
                'type'     => 'switch',
                'title'    => esc_html__('Product Tabs','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-product-tabs-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Product Tabs Style', 'alaha' ),
                'options'  => array(
					'tabs'  		=> esc_html__('Tabs','alaha'),
					'accordion'		=> esc_html__('Accordion','alaha'),					
					'toggle'  		=> esc_html__('Toggle','alaha'),
				),
                'default'  => 'tabs',
				'required' => array( 'single-product-tabs', '=', 1 )
            ),
			array(
                'id'       => 'single-product-tabs-location',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Product Tabs Location', 'alaha' ),
                'options'  => array(
					'after-summary'		=> esc_html__('After Summary','alaha'),	
					'summary-bottom'  	=> esc_html__('Summary Bottom','alaha'),
				),
                'default'  => 'after-summary',
				'required' => array( 'single-product-tabs', '=', 1 )
            ),
			array(
                'id'       => 'single-product-tabs-titles',
                'type'     => 'switch',
                'title'    => esc_html__('Product Tabs Titles','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
				'required' => array( 'single-product-tabs', '=', 1 )
            ),
		),
	) );
	
	/*
	* Product Related/Up-Sells/Recently-Viewed
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Related/Up-Sells/Rviewed', 'alaha' ),
        'id'         => 'product-related-upsells-rv',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'upsells-products',
                'type'     => 'switch',
                'title'    => esc_html__('Up Sells Products','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'related-products',
                'type'     => 'switch',
                'title'    => esc_html__('Related Products','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'recently-viewed-products',
                'type'     => 'switch',
                'title'    => esc_html__('Recently Viewed Products','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'            => 'related-upsells-products',
                'type'          => 'slider',
                'title'         => esc_html__('Show Number Of Products','alaha'),
				'subtitle'     	=> esc_html__('How many products you want to display?','alaha'),
                'default'       => 12,
                'min'           => 1,
                'step'          => 1,
                'max'           => 24,
                'display_value' => 'text',
            ),
			array(
                'id'       		=> 'related-upsells-products-columns',
                'type'     		=> 'button_set',
                'title'    		=> esc_html__( 'Products Columns', 'alaha' ),
				'subtitle'     	=> esc_html__('How many products you want to show per row?','alaha'),
                'options'  		=> array('2'=>'2','3'=>'3','4'=>'4','5'=>'5 (In Full Width)','6'=>'6 (In Full Width)'),
                'default'  		=> '4',
            ),
			array(
                'id'       => 'related-upsells-auto-play',
                'type'     => 'switch',
                'title'    => esc_html__('Carousel Autoplay','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'related-upsells-loop',
                'type'     => 'switch',
                'title'    => esc_html__('Carousel Inifnity Loop','alaha'),
                'subtitle' => esc_html__('Enables related/up sells products carousel Inifnity loop. Duplicate last and first products to get loop illusion.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'related-upsells-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Carousel Navigation','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'related-upsells-product-dots',
                'type'     => 'switch',
                'title'    => esc_html__('Carousel Dots Navigation','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
		),
	) );
	
	/*
	* Checkout Page
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Checkout Page', 'alaha' ),
        'id'         => 'section-checkout',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'multi-step-checkout',
                'type'     => 'switch',
                'title'    => esc_html__('Multi Step Checkout','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
		),
	) );
	
	/**
	* Login/Register 
	*/ 
    Redux::setSection( $opt_name, array(
        'title'   => esc_html__( 'Login/Register', 'alaha' ),
		'id'         => 'section-login-register',
		'icon'		 => 'el el-user',
        'fields'  => array(
			array(
				'id'       	=> 'login-information',
				'type'     	=> 'editor',
				'title'    	=> esc_html__( 'Login Information', 'alaha' ),
				'subtitle'	=> esc_html__( 'Display login information in login form.', 'alaha' ),
				'args'   	=> array(
					'teeny'            => true,
				),
				'default'  => esc_html__('Get access to your Orders, Wishlist and Recommendations.', 'alaha'),

			)
		)
    ));
	if ( class_exists( 'WeDevs_Dokan' ) || class_exists( 'WC_Vendors' ) || class_exists( 'WCMp' ) || class_exists( 'WCFMmp' ) ) {
		$vendor_options = alaha_vendor_theme_options();
		/*
		* Vendor Options
		*/
		Redux::setSection( $opt_name, array(
			'title'      => esc_html__( 'Vendor Options', 'alaha' ),
			'id'         => 'vendor-options',
			'icon'		 => 'el-icon-broom',
			'fields'     => $vendor_options,
		) );
	}
	/*
	* Pages options
	*/
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Pages', 'alaha' ),
        'id'         => 'pages-section',
		'icon'		 => 'el el-list-alt',
        'fields'     => array(
			array(
                'id'       => 'page-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Page Layout', 'alaha' ),
                'subtitle' => esc_html__( 'Select page layout with sidebar postion.', 'alaha' ),
                'options'  => array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  => 'full-width'
            ),
			array(
                'id'       => 'page-sidebar-width',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Sidebar Width', 'alaha' ),
                'options'  => array(
					'3'=>esc_html__('Medium','alaha'),
					'4'=>esc_html__('Large','alaha'),
				),
                'default'  => '3',
				'required' => array( 'page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'page-sidebar-widget',
                'type'     => 'select',
                'title'    => esc_html__('Sidebar Widget Area','alaha'),
                'data'     => 'sidebars',
                'default'  => 'sidebar-1',
                'required' => array( 'page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'page-comments',
                'type'     => 'switch',
                'title'    => esc_html__('Page Comments','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
		)
	) );
	
	/*
	* Widget
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Widget', 'alaha' ),
        'id'         => 'section-widget',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       			=> 'widget-title-style',
                'type'     			=> 'image_select',
                'title'    			=> esc_html__( 'Title Style', 'alaha' ),
				'subtitle' 	   		=> esc_html__('Select widget title style.','alaha'),
                'options'  			=> array(
					'widget-title-default' 	=> array(						
                        'title' 	=> 'Default',
                        'alt' 		=> 'Default',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/widget-title/1.jpg'
                    ), 
					'widget-title-bordered-full' 	=> array(
                        'title' 	=> 'Bordered Full',
                        'alt' 		=> 'Bordered Full',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/widget-title/2.jpg'
                    ), 
					'widget-title-bordered-short' 	=> array(
                        'title' 	=> 'Bordered Short',
                        'alt' 		=> 'Bordered Short',
                        'img' 		=> ALAHA_ADMIN_IMAGES . 'layout/widget-title/3.jpg'
                    ),
                ),
                'default'  			=> 'widget-title-bordered-full',
            ),
			array(
                'id'       => 'widget-toggle',
                'type'     => 'switch',
                'title'    => esc_html__( 'Widget Toggle', 'alaha' ),
                'subtitle' => esc_html__( 'Enable page widget toggle or not.', 'alaha' ),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'widget-menu-toggle',
                'type'     => 'switch',
                'title'    => esc_html__( 'Widget Menu Toggle', 'alaha' ),
                'subtitle' => esc_html__( 'Enable page widget menu toggle or not.', 'alaha' ),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'widget-items-hide-max-limit',
                'type'     => 'switch',
                'title'    => esc_html__( 'Enable Widget Items Hide', 'alaha' ),
                'subtitle' => esc_html__( 'Enable widget items hide max limit.', 'alaha' ),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'            => 'number-of-show-widget-items',
                'type'          => 'slider',
                'title'         => esc_html__('Show Number Of Widget Items','alaha'),
                'default'       => 8,
                'min'           => 5,
                'step'          => 1,
                'max'           => 50,
                'display_value' => 'text',
				'required' => array( 'widget-items-hide-max-limit', '=', 1 )
            ),
			array(
                'id'       => 'sidebar-canvas-mobile',
                'type'     => 'switch',
                'title'    => esc_html__( 'Sidebar Canvas In Mobile', 'alaha' ),
                'subtitle' => esc_html__( 'Display sidebar canvas in mobile.', 'alaha' ),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
		),
	) );
	
	/*
	* 404 options 
	*/ 
    Redux::setSection( $opt_name, array(
        'title'   => esc_html__( 'Page 404', 'alaha' ),
        'subsection' => true,
        'fields'  => array(
			array(
				'id'      => 'alaha-404_heading',
				'type'    => 'text',
				'title'   => esc_html__( 'Heading text', 'alaha' ),                    
				'default' => esc_html__('PAGE NOT FOUND', 'alaha'),								  
			),
			array(
				'id'       	=> 'alaha-404_content',
				'type'     	=> 'editor',
				'title'    	=> esc_html__( 'Content body Text', 'alaha' ),
				'subtitle'	=> esc_html__( 'Custom html allow', 'alaha' ),
				'args'   	=> array(
					'teeny'            => true,
				),
				'default'  => esc_html__('Sorry, the page you are looking for is not available. Maybe you want to perform a search?', 'alaha'),

			),
			array(
				'id'      => 'alaha-404_btn_txt',
				'type'    => 'text',
				'title'   => esc_html__( 'Button text', 'alaha' ),                    
				'default' => 'Back To Home?',
								  
			),                   
		)
    ));     
		
	/*
	* Post options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog / Post', 'alaha' ),
        'id'         => 'section-blog',
		'icon'		 => 'el el-edit',
        'fields'     => array(
			array(
                'id'       => 'post-fancy-date',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Fancy Date', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'fancy-date-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Fancy Date Style', 'alaha' ),
                'options'  => array(
					 'fancy-square-date' => array(
                        'alt' => 'Fancy Square Date',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/fancy-squar-date.png',
                    ),
					'fancy-box2-date' => array(
                        'alt' => 'Fancy Box2 Date',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/fancy-box-2-date.png',
                    ), 
                    'fancy-box-date' => array(
                        'alt' => 'Fancy Box Date',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/fancy-box-date.png',
                    ),			
                   					
                ),
                'default'  => 'fancy-square-date',
				'required' => array( 'post-fancy-date', '=', 1 )
            ),
			array(
                'id'       => 'sticky-post-icon',
                'type'     => 'switch',
                'title'    => esc_html__('Sticky Post Icon','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'post-format-icon',
                'type'     => 'switch',
                'title'    => esc_html__('Post Format Icon','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'post-meta',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Meta', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'specific-post-meta',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Specific Post Meta', 'alaha' ),
                'subtitle' => esc_html__( 'Show/hide specific meta.', 'alaha' ),
                'multi'    => true,
                'options'  => array(
                    'post-author' 		=> esc_html__('Author', 'alaha' ),
                    'post-date' 		=> esc_html__('Date', 'alaha' ),
                    'post-category' 	=> esc_html__('Category', 'alaha' ),					
                    'post-tags' 		=> esc_html__('Tags', 'alaha' ),
					'post-comments' 	=> esc_html__('Comments', 'alaha' ),
					'post-views' 		=> esc_html__('Views', 'alaha' ),
					'post-rtime' 		=> esc_html__('Read Time', 'alaha' ),
					'post-share' 		=> esc_html__('Share', 'alaha' ),
					'post-edit' 		=> esc_html__('Edit', 'alaha' ),
                ),
                'default'  => array( 'post-author', 'post-category', 'post-comments', 'post-share' ),
				'required' => array( 'post-meta', '=', 1 )
            ),
			array(
                'id'       => 'post-meta-icon',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Meta Icon', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				'required' => array( 'post-meta', '=', 1 )
            ),
			array(
                'id'       => 'post-meta-separator',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Post Meta Separator', 'alaha' ),
                'options'  => array(
					'meta-separator-slash'	=> esc_html('/'),
					'meta-separator-colon'	=> esc_html(':'),
					'meta-separator-dot'	=> esc_html('.'),
					'meta-separator-bar'	=> esc_html('|'),
					'meta-separator-hyphen'	=> esc_html('-'),
					'meta-separator-tilde'	=> esc_html('~'),
				),
                'default'  => 'meta-separator-colon',
				'required' => array( 'post-meta', '=', 1 )
            ),		
		)
	) );
	
	/*
	* Blog/Archives options
	*/
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog / Archives', 'alaha' ),
        'id'         => 'blog-archive',
		'subsection'	 => true,
        'fields'     => array(
			array(
                'id'       => 'blog-page-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Page Layout', 'alaha' ),
                'subtitle' => esc_html__( 'Select blog/archive page layout with sidebar postion.', 'alaha' ),
                'options'  => array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  => 'right-sidebar'
            ),
			array(
                'id'       => 'blog-sidebar-width',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Sidebar Width', 'alaha' ),
                'options'  => array(
					'3'=>esc_html__('Medium','alaha'),
					'4'=>esc_html__('Large','alaha'),
				),
                'default'  => '3',
				'required' => array( 'blog-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'blog-page-sidebar-widget',
                'type'     => 'select',
                'title'    => esc_html__('Sidebar Widget Area','alaha'),
                'data'     => 'sidebars',
                'default'  => 'sidebar-1',
                'required' => array( 'blog-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'blog-page-title',
                'type'     => 'switch',
                'title'    => esc_html__( 'Page Title', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'          => 'blog-page-title-text',
                'type'        => 'text',
                'title'       => esc_html__( 'Page Title Text', 'alaha' ),
                'default'       => esc_html__( 'Blog', 'alaha' ),
                'placeholder' => esc_attr__('Enter blog post title here','alaha'),
				'required' => array( 'blog-page-title', '=', 1 )
            ),
			array(
                'id'       => 'blog-page-breadcrumb',
                'type'     => 'switch',
                'title'    => esc_html__( 'Page Breadcrumb', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'blog-post-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Post Style', 'alaha' ),
                'options'  => array(
                    'blog-bottom-overlap' => array(
                        'title' => 'Default Bottom Overlap',
                        'alt' => 'Default Bottom Overlap',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/default-bottom-overlap.png',
                    ),
					'blog-bottom-overlap-center' => array(
                        'title' => 'Bottom Overlap Center',
                        'alt' => 'Bottom Overlap Center',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/bottom-overlap-center.png',
                    ),
                    'blog-full-width' => array(
                        'title' => 'Full Width',
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/full-width.png',
                    ), 
					'blog-small-image' => array(
                        'title' => 'Small Image',
                        'alt' => 'Small Image',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/small-image.png',
                    ),
					'blog-chess' => array(
                        'title' => 'Blog Chess',
                        'alt' => 'Blog Chess',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/blog-chess.png',
                    ),
					'blog-grid' => array(
                        'title' => 'Blog Grid',
                        'alt' => 'Blog Grid',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/blog-grid.png',
                    ),
					/* 'blog-timeline' => array(
                        'alt' => 'Blog Timeline',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ), */
                ),
                'default'  => 'blog-bottom-overlap',
            ),
			array(
                'id'       => 'blog-grid-layout',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Gird Layout', 'alaha' ),
                'options'  => array(
                    'simple-grid' 		=> esc_html__('Simple', 'alaha' ),
                    'masonry-grid' 		=> esc_html__('Masonry', 'alaha' ),
                ),
                'default'  => 'simple-grid',
				'required' => array( 'blog-post-style', '=', array('blog-grid') )
            ),
			array(
                'id'       => 'blog-grid-post-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Grid Post Style', 'alaha' ),
                'options'  => array(
                    'blog-grid-bottom-overlap' => array(
                        'title' => 'Default Bottom Overlap',
                        'alt' => 'Default Bottom Overlap',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/grid-default-bottom-overlap.png',
                    ),
					'blog-grid-bottom-overlap-center' => array(
                        'title' => 'Default Bottom Overlap Center',
                        'alt' => 'Default Bottom Overlap Center',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/grid-default-bottom-overlap-center.png',
                    ),
                    'blog-grid-full-width' => array(
                        'title' => 'Full Width',
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/grid-full-width.png',
                    ), 
					'blog-grid-gradient-overlay' => array(
                        'title' => 'Gradient Overlay',
                        'alt' => 'Gradient Overlay',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/gradient-overlay.png',
                    ),					
                ),
                'default'  => 'blog-grid-bottom-overlap',
				'required' => array( 'blog-post-style', '=', array('blog-grid') ),
            ),						
			array(
                'id'       => 'blog-grid-columns',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Gird Columns', 'alaha' ),
                'subtitle' => esc_html__( 'If you have choosed post style grid or masonry grid layout, so you can manage here number of grid columns display.', 'alaha' ),
                'options'  => array(
                    '2' 		=> esc_html__('2 Columns', 'alaha' ),
                    '3' 	=> esc_html__('3 Columns(in Full Width)', 'alaha' ),
					'4' 		=> esc_html__('4 Columns(in Full Width)', 'alaha' ),
                ),
                'default'  => '2',
				'required' => array( 'blog-post-style', '=', array('blog-grid') ),
            ),
			array(
                'id'       => 'blog-post-thumbnail',
                'type'     => 'switch',
                'title'    => esc_html__('Post Thumbnail','alaha'),
                'subtitle' => esc_html__('Show/hide blog post thumbnail.','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'blog-post-title',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Title', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),			
			array(
                'id'       => 'blog-post-content',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Post Content', 'alaha' ),
                'options'  => array(
					'excerpt-content'=>esc_html__('Excerpt Content','alaha'),
					'full-content'=>esc_html__('Full Content','alaha'),
				),
                'default'  => 'full-content',
            ),			
			array(
                'id'            => 'blog-excerpt-length',
                'type'          => 'slider',
                'title'         => esc_html__('Excerpt Length (words)','alaha'),
                'subtitle'      => esc_html__('Show blog listing excerpt content length (words).','alaha'),
                'default'       => 30,
                'min'           => 10,
                'step'          => 1,
                'max'           => 100,
                'display_value' => 'text',
				'required' => array( 'blog-post-content', '=', 'excerpt-content' )
            ),
			array(
                'id'       => 'read-more-button',
                'type'     => 'switch',
                'title'    => esc_html__( 'Read More Button', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'read-more-button-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Read More Button Style', 'alaha' ),
                'options'  => array(
					'read-more-link'=>esc_html__('Link','alaha'),
					'read-more-button'=>esc_html__('Button','alaha'),
					'read-more-button-fill'=>esc_html__('Button Fill','alaha'),
				),
                'default'  => 'read-more-link',
				'required' => array( 'read-more-button', '=', 1 )
            ),
			array(
                'id'       => 'read-more-text',
                'type'     => 'text',
                'title'    => esc_html__( 'Read More Text', 'alaha' ),
                'default'  => 'Continue Reading',
				'required' => array( 'read-more-button', '=', 1 )
            ),
			array(
                'id'       => 'blog-pagination-style',
                'type'     => 'button_set',
                'title'    => esc_html__( ' Pagination Style', 'alaha' ),
                'options'  => array(
					'default'=>esc_html__('Default','alaha'),
					'infinity-scroll'=>esc_html__('Infinity Scroll','alaha'),
					'load-more-button'=>esc_html__('Load More','alaha'),
				),
                'default'  => 'default',
            ),
			array(
                'id'       => 'blog-pagination-load-more-button-text',
                'type'     => 'text',
                'title'    => esc_html__( 'Load More Button Text', 'alaha' ),
				'subtitle' => esc_html__('Add Load More Button Text.','alaha'),
                'default'  => 'Load More Posts',
				'required' => array( 'blog-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
			array(
                'id'       => 'blog-pagination-finished-message',
                'type'     => 'text',
                'title'    => esc_html__( 'Finished Message', 'alaha' ),
				'subtitle' => esc_html__('Text to display when no additional items are available.','alaha'),
                'default'  => 'No More Posts Available',
				'required' => array( 'blog-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
		),
	) );
	
	/*
	* Single Post options
	*/
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Single Post', 'alaha' ),
        'id'         => 'single-post',
		'subsection'	 => true,
        'fields'     => array(
			array(
                'id'       => 'single-post-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Sidebar', 'alaha' ),
                'subtitle' => esc_html__( 'Select single post sidebar layout.', 'alaha' ),
                'options'  => array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  => 'right-sidebar'
            ),
			array(
                'id'       => 'single-post-sidebar-width',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Sidebar Width', 'alaha' ),
                'options'  => array(
					'3'=>esc_html__('Medium','alaha'),
					'4'=>esc_html__('Large','alaha'),
				),
                'default'  => '3',
				'required' => array( 'single-post-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'single-post-sidebar-widget',
                'type'     => 'select',
                'title'    => esc_html__('Sidebar Widget Area','alaha'),
                'data'     => 'sidebars',
                'default'  => 'sidebar-1',
                'required' => array( 'single-post-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'single-post-thumbnail',
                'type'     => 'switch',
                'title'    => esc_html__('Post Thumbnail','alaha'),
                'subtitle' => esc_html__('Show/hide single post thumbnail.','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-post-gallery-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Post Gallery Style', 'alaha' ),
                'options'  => array(
					'slider'		=>esc_html__('Slider','alaha'),
					'grid'			=>esc_html__('Grid','alaha'),
					'one-column'	=>esc_html__('One Column','alaha'),					
				),
                'default'  => 'slider',
				'required' => array( 'single-post-thumbnail', '=', 1 )
            ),
			array(
                'id'       => 'single-post-title',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Title', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'         	=> 'single-post-title-text',
                'type'        	=> 'text',
                'title'       	=> esc_html__( 'Page Title Text', 'alaha' ),
                'default'       => esc_html__( 'Our Blog', 'alaha' ),
                'placeholder' 	=> esc_attr__('Enter post title here','alaha'),
				'required' 		=> array( 'single-post-title', '=', 1 )
            ),
			array(
                'id'       => 'single-post-author-info',
                'type'     => 'switch',
                'title'    => esc_html__( 'Author Info', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'single-post-tag',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Tags', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'single-post-social-share-link',
                'type'     => 'switch',
                'title'    => esc_html__( 'Social Share Links', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),			
			array(
                'id'       => 'single-post-navigation',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Navigation', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'single-post-comment',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Comments', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'single-post-related',
                'type'     => 'switch',
                'title'    => esc_html__( 'Related Posts', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       	=> 'show-related-posts',
                'type'     	=> 'slider',
                'title'    	=> esc_html__( 'Show Related Posts', 'alaha' ),
				'subtitle'  => esc_html__('Show/display number of related posts.','alaha'),
                'default'   => 6,
                'min'       => 2,
                'step'      => 1,
                'max'       => 12,
                'display_value' => 'text',
				'required' => array( 'single-post-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-posts-taxonomy',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Taxonomy', 'alaha' ),
				'subtitle' => esc_html__('Get related posts by post taxonomy category or tag.','alaha'),
                'options'  => array(
					'post_tag'=>esc_html__('Tag','alaha'),
					'category'=>esc_html__('Category','alaha'),					
				),
                'default'  => 'post_tag',
				'required' => array( 'single-post-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-posts-orderby',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Post Orderby', 'alaha' ),
                'options'  => array(
					'none'=>esc_html__('None','alaha'),
					'rand'=>esc_html__('Random','alaha'),
					'ID'=>esc_html__('ID','alaha'),
					'name'=>esc_html__('Name','alaha'),
					'date'=>esc_html__('Date','alaha'),
					'modified'=>esc_html__('Modified Date','alaha'),					
					'comment_count'=>esc_html__('Comment Count','alaha'),
				),
                'default'  => 'rand',
				'required' => array( 'single-post-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-posts-order',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Post Order', 'alaha' ),
                'options'  => array(
					'DESC'=>esc_html__('DESC','alaha'),
					'ASC'=>esc_html__('ASC','alaha'),					
				),
                'default'  => 'DESC',
				'required' => array( 'single-post-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-posts-display',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Display Posts In', 'alaha' ),
				'subtitle' => esc_html__('Display related posts in slider or grid.','alaha'),
                'options'  => array(
					'slider'=>esc_html__('Slider','alaha'),
					'grid'=>esc_html__('Grid','alaha'),					
				),
                'default'  => 'slider',
				'required' => array( 'single-post-related', '=', 1 ),
            ),
		),
	) ); /* End Single Post Section */

	/*
	* Portfolio options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Portfolio', 'alaha' ),
        'id'         => 'portfolio',
		'icon'		 => 'el el-th',
        'fields'     => array(
			array(
                'id'       => 'enable-portfolio',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Enable','alaha'),
                'off'      => esc_html__('Disable','alaha'),
            ),
			array(
                'id'       => 'portfolio-slug',
                'type'     => 'text',
                'title'    => esc_html__( 'Slug Name', 'alaha' ),
                'default'  => '',
                'placeholder'  => esc_attr('portfolio'),
            ),
			array(
                'id'       => 'portfolio-name',
                'type'     => 'text',
                'title'    => esc_html__( 'Name', 'alaha' ),
                'default'  => '',
                'placeholder'  => esc_attr__('Portfolios','alaha'),
            ),
			array(
                'id'       => 'portfolio-singular-name',
                'type'     => 'text',
                'title'    => esc_html__( 'Singular Name', 'alaha' ),
                'default'  => '',
                'placeholder'  => esc_attr__('Portfolio','alaha'),
            ),
			array(
                'id'       => 'portfolio-cat-slug',
                'type'     => 'text',
                'title'    => esc_html__( 'Category Slug', 'alaha' ),
                'default'  => '',
                'placeholder'  => esc_attr('portfolio_cat'),
            ),
			array(
                'id'       => 'portfolio-skill-slug',
                'type'     => 'text',
                'title'    => esc_html__( 'Skill Slug', 'alaha' ),
                'default'  => '',
                'placeholder'  => esc_attr('portfolio_skill'),
            ),
			array(
                'id'       => 'portfolio-meta',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio Meta', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'specific-portfolio-meta',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Portfolio Meta', 'alaha' ),
                'subtitle' => esc_html__( 'Show/hide specific meta.', 'alaha' ),
                'multi'    => true,
                'options'  => array(
                    'categories' 	=> esc_html__('Category', 'alaha' ),
                    'skills' 		=> esc_html__('Skill', 'alaha' ),
                ),
                'default'  => array( 'categories', 'skills'),
				'required' => array( 'portfolio-meta', '=', 1 )
            ),
		)
	) );
	/* END Portfolio SECTIONS */
	
	/*
	* Portfolio Archives options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Portfolio Archives', 'alaha' ),
        'id'         => 'portfolio-archive',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'portfolio-page-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Page Layout', 'alaha' ),
                'options'  => array(
                    'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  => 'full-width',
            ),
			array(
                'id'       => 'portfolio-sidebar-width',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Sidebar Width', 'alaha' ),
                'options'  => array(
					'3'=>esc_html__('Medium','alaha'),
					'4'=>esc_html__('Large','alaha'),
				),
                'default'  => '3',
				'required' => array( 'portfolio-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'portfolio-sidebar-widget',
                'type'     => 'select',
                'title'    => esc_html__('Select Sidebar Widget Area','alaha'),
                'data'     => 'sidebars',
                'default'  => 'sidebar-1',
                'required' => array( 'portfolio-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'portfolio-page-title',
                'type'     => 'switch',
                'title'    => esc_html__( 'Page Title', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'        => 'portfolio-page-title-text',
                'type'      => 'text',
                'title'     => esc_html__( 'Page Title Text', 'alaha' ),
                'placeholder' => esc_attr__('Enter portfolio post title here','alaha'),
				'default'  	=> 'Portfolio',
				'required' 	=> array( 'portfolio-page-title', '=', 1 )
            ),
			array(
                'id'       => 'portfolio-page-breadcrumb',
                'type'     => 'switch',
                'title'    => esc_html__( 'Page Breadcrumb', 'alaha' ),
                'default'  => 1,
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
            ),
			array(
                'id'       => 'portfolio-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Hover Style', 'alaha' ),
                'options'  => array(
                    'portfolio-style-1' => array(
                        'alt' => 'Style 1',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-1.png',
                    ),
					'portfolio-style-2' => array(
                        'alt' => 'Style 2',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-2.png',
                    ),
					'portfolio-style-3' => array(
                        'alt' => 'Style 3',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-3.png',
                    ),
					'portfolio-style-4' => array(
                        'alt' => 'Style 4',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-4.png',
                    ),
					'portfolio-style-5' => array(
                        'alt' => 'Style 5',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-5.png',
                    ),
					'portfolio-style-6' => array(
                        'alt' => 'Style 6',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-6.png',
                    ),
					'portfolio-style-7' => array(
                        'alt' => 'Style 7',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/style-7.png',
                    ),
                ),
                'default'  => 'portfolio-style-1',
            ),
			array(
                'id'       => 'portfolio-grid-layout',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Grid Layout', 'alaha' ),
                'options'  => array(
                    'simple-grid' 	=> esc_html__('Simple', 'alaha' ),
                    'masonry-grid' 	=> esc_html__('Masonry', 'alaha' ),
                ),
                'default'  => 'masonry-grid',
            ),
			array(
                'id'       	=> 'portfolio-grid-columns',
                'type'     	=> 'button_set',
                'title'    	=> esc_html__( 'Grid Columns', 'alaha' ),
                'options'  	=> array(
                    '2' 	=> esc_html__('2 Columns', 'alaha' ),
                    '3' 	=> esc_html__('3 Columns', 'alaha' ),
					'4' 	=> esc_html__('4 Columns', 'alaha' ),
                ),
                'default'  => '3',
            ),
			array(
                'id'            => 'portfolio-grid-gap',
                'type'          => 'slider',
                'title'         => esc_html__('Grid Gapping','alaha'),
                'subtitle'      => esc_html__('Grid gapping/spacing between portfolio.','alaha'),
                'default'       => 15,
                'min'           => 0,
                'step'          => 5,
                'max'           => 15,
				'required' => array( 'portfolio-style', '=', array( 'portfolio-style-3', 'portfolio-style-4', 'portfolio-style-5', 'portfolio-style-6', 'portfolio-style-7' )),
            ),
			array(
                'id'       => 'portfolio-filter',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio Filter', 'alaha' ),
				'subtitle' => esc_html__( 'Show portfolios filter or not.', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'            => 'portfolio-per-page',
                'type'          => 'slider',
                'title'         => esc_html__('Portfolio Per Page','alaha'),
                'subtitle'      => esc_html__('Show number of portfolio per page.','alaha'),
                'default'       => 9,
                'min'           => 3,
                'step'          => 1,
                'max'           => 50,
                'display_value' => 'text',
            ),
			array(
                'id'       => 'portfolio-button-icon',
                'type'     => 'switch',
                'title'    => esc_html__( 'Hover Button Icon', 'alaha' ),
				'subtitle' => esc_html__( 'Portfolio hover button icon show or hide.', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'portfolio-link-icon',
                'type'     => 'switch',
                'title'    => esc_html__( 'Link Button Icon', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
                'default'  => 1,
				'required' => array( 'portfolio-button-icon', '=', 1 ),
            ),
			array(
                'id'       => 'portfolio-zoom-icon',
                'type'     => 'switch',
                'title'    => esc_html__( 'Zoom Image Icon', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
				'required' => array( 'portfolio-button-icon', '=', 1 ),
            ),
			array(
                'id'       => 'portfolio-content-part',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio Content Part', 'alaha' ),
				'subtitle' => esc_html__( 'Portfolio bottom content part( title and category) show or hide.', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				 'default'  => 1,
            ),
			array(
                'id'       => 'portfolio-category',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio Category', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
				'required' => array( 'portfolio-content-part', '=', 1 ),
            ),
			array(
                'id'       => 'portfolio-title',
                'type'     => 'switch',
                'title'    => esc_html__( 'Portfolio Title', 'alaha' ),
                'on'       => esc_html__('Show','alaha'),
                'off'      => esc_html__('Hide','alaha'),
                'default'  => 1,
				'required' => array( 'portfolio-content-part', '=', 1 ),
            ),			
			array(
                'id'       => 'portfolio-pagination-style',
                'type'     => 'button_set',
                'title'    => esc_html__( ' Pagination Style', 'alaha' ),
                'options'  => array(
					'default'=>esc_html__('Default','alaha'),
					'infinity-scroll'=>esc_html__('Infinity Scroll','alaha'),
					'load-more-button'=>esc_html__('Load More','alaha'),
				),
                'default'  => 'default',
            ),
			array(
                'id'       => 'portfolio-pagination-load-more-button-text',
                'type'     => 'text',
                'title'    => esc_html__( 'Load More Button Text', 'alaha' ),
				'subtitle' => esc_html__('Add Load More Button Text.','alaha'),
                'default'  => 'Load More Portfolios',
				'required' => array( 'portfolio-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
			array(
                'id'       => 'portfolio-pagination-finished-message',
                'type'     => 'text',
                'title'    => esc_html__( 'Finished Message', 'alaha' ),
				'subtitle' => esc_html__('Text to display when no additional items are available.','alaha'),
                'default'  => 'No More Portfolios Available',
				'required' => array( 'portfolio-pagination-style', '=', array('infinity-scroll', 'load-more-button') ),
            ),
		)
	) );
	/* END Portfolio Archives SECTIONS */
	
	/*
	* Single Portfolio options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Single Portfolio', 'alaha' ),
        'id'         => 'single-portfolio',
		'subsection'	 => true,
        'fields'     => array(
			array(
                'id'       => 'single-portfolio-page-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Page Layout', 'alaha' ),
                'subtitle' => esc_html__( 'Select single post sidebar layout.', 'alaha' ),
                'options'  => array(
                   'full-width' => array(
                        'alt' => 'Full Width',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-none.png',
                    ),                   
                    'left-sidebar' => array(
                        'alt' => '2 Column Left',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-left.png',
                    ), 
					'right-sidebar' => array(
                        'alt' => '2 Column Right',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/sidebar-right.png',
                    ), 
                ),
                'default'  => 'full-width'
            ),
			array(
                'id'       => 'single-portfolio-sidebar-width',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Sidebar Width', 'alaha' ),
                'options'  => array(
					'3'=>esc_html__('Medium','alaha'),
					'4'=>esc_html__('Large','alaha'),
				),
                'default'  => '3',
				'required' => array( 'single-portfolio-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'single-portfolio-sidebar-widget',
                'type'     => 'select',
                'title'    => esc_html__('Sidebar Widget Area','alaha'),
                'data'     => 'sidebars',
                'default'  => 'sidebar-1',
                'required' => array( 'single-portfolio-page-layout', '=', array( 'left-sidebar', 'right-sidebar' ) )
            ),
			array(
                'id'       => 'single-portfolio-layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Portfolio Layout', 'alaha' ),
               'options'  => array(
                    '4' 	=> array(
                        'alt' => ' 4 8 Column',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/4_8-layout.png',
                    ),
					'6' 	=> array(
                        'alt' => ' 6 6 Column',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/6_6-layout.png',
                    ),                   
                    '8' => array(
                        'alt' => '8 4 Column',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/8_4-layout.png',
                    ), 
					'12' => array(
                        'alt' => '12 12 Column',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/portfolio/12_12-layout.png',
                    ),
                ),
                'default'  => '8',
            ),
			array(
                'id'       => 'single-portfolio-gallery',
                'type'     => 'switch',
                'title'    => esc_html__('Thumbnail/Gallery','alaha'),
                'subtitle' => esc_html__('Show/hide portfolio thumbnail/gallery.','alaha'),
                'on'       => esc_html__('Gallery','alaha'),
				'off'      => esc_html__('Thumbnail','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-gallery-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Gallery Style', 'alaha' ),
                'options'  => array(
					'slider'		=>esc_html__('Slider','alaha'),
					'grid'			=>esc_html__('Grid','alaha'),
					'one-column'	=>esc_html__('One Column','alaha'),					
				),
                'default'  => 'slider',
				'required' => array( 'single-portfolio-gallery', '=', 1 )
            ),			
			array(
                'id'       => 'single-portfolio-information-title',
                'type'     => 'switch',
                'title'    => esc_html__('Information Title','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-description',
                'type'     => 'switch',
                'title'    => esc_html__('Project Description','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-preview-button',
                'type'     => 'switch',
                'title'    => esc_html__('Preview Button','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-client',
                'type'     => 'switch',
                'title'    => esc_html__('Project Client','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-date',
                'type'     => 'switch',
                'title'    => esc_html__('Project Date','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-category',
                'type'     => 'switch',
                'title'    => esc_html__('Project Category','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-skill',
                'type'     => 'switch',
                'title'    => esc_html__('Project Skill','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-share',
                'type'     => 'switch',
                'title'    => esc_html__('Social Share Links','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Project Navigation','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-comments',
                'type'     => 'switch',
                'title'    => esc_html__('Comment','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'single-portfolio-related',
                'type'     => 'switch',
                'title'    => esc_html__('Related Projects','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       	=> 'show-related-portfolios',
                'type'     	=> 'slider',
                'title'    	=> esc_html__( 'Show Related Portfolios', 'alaha' ),
				'subtitle'  => esc_html__('Show/display number of related Portfolios.','alaha'),
                'default'   => 6,
                'min'       => 2,
                'step'      => 1,
                'max'       => 12,
                'display_value' => 'text',
				'required' => array( 'single-portfolio-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-portfolios-taxonomy',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Taxonomy', 'alaha' ),
				'subtitle' => esc_html__('Get related Portfolios by post taxonomy category or tag.','alaha'),
                'options'  => array(
					'post_tag'=>esc_html__('Tag','alaha'),
					'category'=>esc_html__('Category','alaha'),					
				),
                'default'  => 'post_tag',
				'required' => array( 'single-portfolio-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-Portfolios-orderby',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Portfolios Orderby', 'alaha' ),
                'options'  => array(
					'none'=>esc_html__('None','alaha'),
					'rand'=>esc_html__('Random','alaha'),
					'ID'=>esc_html__('ID','alaha'),
					'name'=>esc_html__('Name','alaha'),
					'date'=>esc_html__('Date','alaha'),
					'modified'=>esc_html__('Modified Date','alaha'),					
					'comment_count'=>esc_html__('Comment Count','alaha'),
				),
                'default'  => 'rand',
				'required' => array( 'single-portfolio-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-portfolios-order',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Portfolios Order', 'alaha' ),
                'options'  => array(
					'DESC'=>esc_html__('DESC','alaha'),
					'ASC'=>esc_html__('ASC','alaha'),					
				),
                'default'  => 'DESC',
				'required' => array( 'single-portfolio-related', '=', 1 ),
            ),
			array(
                'id'       => 'related-portfolios-display',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Display Portfolios In', 'alaha' ),
				'subtitle' => esc_html__('Display related portfolios in slider or grid.','alaha'),
                'options'  => array(
					'slider'=>esc_html__('Slider','alaha'),
					'grid'=>esc_html__('Grid','alaha'),					
				),
                'default'  => 'slider',
				'required' => array( 'single-portfolio-related', '=', 1 ),
            ),			
		)
	) ); /* END Portfolio Single SECTIONS */
	
	/*
	* Social
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social', 'alaha' ),
        'id'         => 'social',
		'icon'		 => 'el el-group',
        'fields'     => array(
		)
	) );
	
	/*
	* Social Profile
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Profile', 'alaha' ),
        'id'         => 'social-profile',
		'icon'		 => '',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'show-social-profile',
                'type'     => 'switch',
                'title'    => esc_html__('Social Profile Icon','alaha'),
				'subtitle' => esc_html__('Show social profile icon in header and footer.','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'social-profile-icons-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Icons Style', 'alaha' ),
                'options'  => array(
					'icons-default' 	=> array(
                        'title' => 'Default',
                        'alt' => 'Default',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/default.png',
                    ),
					'icons-colour'	=> array(
                        'title' => 'Colour',
                        'alt' => 'Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/colour.png',
                    ),                   
                    'icons-bordered'  => array(
                        'title' => 'Bordered',
                        'alt' => 'Bordered',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/bordered.png',
                    ), 
					'icons-fill-colour' => array(
                        'title' => 'Fill Colour',
                        'alt' => 'Fill Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/fill-color.png',
                    ),
					'icons-theme-colour' => array(
                        'title' => 'Theme Colour',
                        'alt' => 'Theme Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/theme-color.png',
                    ),
										
                ),
                'default'  => 'icons-default',
				'required' => array( 'show-social-profile', '=', 1 )
            ),
			array(
                'id'       => 'profile-icons-size',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Icons Size', 'alaha' ),
                'options'  => array(
                    'icons-size-default'=> esc_html__('Default','alaha'),
					'icons-size-small' 	=> esc_html__('Small','alaha'),
					'icons-size-large' 	=> esc_html__('Large','alaha'),
                ),
                'default'  => 'icons-size-small',
				'required' => array( 'show-social-profile', '=', 1 )
            ),
			array(
                'id'       => 'facebook-link',
                'type'     => 'text',
                'title'    => esc_html__('Facebook','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the facebook icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'twitter-link',
                'type'     => 'text',
                'title'    => esc_html__('Twitter','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the twitter icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'instagram-link',
                'type'     => 'text',
                'title'    => esc_html__('Instagram','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the instagram icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'linkedin-link',
                'type'     => 'text',
                'title'    => esc_html__('Linkedin','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the linkedin icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'flickr-link',
                'type'     => 'text',
                'title'    => esc_html__('Flickr','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the flickr icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),			
			array(
                'id'       => 'rss-link',
                'type'     => 'text',
                'title'    => esc_html__('RSS','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the rss icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'pinterest-link',
                'type'     => 'text',
                'title'    => esc_html__('Pinterest','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the pinterest icon. Leave blank to hide icon.','alaha'),
				'default'  => '',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'youtube-link',
                'type'     => 'text',
                'title'    => esc_html__('Youtube','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the youtube icon. Leave blank to hide icon.','alaha'),
				'default'  => '#',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'github-link',
                'type'     => 'text',
                'title'    => esc_html__('Github','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the github icon. Leave blank to hide icon.','alaha'),
				'default'  => '',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'whatsapp-link',
                'type'     => 'text',
                'title'    => esc_html__('WhatsApp','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the whatsapp icon. Leave blank to hide icon.','alaha'),
				'default'  => '',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'telegram-link',
                'type'     => 'text',
                'title'    => esc_html__('Telegram','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the telegram icon. Leave blank to hide icon.','alaha'),
				'default'  => '',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
			array(
                'id'       => 'vk-link',
                'type'     => 'text',
                'title'    => esc_html__('VK','alaha'),
                'subtitle' => esc_html__('Enter your custom link to show the VK icon. Leave blank to hide icon.','alaha'),
				'default'  => '',
				'required' => array( 'show-social-profile', '=', 1 ),
            ),
		)
	) );
	
	/*
	* Social Share
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social Share', 'alaha' ),
        'id'         => 'social-share',
		'icon'		 => '',
		'subsection' => true,
        'fields'     => array(
			array(
                'id'       => 'show-social-sharing',
                'type'     => 'switch',
                'title'    => esc_html__('Share Icons','alaha'),
				'subtitle' => esc_html__('Show social share icons in blog, posts, products, portfolios, etc...','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'social-sharing-icons-style',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Icons Style', 'alaha' ),
                'options'  => array(
					'icons-default' 	=> array(
                        'title' => 'Default',
                        'alt' => 'Default',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/default.png',
                    ),
					'icons-colour'	=> array(
                        'title' => 'Colour',
                        'alt' => 'Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/colour.png',
                    ),                   
                    'icons-bordered'  => array(
                        'title' => 'Bordered',
                        'alt' => 'Bordered',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/bordered.png',
                    ), 
					'icons-fill-colour' => array(
                        'title' => 'Fill Colour',
                        'alt' => 'Fill Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/fill-color.png',
                    ),
					'icons-theme-colour' => array(
                        'title' => 'Theme Colour',
                        'alt' => 'Theme Colour',
                        'img' => ALAHA_ADMIN_IMAGES . 'layout/social-icon/theme-color.png',
                    ),
										
                ),
                'default'  => 'icons-bordered',
				'required' => array( 'show-social-sharing', '=', 1 )
            ),
			array(
                'id'       => 'sharing-icons-shape',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Icons Shape', 'alaha' ),
                'options'  => array(
					'icons-shape-circle' => esc_html__('Circle','alaha'),
                    'icons-shape-square' => esc_html__('Square','alaha'),
                ),
                'default'  => 'icons-shape-circle',
				'required' => array( 'show-social-sharing', '=', 1 )
            ),
			array(
                'id'       => 'sharing-icons-size',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Icons Size', 'alaha' ),
                'options'  => array(
                    'icons-size-default'=> esc_html__('Default','alaha'),
					'icons-size-small' 	=> esc_html__('Small','alaha'),
					'icons-size-large' 	=> esc_html__('Large','alaha'),
                ),
                'default'  => 'icons-size-default',
				'required' => array( 'show-social-sharing', '=', 1 )
            ),
			array(
                'id'       => 'social-share-manager',
                'type'     => 'sorter',
                'title'    => 'Share Icons Manager',
                'compiler' => 'true',
                'options'  => array(
                    'enabled'  => array(
                        'facebook' 		=> 'Facebook',
                        'twitter'     	=> 'Twitter',
                        'linkedin'   	=> 'Linkedin',
						'telegram'		=> 'Telegram',
						'pinterest'		=> 'Pinterest',
                    ),
                    'disabled' => array(
						'stumbleupon'	=> 'StumbleUpon',
						'tumblr'   		=> 'Tumblr',
						'reddit'   		=> 'Reddit',
						'vk'   			=> 'VK',
						'odnoklassniki' => 'Odnoklassniki',
						'pocket'   		=> 'Pocket',
						'whatsapp'  	=> 'WhatsApp',
						'email'   		=> 'Email',
						'print'   		=> 'Print',
					),
                ),
				'required' => array( 'show-social-sharing', '=', 1 )
            ),			
		)
	) );/* End Social sections */
			
	/*
	* Slider Config
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Slider Config', 'alaha' ),
        'id'         => 'slider-config',
		'icon'		 => 'el el-picture',
        'fields'     => array(
			array(
                'id'       => 'slider-loop',
                'type'     => 'switch',
                'title'    => esc_html__('Loop','alaha'),
				'subtitle' => esc_html__('Infinity loop. Duplicate last and first items to get loop illusion.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'slider-autoplay',
                'type'     => 'switch',
                'title'    => esc_html__('Autoplay','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),			
			array(
                'id'       => 'slider-autoplay-hover-pause',
                'type'     => 'switch',
                'title'    => esc_html__('autoplayHoverPause','alaha'),
				'subtitle' => esc_html__('Pause on mouse hover.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
				'required' => array( 'slider-autoplay', '=', 1 )
            ),
			array(
                'id'       => 'slider-autoplaytimeout',
                'type'     => 'text',
                'title'    => esc_html__( 'autoplayTimeout', 'alaha' ),
				'subtitle' => esc_html__('Autoplay interval timeout.','alaha'),
                'default'  => 3500,
				'validate' => 'numeric',
				'required' => array( 'slider-autoplay', '=', 1 )
            ),
			array(
                'id'       => 'slider-center',
                'type'     => 'switch',
                'title'    => esc_html__('Center','alaha'),
				'subtitle' => esc_html__('Center item. Works well with even an odd number of items.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'slider-smartspeed',
                'type'     => 'text',
                'title'    => esc_html__( 'smartSpeed', 'alaha' ),
				'subtitle' => esc_html__('Speed Calculate. More info to come..','alaha'),
                'default'  => 750,
				'validate' => 'numeric',
            ),			
			array(
                'id'       => 'slider-rewind',
                'type'     => 'switch',
                'title'    => esc_html__('Rewind','alaha'),
				'subtitle' => esc_html__('Go backwards when the boundary has reached.','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'slider-auto-height',
                'type'     => 'switch',
                'title'    => esc_html__('AutoHeight','alaha'),
                'on'       => esc_html__('Yes','alaha'),
				'off'      => esc_html__('No','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'slider-next-prev-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Next/Prev Navigation','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'slider-nav-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Navigation Style', 'alaha' ),
                'options'  => array(
					'owl-nav-rectangle'	=> esc_html__('Rectangle','alaha'),
					'owl-nav-circle'	=> esc_html__('Circle','alaha'),
					'owl-nav-square'	=> esc_html__('Square','alaha'),
					'owl-nav-arrow'		=> esc_html__('Arrow','alaha'),
				),
                'default'  => 'owl-nav-rectangle',
				'required' => array( 'slider-next-prev-navigation', '=', 1 )
            ),
			array(
                'id'       => 'slider-nav-position',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Navigation Position', 'alaha' ),
                'options'  => array(
					'owl-nav-middle'=>esc_html__('Middle','alaha'),				
					'owl-nav-top'	=>esc_html__('Top','alaha'),
				),
                'default'  => 'owl-nav-middle',
				'required' => array( 'slider-next-prev-navigation', '=', 1 )
            ),
			array(
                'id'       => 'slider-dots-navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Dots Navigation','alaha'),
                'on'       => esc_html__('Show','alaha'),
				'off'      => esc_html__('Hide','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'slider-touchDrag',
                'type'     => 'switch',
                'title'    => esc_html__('TouchDrag In Mobile','alaha'),
				'subtitle' => esc_html__('Touch drag enabled','alaha'),
                'on'       => esc_html__('Enable','alaha'),
				'off'      => esc_html__('Disable','alaha'),
				'default'  => 1,
            ),
			array(
                'id'       => 'slider-animate-in',
                'type'     => 'text',
                'title'    => esc_html__( 'Animate In', 'alaha' ),
				'subtitle' => wp_kses_post('Please input animation. Please reference <a href="http://daneden.github.io/animate.css/">animate.css</a>. ex: fadeIn', 'alaha'),
                'default'  => '',
            ),
			array(
                'id'       => 'slider-animate-out',
                'type'     => 'text',
                'title'    => esc_html__( 'Animate Out', 'alaha' ),
				'subtitle' => wp_kses_post('Please input animation. Please reference <a href="http://daneden.github.io/animate.css/">animate.css</a>. ex: fadeOut', 'alaha'),
                'default'  => '',
            ),
		)
	) );/* END SLIDER CONFIG SECTIONS */	
	
	/*
	* Newsletter Options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Newsletter', 'alaha' ),
        'id'         => 'section-newsletter',
		'icon'       => 'el el-envelope',
        'fields'     => array(
			array(
                'id'       => 'newsletter-popup',
                'type'     => 'switch',
                'title'    => esc_html__('Newsletter', 'alaha'),
                'on'       => esc_html__('Enable','alaha'),
				'off'      => esc_html__('Disable','alaha'),
				'subtitle' => esc_html__('Newsletter popup enable or disable in your site.', 'alaha'),
				'default'  => 0,
            ),
			array(
				'id'      	=> 'newsletter-when-appear',
				'type'    	=> 'button_set',
				'title'   	=> esc_html__( 'When Popup Appear?', 'alaha' ),                    
				'options' 	=> array(
					'page_load' 	=> esc_html__('On Page Load', 'alaha'),
					'scroll' 		=> esc_html__('When Page Scroll', 'alaha'),
					'exit' 			=> esc_html__('On Exit Intent', 'alaha'),
				), 
				'default' 	=> 'page_load',
				'required' 	=> array( 'newsletter-popup', '=', 1 ),
			),
			array(
				'id'       => 'newsletter-delay',
				'type'     => 'text',
				'title'    => esc_html__( 'Popup Delay', 'alaha' ),
				'default'  => '5',
				'subtitle' =>  esc_html__( 'Enter no of second to open popup after page load.', 'alaha' ),
				'required' => array( 'newsletter-when-appear', '=', 'page_load' ),
			),
			array(
				'id'       => 'newsletter-x-scroll',
				'type'     => 'text',
				'title'    => esc_html__( 'Open when user scroll % of page', 'alaha' ),
				'default'  => '30',
				'subtitle' =>  esc_html__( '100% - For end of page', 'alaha' ),
				'required' => array( 'newsletter-when-appear', '=', 'scroll' ),
			),
			array(
                'id'       => 'newsletter-title',
                'type'     => 'text',
                'title'    => esc_html__('Newsletter Title', 'alaha'),
				'default'  => esc_html__('Sign Up & Get 40% Off', 'alaha'),
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),
			array(
				'id'       => 'newsletter-tag-line',
				'type'     => 'editor',
				'title'    => esc_html__('Main content', 'alaha'),
				'subtitle' => esc_html__('It will be shown at just below title', 'alaha'),
               'required' => array( 'newsletter-popup', '=', 1 ),
				'default'  => esc_html__('Signup today for free and be the first to hear of special promotions, new arrivals, designer and offers news.', 'alaha'),
			),
			array(
                'id'       => 'newsletter-dont-show',
                'type'     => 'text',
                'title'    => esc_html__('Newsletter Don\'t Show Msg', 'alaha'),
				'default'  => esc_html__('Don\'t show this popup again', 'alaha'),
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),			
			array(
                'id'       => 'newsletter-hide-mobile',
                'type'     => 'switch',
                'title'    => esc_html__('Mobile', 'alaha'),
                'on'       => esc_html__('Hide','alaha'),
				'off'      => esc_html__('Show','alaha'),
				'subtitle' => esc_html__('You can hide newsletter for mobile devices.', 'alaha'),
				'default'  => 1,
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),
			array(
                'id'       	=> 'newsletter-background',
                'type'     	=> 'background',
                'title'    	=> esc_html__('Background Color', 'alaha'),
                'subtitle'  => esc_html__( 'Newsletter background with image, color, etc.', 'alaha' ),
				'output'	=> array('.alaha-newsletter-popup'),
                'default' 	=> array(
					'background-color' 		=> '#ffffff',
					'background-image' 		=> ALAHA_ADMIN_IMAGES .'newsletter.jpg',
					'background-repeat' 	=> '',
					'background-size' 		=> '',
					'background-attachment' => '',
					'background-position' 	=> '',
				),
				'required' 	=> array( 'newsletter-popup', '=', 1 ),
            ),
			array(
                'id'       			=> 'newsletter-color',
                'type'     			=> 'button_set',
                'title'    			=> esc_html__('Title Color','alaha'),
                'subtitle' 	   		=> esc_html__('Page title color.','alaha'),
                'options'  			=> array(
                    'default' 	=> esc_html__('Default', 'alaha' ),
                    'light' 	=> esc_html__('Light', 'alaha' ),
                    'dark' 		=> esc_html__('Dark', 'alaha' ),
                ),
                'default'  			=> 'light',
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),
			array(
                'id'       		=> 'newsletter-button-bg-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Button Background Color', 'alaha' ),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#2370F4',
                    'hover'   	=> '#2370F4',
                ),			
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),
			array(
                'id'       		=> 'newsletter-button-text-color',
                'type'     		=> 'link_color',
                'title'    		=> esc_html__( 'Button Text Color', 'alaha' ),
                'active'    	=> false,
                'default'  		=> array(
                    'regular' 	=> '#ffffff',
                    'hover'   	=> '#ffffff',
                ),			
				'required' => array( 'newsletter-popup', '=', 1 ),
            ),
		)
	) );
	
	/*
	* Cookie Options
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Cookie Notice', 'alaha' ),
        'id'         => 'section-cookie-notice',
		'icon'       => 'el el-dashboard',
        'fields'     => array(
			array(
                'id'       => 'cookie-notice',
                'type'     => 'switch',
                'title'    => esc_html__('Cookie','alaha'),
                'on'       => esc_html__('Enable','alaha'),
				'off'      => esc_html__('Disable','alaha'),
				'subtitle' => esc_html__('Cookie notice enable or disable in your site.','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'cookie-title',
                'type'     => 'text',
                'title'    => 'Cookie Title',
                'subtitle' => esc_html__('Enter the Cookie Title/Name.','alaha'),
				'default'  => esc_html__('Cookies Notice','alaha'),
            ),
			array(
                'id'       => 'cookie-message-text',
                'type'     => 'textarea',
                'title'    => esc_html__('Message','alaha'),
				'subtitle' => esc_html__('Enter the cookie notice message.','alaha'),
				'default'  => esc_html__('We use cookies to ensure that we give you the best experience on our website. If you continue to use this site we will assume that you are happy with it.','alaha'),
            ),
			array(
                'id'       => 'cookie-accept-text',
                'type'     => 'text',
                'title'    => esc_html__('Button Text','alaha'),
                'subtitle' => esc_html__('The text of the option to accept the usage of the cookies and make the notification disappear.','alaha'),
				'default'  => esc_html__('Yes, I\'m Accept','alaha'),
            ),
			array(
                'id'       => 'cookie-see-more-opt',
                'type'     => 'switch',
                'title'    => esc_html__('More Info Link','alaha'),
                'on'       => esc_html__('Enable','alaha'),
				'off'      => esc_html__('Disable','alaha'),
				'subtitle' => esc_html__('Enable Read more link.','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'cookie-see-more-text',
                'type'     => 'text',
                'title'    => '',
                'subtitle' => esc_html__('The text of the more info button.','alaha'),
				'default'  => esc_html__('Read more','alaha'),
				'required' => array( 'cookie-see-more-opt', '=', 1 ),
            ),
			array(
                'id'       => 'cookie-see-more-link-type',
                'type'     => 'radio',
                'title'    => '',
                'subtitle' => esc_html__('Select where to redirect user for more information about cookies.','alaha'),
                'options'  => array(
								'custom' 	 => esc_html__('Custom link','alaha'),
								'page' => esc_html__('Page link','alaha'),
							),
				'default'  => 'custom',
				'required' => array( 'cookie-see-more-opt', '=', 1 ),
            ),
			array(
                'id'       => 'cookie-see-more-link-custom',
                'type'     => 'text',
                'title'    => '',
                'subtitle' => esc_html__('Enter the full URL starting with http://','alaha'),
				'default'  => 'http://empty',
				'placeholder' => esc_attr('http://#'),
				'required' => array( 'cookie-see-more-link-type', '=', 'custom' ),
            ),
			array(
                'id'       => 'cookie-see-more-link-pages',
                'type'     => 'select',
                'data'     => 'pages',
                'title'    => '',
                'subtitle' => esc_html__( 'Select from one of your site\'s pages', 'alaha' ),
				'required' => array( 'cookie-see-more-link-type', '=', 'page' ),
            ),
			array(
                'id'       => 'cookie-see-more-link-target',
                'type'     => 'select',
                'title'    => esc_html__( 'Link Target', 'alaha' ),
                'subtitle' => esc_html__( 'Select the link target for more info page.', 'alaha' ),
                'options'  => array(
                    '_blank' => '_blank',
                    '_self' => '_self',
                ),
                'default'  => '_blank',
            ),
			array(
                'id'       => 'cookie-refuse-opt',
                'type'     => 'switch',
                'title'    => esc_html__('Refuse Button','alaha'),
                'on'       => esc_html__('Enable', 'alaha'),
				'off'      => esc_html__('Disable', 'alaha'),
				'subtitle' => esc_html__('Give to the user the possibility to refuse third party non functional cookies.','alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'cookie-refuse-text',
                'type'     => 'text',
                'title'    => '',
                'subtitle' => esc_html__('The text of the option to refuse the usage of the cookies. To get the cookie notice status use alaha_cn_cookies_accepted() function.', 'alaha'),
				'default'  => esc_html__('No', 'alaha'),
				'required' => array( 'cookie-refuse-opt', '=', 1 ),
            ),
			array(
                'id'       => 'cookie-refuse-code',
                'type'     => 'textarea',
                'title'    => '',
				'subtitle' => esc_html__('Enter non functional cookies Javascript code here (for e.g. Google Analitycs). It will be used after cookies are accepted.','alaha'),
				'required' => array( 'cookie-refuse-opt', '=', 1 ),
				
            ),
			array(
                'id'       => 'cookie-on-scroll',
                'type'     => 'switch',
                'title'    => esc_html__('On Scroll', 'alaha'),
                'on'       => esc_html__('Enable', 'alaha'),
				'off'      => esc_html__('Disable', 'alaha'),
				'subtitle' => esc_html__('Enable cookie notice acceptance when users scroll.', 'alaha'),
				'default'  => 0,
            ),
			array(
                'id'       => 'cookie-on-scroll-offset',
                'type'     => 'text',
                'title'    => '',
                'subtitle' => esc_html__('Number of pixels user has to scroll to accept the usage of the cookies and make the notification disappear.','alaha'),
				'default'  => 100,
				'required' => array( 'cookie-on-scroll', '=', 1 ),
            ),
			array(
                'id'       => 'cookie-expiry-times',
                'type'     => 'select',
                'title'    => esc_html__( 'Cookie Expiry', 'alaha' ),
                'subtitle' => esc_html__( 'Select the link target for more info page.', 'alaha' ),
                'options'  => array(
					'86400'	 	=> esc_html__( '1 day', 'alaha' ),
					'604800'	=> esc_html__( '1 week', 'alaha' ),
					'2592000'	=> esc_html__( '1 month', 'alaha' ),
					'7862400'	=> esc_html__( '3 months', 'alaha' ),
					'15811200'	=> esc_html__( '6 months', 'alaha' ),
					'31536000'	=> esc_html__( '1 year', 'alaha' ),
					'31337313373' => esc_html__( 'infinity', 'alaha' ),
                ),
                'default'  => '2592000',
            ),
			array(
                'id'       => 'cookie-script-placements',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Script Placement', 'alaha' ),
                'subtitle' => esc_html__( 'Select where all the plugin scripts should be placed.', 'alaha' ),
                'options'  => array(
                    'header' => esc_html__('Header', 'alaha'),
                    'footer' => esc_html__('Footer', 'alaha'),
                ),
                'default'  => 'footer',
            ),
			array(
                'id'       => 'cookie-positions',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Position', 'alaha' ),
                'subtitle' => esc_html__( 'Select location for your cookie notice.', 'alaha' ),
                'options'  => array(
                    'top' 		=> esc_html__('Top', 'alaha'),
                    'bottom' 	=> esc_html__('Bottom', 'alaha'),
                ),
                'default'  => 'bottom'
            ),
			array(
                'id'       => 'cookie-style',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Cookie Style', 'alaha' ),
                'subtitle' => esc_html__( 'Select style of cookie notice on bottom.', 'alaha' ),
                'options'  => array(
                    'bar' 		=> esc_html__('Bar', 'alaha'),
                    'box' 	=> esc_html__('Box', 'alaha'),
                ),
                'default'  => 'box',
				'required' => array( 'cookie-positions', '=', 'bottom' ),
            ),
			array(
                'id'       => 'cookie-text-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Text Color', 'alaha' ),
                'default'  => '#212121',
            ),
			array(
                'id'       => 'cookie-background-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Bar Background Color', 'alaha' ),
                'default'  => '#fcfcfc',
            ),
		)
	) );

	/*
	* Maintenance Mode
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Maintenance Mode', 'alaha' ),
        'id'         => 'site-maintenance-mode',
		'icon'		 => 'el el-icon-website',
        'fields'     => array(
			array(
                'id'       		=> 'maintenance-mode',
                'type'     		=> 'switch',
                'title'    		=> esc_html__( 'Maintenance Mode', 'alaha' ),
				'subtitle'		=> esc_html__('Status of Maintenance Mode.', 'alaha' ),
                'default'  		=> 0,
                'on'       		=> esc_html__('On','alaha'),
                'off'      		=> esc_html__('Off','alaha'),
            ),
			array(
				'id'      	=> 'maintenance-page',
				'type'    	=> 'select',
				'title'   	=> esc_html__('Page', 'alaha' ),
				'subtitle'	=> esc_html__('Select page to display as maintenance page.', 'alaha' ),
				'data'    	=> 'pages',
			),
		)
	) );
	
	/*
	* Custom Code Mode
	*/
	Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom Css/Js', 'alaha' ),
        'id'         => 'custom-css-js',
		'icon'		 => 'el-icon-broom',
        'fields'     => array(
			array(
                'id'       => 'custom-css',
				'type'     => 'ace_editor',
				'title'    => esc_html__( 'CSS Code', 'alaha' ),
				'subtitle' => esc_html__( 'Paste your CSS code here.', 'alaha' ),
				'mode'     => 'css',
				'theme'    => 'monokai',
				'default'  => '',
            ),
			array(
				'id'       => 'custom-js-head',
				'type'     => 'ace_editor',
				'title'    => esc_html__( 'JS Code before &lt;/head&gt;', 'alaha' ),
				'subtitle' => esc_html__( 'Paste your JS code here.', 'alaha' ),
				'mode'     => 'javascript',
				'theme'    => 'chrome',
				'default'  => '',
			),
			array(
				'id'       => 'custom-js-footer',
				'type'     => 'ace_editor',
				'title'    => esc_html__( 'JS Code before &lt;/body&gt;', 'alaha' ),
				'subtitle' => esc_html__( 'Paste your JS code here.', 'alaha' ),
				'mode'     => 'javascript',
				'theme'    => 'chrome',
				'default'  => '',
			),
		)
	) );
	
    /* Action hook examples */

    // Change the arguments after they've been declared, but before the panel is created
    //add_filter('redux/options/' . $opt_name . '/args', 'change_arguments' );

    // Dynamically add a section. Can be also used to modify sections/fields
    //add_filter('redux/options/' . $opt_name . '/sections', 'dynamic_section');

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => esc_html__( 'Section via hook', 'alaha' ),
                'desc'   => esc_html__( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'alaha' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }
