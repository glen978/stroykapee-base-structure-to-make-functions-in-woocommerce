jQuery( function ( $ ){
	"use strict";
	
	var alaha_import_percent 			= 0,
        alaha_import_percent_increase 	= 0,
        alaha_import_index_request 		= 0,
        alaha_import_request_data 		= [],
        alaha_import_demo_name 			= '';
	
	$(document).on('click', '.rwmb-image-set .rwmb-image-set-inner ._kp_page_sidebar_position' , function(e) {
		var selected_val = $(this).attr('data-value');
		if(selected_val == 'none'){			
			$("#_kp_page_sidebar_widget").closest('.rwmb-field').hide();
		}else{
			$("#_kp_page_sidebar_widget").closest('.rwmb-field').show();
		}
		
	});
	
	/* Size Guide Chart Table*/
	var sizechart_table = $('#alaha-chart-table');
	if(sizechart_table.length > 0 ) {
        sizechart_table.editTable();
    }
	
	
	/* Color Picker */
    if( $('.alaha-color-box').length > 0 ) {
        $('.alaha-color-box').wpColorPicker();
    }
	 if( $('.alaha-image-clear').length > 0 ) {
		 var attachement_id = $('.alaha-attachment-id').val();
		 if(attachement_id == ''){
			 $('.alaha-image-clear').hide();
		 }
		 $(document).on('click','.alaha-image-clear',function(e){			
			var image_url = $(this).attr('data-src');			
			$('.alaha-attr-img').attr('src',image_url);
            $('.alaha-selected-attr-img').val('');
            $('.alaha-attachment-id').val('');
			$('.alaha-image-clear').hide('slow');
		});
    }
	
	/* Upload media image */
	$(document).on('click','.alaha-image-upload',function(e){
		e.preventDefault();
		var image = wp.media({ 
            title: 'Upload Image',
            multiple: false
        }).open()
        .on('select', function(e){
            var uploaded_image = image.state().get('selection').first();
            var image_url,attachment;
			attachment = uploaded_image.toJSON();
			var attachment_id = attachment.id ? attachment.id : '';
            if(typeof uploaded_image.toJSON().sizes.thumbnail === 'undefined') {
                image_url=attachment.url;
                image_url=attachment.url;
            }else{
                image_url = attachment.sizes.thumbnail.url;
            }
            $('.alaha-attr-img').attr('src',image_url);
            $('.alaha-selected-attr-img').val(image_url);
            $('.alaha-attachment-id').val(attachment_id);
			$('.alaha-image-clear').show('slow');
		
        });
	});

	/* Import Demo*/
	$(document).on('click', '.alaha-import-data .theme', function(e) {
		var content_wrp = $(this);
		var template_part = $('#alaha-popup-content');
		content_wrp.find('.theme-screenshot').addClass('loading');
		var template                = wp.template('alaha-popup-data');
		var demo_name,demo_deails,modalcontainer;
		demo_name = $(this).attr('data-name');
		alaha_import_demo_name = $(this).attr('data-name');
		modalcontainer = $(this).closest('.alaha-import-demo-popup');
		
		var data = {
						action	: 'get_demo_data',
						demo   	: demo_name
					};
					
		$.post(ajaxurl,data,function(response) {
			var data = $.parseJSON(response);
			template_part.append( template({
				title : data.title,
				demo_key : data.slug,
				preview_image : data.preview_image,
				preview_demo_link : data.preview_demo_link,
			}));
			$.magnificPopup.open({
				items			: {
					src	: '.alaha-import-demo-popup'
				},
				type			: 'inline',
				mainClass		: 'mfp-with-zoom',
				closeOnBgClick	: false,
				enableEscapeKey	: false,
				zoom			: {
					enabled	: true,
					duration: 300
				},
				callbacks		: {
					open	: function () {
						content_wrp.find('.theme-screenshot').removeClass('loading');
					},	
					close	:function(){
						template_part.html('');
					}
				},
			});
		});	
	});
	
	/* Process to import*/
	$(document).on('click', '.install-demo', function(e) {
		var import_btn = $(this);
		if (import_btn.hasClass('processing')) {
			return false;
		}
		if (import_btn.hasClass('disabled')) {
			return false;
		}
		if (import_btn.hasClass('import-completed')) {
			return false;
		}
		
		var c = confirm('Are you sure you want to import this demo?');
		if (!c) {
			return false;
		}
		
		import_btn.addClass('processing');
		import_btn.addClass('loading');
		$('.install-demo.processing').text('Importing...');
		$('.progress-percent').html('1%');
		$('.progress-bar').css('width','1%');
		$('.import-process').show();
		alaha_import_request_data = [],
		alaha_import_demo_name = $(this).attr('data-demo');
		
		var import_full_content = false,
		import_content 			= false,
		import_menu 			= false,
		import_widget 			= false,
		import_revslider 		= false,
		import_theme_options 	= false,
		import_attachments 		= false;
		var demo_name 			= alaha_import_demo_name;
		
        if ($('#import_content_' + demo_name).is(':checked')) {
            import_content = true;
        } else {
            import_content = false;
        }
		if ($('#import_widget_' + demo_name).is(':checked')) {
            import_widget = true;
        } else {
            import_widget = false;
        }
        if ($('#import_revslider_' + demo_name).is(':checked')) {
            import_revslider = true;
        } else {
            import_revslider = false;
        }
        if ($('#import_attachments_' + demo_name).is(':checked')) {
            import_attachments = true;
        } else {
            import_attachments = false;
        }
        if ($('#import_menu_' + demo_name).is(':checked')) {
            import_menu = true;
        } else {
            import_menu = false;
        }
        if ($('#import_theme_options_' + demo_name).is(':checked')) {
            import_theme_options = true;
        } else {
            import_theme_options = false;
        }
        if ($('#import_full_content_' + demo_name).is(':checked')) {
            import_full_content 	= true;
            import_widget 			= true;
            import_revslider 		= true;
            import_menu 			= true;
            import_content 			= true;
            import_attachments 		= true;
            import_theme_options 	= true;
        }
		
        /* Import content */
        if ( import_content ) {			
			var condent_no;
			for (condent_no = 1; condent_no <= 1; condent_no++) {
				var data = {
					'action'		: 'import_content',
					'count'			: condent_no,
					'attachments'	: import_attachments,
				}
				
				alaha_import_request_data.push(data);
			}		
        }
		
		/* Import Menu */
		if ( import_menu ) {
            alaha_import_request_data.push({
                'action'	: 'import_menu',
                'demo_name'	: demo_name,
            });
        }
		
		/* Import Theme Options */
        if ( import_theme_options ) {
            alaha_import_request_data.push({
                'action'	: 'import_theme_options',
                'demo_name'	: demo_name,
            });
        }
		
		/* Import Widget */
        if ( import_widget ) {
            alaha_import_request_data.push({'action': 'import_widget', 'demo_name': demo_name});
        }
		
		/* Import Slider */
        if ( import_revslider ) {
            alaha_import_request_data.push({'action': 'import_revslider', 'demo_name': demo_name});
        }
        
		/* Import Configuration */
        alaha_import_request_data.push({
            'action': 'import_config',
            'demo_name': demo_name,
        });
        
        var total_ajaxs = alaha_import_request_data.length;
        
        if (total_ajaxs == 0) {
            import_btn.removeClass('processing');
            import_btn.removeClass('loading');
			import_btn.addClass('import-completed');
            return;
        }
        
        alaha_import_percent_increase = (100 / total_ajaxs);
       
        alaha_import_ajax_call();
        
        e.preventDefault();
		
	});
	
	function alaha_import_ajax_call() {
        if (alaha_import_index_request == alaha_import_request_data.length) {
			alert('Import proceess done');
			location.reload();
            return;
        }
       $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: alaha_import_request_data[alaha_import_index_request],
            complete: function (jqXHR, textStatus) {
                alaha_import_percent += alaha_import_percent_increase;
                alaha_import_progress_bar();
                alaha_import_index_request++;
                setTimeout(function () {
                    alaha_import_ajax_call();
                }, 200);
            }
        });
    }
	function alaha_import_progress_bar(){
		if (alaha_import_percent > 100) {
            alaha_import_percent = 100;
        }
        
        if (alaha_import_percent == 100) {
            $('.install-demo.processing').text('Import Completed');
			$('.alaha-complete-action').show();
            $('.install-demo.processing').removeClass('loading');
            $('.install-demo.processing').removeClass('processing');
            
        }
        
        var progress_bar_wrap = $('[data-demo="' + alaha_import_demo_name + '"]').closest('.alaha-import-demo-popup').find('.import-process');
        progress_bar_wrap.find('.progress-percent').html(parseInt(alaha_import_percent)+'%');  
        progress_bar_wrap.find('.progress-bar').css('width',parseInt(alaha_import_percent)+'%');
	}
	
	function full_content_change() {
        $('.import_full_content').each(function () {
            var _this = $(this);
            if (_this.is(':checked')) {
                _this.closest('.import-options').find('input[type="checkbox"]').not(_this).attr('checked', false);
                _this.closest('.import-options').find('label').not(_this.parent()).css({
                    'pointer-events': 'none',
                    'opacity': '0.4'
                });
            } else {
                _this.closest('.import-options').find('label').not(_this.parent()).css({
                    'pointer-events': 'initial',
                    'opacity': '1'
                });
            }
        })
		if ($(".import-options input:checkbox:checked").length > 0)
		{
			$('.import-options').closest('.alaha-box-body').find('.install-demo').removeClass('disabled');
		}
		else
		{
		   $('.import-options').closest('.alaha-box-body').find('.install-demo').addClass('disabled');
		}
    }
    
    full_content_change();
    
    $(document).on('change', function () {
        full_content_change()
    });
	

} );
jQuery(window).on("load", function(){
    var sidebar_position = jQuery('.rwmb-image-set #_kp_page_sidebar_position').val();
	if(sidebar_position == 'none'){	
		jQuery("#_kp_page_sidebar_widget").closest('.rwmb-field').hide();
	}
});



jQuery(function($) {
	
	$(document).on('click', '.alaha-mask-overaly', function(e) {
		$.magnificPopup.close();
	});
	
});