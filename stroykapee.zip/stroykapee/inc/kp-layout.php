<?php
/**
 * Custom functions for layout.
 *
 * @package Stroyka
 */

/**
 * Get layout base on current page
 *
 * @return string
 */
function alaha_get_layout() {
	$layout = alaha_get_option( 'blog-page-layout', 'right-sidebar' );

	if ( alaha_get_post_meta( 'layout' ) ) {		
		$layout = alaha_get_post_meta( 'layout' );
	} elseif ( is_singular( 'post' ) ) {
		$layout = alaha_get_option( 'single-post-layout', 'right-sidebar' );
	} elseif ( is_singular( 'portfolio' ) ) {
		$layout = alaha_get_option( 'single-portfolio-page-layout', 'full-width' );
	} elseif( function_exists( 'alaha_is_wcmp_vendor_page' ) && alaha_is_wcmp_vendor_page() ) {
		$layout = alaha_get_option( 'vendor-page-layout', 'left-sidebar' );
	}elseif( alaha_is_wc_vendor_page() ){
		$layout = alaha_get_option( 'vendor-page-layout', 'left-sidebar' );
	}elseif ( alaha_is_catalog() ) {
		$layout = alaha_get_option( 'shop-page-layout','left-sidebar' );
		$product_columns = alaha_get_option( 'products-columns', 4 );
		if($product_columns > 4){
			$layout = 'full-width';
		}		
	} elseif(ALAHA_DOKAN_ACTIVE && ( dokan_is_store_page() || dokan_is_product_edit_page() )){
		$layout = 'full-width';
	} elseif( function_exists('alaha_is_wcmp_vendor_page') && alaha_is_wcmp_vendor_page()){
		$layout = 'full-width';
	} elseif ( function_exists('is_product') && is_product() )  {
		$layout = alaha_get_option( 'product-page-layout', 'full-width' );
	} elseif ( function_exists('alaha_full_pages') && alaha_full_pages() )  {
		$layout = 'full-width';
	} elseif ( is_404() ) {
		$layout = 'full-width';
	}elseif ( alaha_is_portfolio() ) {
		$layout = alaha_get_option( 'portfolio-page-layout', 'full-width' );		
	}elseif (  is_singular( 'page' ) ) { 
		$layout = alaha_get_option( 'page-layout', 'full-width' );
	} 
	$layout = !empty($layout) ? $layout : 'full-width';
	return apply_filters( 'alaha_site_layout', $layout );
}

/**
 * Get sidebar width on current page
 *
 * @return string
 */
function alaha_get_sidebar_width() {
	$layout = alaha_get_layout();
	$sidebar_width = alaha_get_option( 'blog-sidebar-width', '3' );
	if($layout == 'full-width'){
		$sidebar_width = '';
	}else{
		$meta_sidebar = alaha_get_post_meta( 'sidebar_width' );
		if ( !empty($meta_sidebar) && $meta_sidebar != 'default') {
			$sidebar_width = alaha_get_post_meta( 'sidebar_width' ); 
		} elseif ( is_singular( 'post' ) ) {
			$sidebar_width = alaha_get_option( 'single-post-sidebar-width', '3' );
		} elseif ( is_singular( 'portfolio' ) ) {
			$sidebar_width = alaha_get_option( 'single-portfolio-sidebar-width', '3' );
		} elseif( function_exists( 'alaha_is_wcmp_vendor_page' ) && alaha_is_wcmp_vendor_page() ) {
			$sidebar_width = alaha_get_option( 'vendor-sidebar-width', '3');
		} elseif( alaha_is_wc_vendor_page() ){
			$sidebar_width = alaha_get_option( 'vendor-sidebar-width', '3');
		}elseif ( alaha_is_catalog() ) {
			$sidebar_width = alaha_get_option( 'shop-page-sidebar-width','3' );
		} elseif ( function_exists('is_product') && is_product()  ) {
			$sidebar_width = alaha_get_option( 'product-page-sidebar-width', '3' );
		} elseif ( alaha_is_portfolio() ) {
			$sidebar_width = alaha_get_option( 'portfolio-sidebar-width', '3' );		
		} elseif ( is_singular( 'page' ) ) {			
			$sidebar_width = alaha_get_option( 'page-sidebar-width', '3' );
		} 
	}
	
	return apply_filters( 'alaha_sidebar_width', $sidebar_width );
}

/**
 * Get sidebar name on current page
 *
 * @return string
 */
function alaha_get_sidebar_name() {
	$layout = alaha_get_layout();
	$sidebar_widget = alaha_get_option( 'blog-page-sidebar-widget', 'sidebar-1' );
	if($layout == 'full-width'){
		$sidebar_widget = '';
	}else{
		if ( alaha_get_post_meta( 'sidebar_widget' )) {
			$sidebar_widget = alaha_get_post_meta( 'sidebar_widget' );
		} elseif ( is_singular( 'post' ) ) {
			$sidebar_widget = alaha_get_option( 'single-post-sidebar-widget', 'sidebar-1' );
		} elseif ( is_singular( 'portfolio' ) ) {
			$sidebar_widget = alaha_get_option( 'single-portfolio-sidebar-widget', 'sidebar-1' );
		} elseif( function_exists( 'alaha_is_wcmp_vendor_page' ) && alaha_is_wcmp_vendor_page() ) {
			$sidebar_widget = alaha_get_option( 'vendor-page-sidebar-widget', 'shop-page-sidebar' );
		} elseif( alaha_is_wc_vendor_page() ){
			$sidebar_widget = alaha_get_option( 'vendor-page-sidebar-widget', 'shop-page-sidebar' );
		} elseif ( alaha_is_catalog() ) {
			$sidebar_widget = alaha_get_option( 'shop-page-sidebar-widget', 'shop-page-sidebar' );
			$prefix = ALAHA_PREFIX;
			$cat_sidebar    = '';
			if ( function_exists( 'is_product_category' ) && is_product_category() ) {				
				$queried_object = get_queried_object();
				$term_id        = $queried_object->term_id;				
				$cat_sidebar    = get_term_meta( $term_id, $prefix.'sidebar', true );
				$cat_ancestors  = get_ancestors( $term_id, 'product_cat' );
				if ( empty( $cat_sidebar ) && count( $cat_ancestors ) > 0 ) {
					$parent_id   = $cat_ancestors[0];
					$cat_sidebar = get_term_meta( $parent_id, $prefix.'sidebar', true );
				}				
			}
			if( !empty( $cat_sidebar ) ){
				$sidebar_widget  = $cat_sidebar;
			}
			
		} elseif ( function_exists('is_product') && is_product() ) {
			$sidebar_widget = alaha_get_option( 'product-page-sidebar-widget', 'product-page-sidebar' );
		} elseif ( alaha_is_portfolio() ) {
			$sidebar_widget = alaha_get_option( 'portfolio-sidebar-widget', 'sidebar-1' );		
		}
	}
	
	return apply_filters( 'alaha_sidebar_widget', $sidebar_widget );
}

/**
 * Get Bootstrap column classes for content area
 *
 * @since  1.0
 *
 * @return array Array of classes
 */
function alaha_get_content_columns( $layout = null, $sidebar_width = null ) {
	$layout  		= $layout ? $layout : alaha_get_layout();
	$sidebar_width  = $sidebar_width ? $sidebar_width : alaha_get_sidebar_width();
	$classes 		= array( 'col-12', 'col-md-8', 'col-lg-9', 'col-xl-9' );	
	$sidebar_name 	= alaha_get_sidebar_name();
	
	if ( 'full-width' == $layout  || ! is_active_sidebar( $sidebar_name ) ) {
		$classes = array( 'col-md-12' );
	}elseif($sidebar_width == 4){
		$classes = array( 'col-12', 'col-md-8', 'col-lg-8', 'col-xl-8' );
	}

	return apply_filters( 'alaha_content_columns', $classes );
}

/**
 * Get Bootstrap column classes for sidebar area
 *
 * @since  1.0
 *
 * @return array Array of classes
 */
function alaha_get_sidebar_columns( $layout = null, $sidebar_width = null ) {
	$layout  = $layout ? $layout : alaha_get_layout();
	$sidebar_width  = $sidebar_width ? $sidebar_width : alaha_get_sidebar_width();
	$classes = array( 'col-12', 'col-md-4', 'col-lg-3', 'col-xl-3' );

	if($sidebar_width == 4){
		$classes = array( 'col-12', 'col-md-4', 'col-lg-4', 'col-xl-4' );
	}

	return apply_filters( 'alaha_sidebar_columns', $classes );
}


/**
 * Function to get grid class
 */
if ( ! function_exists( 'alaha_get_grid_class' ) ) :
	function alaha_get_grid_class( $column = '3' ){
		$grid_class = '';
		switch($column){
			case 1:
				$grid_class = ' col-12';
				break;
			case 2:
				$grid_class = ' col-12 col-md-6 col-lg-6';
				break;
			case 3:
				$grid_class = ' col-12 col-md-6 col-lg-4';
				break;
			case 4:
				$grid_class = ' col-12 col-md-6 col-lg-3';
				break;
		}
		
		return apply_filters( 'alaha_get_grid_class', $grid_class );
	}
endif;

/**
 * Get Bootstrap reverse class
 *
 * @since  1.0
 *
 * @return string 
 */
function alaha_sidebar_reverse($echo = true) {
	$layout  = alaha_get_layout();
	$reverse_class = '';
	if($layout == 'left-sidebar'){
		$reverse_class = 'flex-row-reverse';
	}
	if($echo){
		echo apply_filters('alaha_sidebar_reverse',$reverse_class);
	}else{
		return apply_filters('alaha_sidebar_reverse',$reverse_class);
	}
}

/**
 * Check is catalog
 *
 * @return bool
 */
function alaha_is_catalog() {

	if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() || is_product_tag() || is_tax( 'product_brand' ) ) ) {
		return true;
	}

	return false;
}

/**
 * Check is catalog
 *
 * @return bool
 */
if ( ! function_exists( 'alaha_full_pages' ) ) :
	function alaha_full_pages() {

		if ( (function_exists( 'is_cart' )  && is_cart()) ||
			 (function_exists( 'is_checkout' )  && is_checkout()) ||
			 (function_exists( 'is_account_page' )  && is_account_page()) ||
			 (function_exists( 'is_wc_endpoint_url' )  && is_wc_endpoint_url()) || alaha_is_wishlist_page()) {
			return true;
		}

		return false;
	}
endif;

/**
 * Check is wishlist page
 *
 * @return bool
 */
if ( ! function_exists( 'alaha_is_wishlist_page' ) ) :
	function alaha_is_wishlist_page() {
		if ( function_exists( 'YITH_WCWL' )) {
			$wishlist_pageid = get_option('yith_wcwl_wishlist_page_id',true);
			global $post;
			if($post){
				$page_id = $post->ID;
				if($page_id == $wishlist_pageid){
					return true;
				}
			}
			
		}
		return false;
	}
endif;

/**
 * Check is portfolio
 *
 * @return bool
 */
if ( ! function_exists( 'alaha_is_portfolio' ) ) :
	function alaha_is_portfolio() {

		if (  is_post_type_archive( 'portfolio' ) || is_tax( array('portfolio_cat', 'portfolio_tag') ) ) {
			return true;
		}

		return false;
	}
endif;

/**
 * Get image size
 *
 * @since  1.0
 *
 * @return string size
 */
if ( ! function_exists( 'alaha_get_post_thumbnail_size' ) ) :
	function alaha_get_post_thumbnail_size() {
		$layout  					=  alaha_get_layout();
		$blog_post_style			= alaha_get_loop_prop('blog-post-style');
		$grid_columns				= alaha_get_loop_prop('blog-grid-columns');
		$blog_custom_image_size		= alaha_get_loop_prop( 'blog-custom-thumbnail-size' );
		
		$size	= 'large';
		if( $layout == 'full-width' && ($blog_post_style == 'blog-bottom-overlap' || $blog_post_style == 'blog-bottom-overlap-center' || $blog_post_style == 'blog-full-width')){
			$size	= 'full';
		} elseif(	$blog_post_style == 'blog-grid'  && ($layout != 'full-width' || $grid_columns != 'two-columns') ){
			$size	='medium';
		}
		if(!empty($blog_custom_image_size)){
			$size = $blog_custom_image_size;	 
		}
		return apply_filters( 'alaha_post_thumbnail_size', $size );
	}
endif;

if ( ! function_exists( 'alaha_is_vendor_page' ) ) :
	function alaha_is_vendor_page(){
		
		/* Dokan */
		if ( function_exists( 'dokan_is_store_page' ) && dokan_is_store_page() ) {
			return true;
		}

		/* WC Vendor */
		if ( alaha_is_wc_vendor_page() ) {
			return true;
		}	
		
		/* WCMP plugin*/
		if ( function_exists( 'alaha_is_wcmp_vendor_page' ) && alaha_is_wcmp_vendor_page() ) {
			return true;
		}
		
		/* WCFM plugin*/
		if ( function_exists( 'wcfm_is_store_page' ) && wcfm_is_store_page() ) {
			return true;
		}
		return false;
			
	}
endif;

/**
 * Check is vendor page
 *
 * @return bool
 */
if ( ! function_exists( 'alaha_is_wc_vendor_page' ) ) :
	/* WC Vendor */
	function alaha_is_wc_vendor_page() {
	
		if ( class_exists( 'WCV_Vendors' ) && method_exists( 'WCV_Vendors', 'is_vendor_page' ) ) {
			return WCV_Vendors::is_vendor_page();
		}

		return false;
	}
endif;