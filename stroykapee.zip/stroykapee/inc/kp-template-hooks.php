<?php
/**
 * Action/filter hooks used for theme functions/templates.
 *
 * @author 		stroykas
 * @package 	alaha/inc
 * @version     1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_filter( 'body_class', 'alaha_body_classes' );
add_filter( 'post_class', 'alaha_post_classes', 10, 3 );

add_action( 'alaha_body_top', 'alaha_site_loader', 1 );
/**
 * Content Wrappers.
 *
 * @see alaha_output_content_wrapper()
 * @see alaha_output_content_wrapper_end()
 */
add_action( 'alaha_before_main_content', 'alaha_output_content_wrapper', 10 );
add_action( 'alaha_after_main_content', 'alaha_output_content_wrapper_end', 10 );

/**
 * Header.
 *
 * @see alaha_template_header()
 * @see alaha_header_topbar_left()
 * @see alaha_header_topbar_right()
 * @see alaha_header_main_left()
 * @see alaha_header_main_center()
 * @see alaha_header_main_right()
 * @see alaha_header_navigation_left()
 * @see alaha_header_navigation_center()
 * @see alaha_header_navigation_right()
 */
add_action( 'alaha_header', 'alaha_template_header', 10 );
add_action( 'alaha_header_topbar_left', 'alaha_header_topbar_left', 10 );
add_action( 'alaha_header_topbar_right', 'alaha_header_topbar_right', 10 );
add_action( 'alaha_header_main_left', 'alaha_header_main_left', 10 );
add_action( 'alaha_header_main_center', 'alaha_header_main_center', 10 );
add_action( 'alaha_header_main_right', 'alaha_header_main_right', 10 );
add_action( 'alaha_header_navigation_left', 'alaha_header_navigation_left', 10 );
add_action( 'alaha_header_navigation_center', 'alaha_header_navigation_center', 10 );
add_action( 'alaha_header_navigation_right', 'alaha_header_navigation_right', 10 );
add_action( 'alaha_header_sticky_left', 'alaha_header_sticky_left', 10 );
add_action( 'alaha_header_sticky_center', 'alaha_header_sticky_center', 10 );
add_action( 'alaha_header_sticky_right', 'alaha_header_sticky_right', 10 );
add_action( 'alaha_header_mobile_left', 'alaha_header_mobile_left', 10 );
add_action( 'alaha_header_mobile_center', 'alaha_header_mobile_center', 10 );
add_action( 'alaha_header_mobile_right', 'alaha_header_mobile_right', 10 );
add_action( 'alaha_header_mobile_sticky_left', 'alaha_header_mobile_sticky_left', 10 );
add_action( 'alaha_header_mobile_sticky_center', 'alaha_header_mobile_sticky_center', 10 );
add_action( 'alaha_header_mobile_sticky_right', 'alaha_header_mobile_sticky_right', 10 );
/**
 * Page Title.
 *
 * @see alaha_template_page_title()
 * @see alaha_template_breadcrumbs()
 */
add_action( 'alaha_page_title', 'alaha_page_title', 10 );
add_action( 'alaha_inner_page_title', 'alaha_template_page_title', 10 );
add_action( 'alaha_inner_page_title', 'alaha_template_breadcrumbs', 20 );


/**
 * Sidebar.
 *
 * @see alaha_get_sidebar()
 */
add_action( 'alaha_sidebar', 'alaha_get_sidebar', 10 );

/**
 * Page
 *
 * @see alaha_template_page_content()
 * @alaha_template_page_comments()
 */
add_action( 'alaha_page_content', 'alaha_template_page_content', 10 );
add_action( 'alaha_after_page_entry', 'alaha_template_page_comments', 10 );

/**
 * Post Loop.
 *
 * @see alaha_post_wrapper()
 * @see alaha_template_loop_post_fancy_date()
 * @see alaha_template_loop_post_highlight()
 * @see alaha_template_loop_post_thumbnail()
 * @see alaha_template_loop_post_header()
 * @see alaha_template_loop_post_content()
 * @see alaha_template_loop_post_footer()
 * @see alaha_post_wrapper_end()
 * @see alaha_pagination()
 */
 
add_action( 'alaha_loop_post_entry_top', 'alaha_post_wrapper', 10 );
add_action( 'alaha_loop_post_thumbnail', 'alaha_template_loop_post_fancy_date', 10 );
add_action( 'alaha_loop_post_thumbnail', 'alaha_template_loop_post_highlight', 20 );
add_action( 'alaha_loop_post_thumbnail', 'alaha_template_loop_post_thumbnail', 30 );
add_action( 'alaha_loop_post_content', 'alaha_template_loop_post_header', 10 );
add_action( 'alaha_loop_post_content', 'alaha_template_loop_post_content', 20 );
add_action( 'alaha_loop_post_content', 'alaha_template_loop_post_footer', 30 );
add_action( 'alaha_loop_post_entry_bottom', 'alaha_post_wrapper_end', 10 );
add_action( 'alaha_after_loop_post', 'alaha_pagination', 10 );

//Inner hook
add_action( 'alaha_loop_post_header', 'alaha_template_loop_post_title', 10 );
add_action( 'alaha_loop_post_header', 'alaha_template_loop_post_meta', 20 );
add_action( 'alaha_loop_post_footer', 'alaha_template_read_more_link', 10 );

/**
 * Single Post.
 *
 * @see alaha_post_wrapper()
 * @see alaha_template_single_post_fancy_date()
 * @see alaha_template_single_post_highlight()
 * @see alaha_template_single_post_thumbnail()
 * @see alaha_template_single_post_header()
 * @see alaha_template_single_post_content()
 * @see alaha_post_wrapper_end()
 * @see alaha_template_single_tag_social_share()
 * @see alaha_template_single_post_author_bios()
 * @see alaha_template_single_post_navigation()
 * @see alaha_template_single_post_related()
 * @see alaha_template_single_post_comments()
 * @see alaha_template_single_post_title()
 * @see alaha_template_single_post_meta()
 */
 
add_action( 'alaha_single_post_entry_top', 'alaha_post_wrapper', 10 );
add_action( 'alaha_single_post_entry_top', 'alaha_template_single_post_header', 15 );
add_action( 'alaha_single_post_thumbnail', 'alaha_template_single_post_fancy_date', 10 );
add_action( 'alaha_single_post_thumbnail', 'alaha_template_single_post_highlight', 20 );
add_action( 'alaha_single_post_thumbnail', 'alaha_template_single_post_thumbnail', 30 );
add_action( 'alaha_single_post_content', 'alaha_template_single_post_content', 20 );
add_action( 'alaha_single_post_entry_bottom', 'alaha_post_wrapper_end', 10 );
add_action( 'alaha_after_single_post_entry', 'alaha_template_single_post_author_bios', 10 );
add_action( 'alaha_after_single_post_entry', 'alaha_template_single_tag_social_share', 20 );
add_action( 'alaha_after_single_post_entry', 'alaha_template_single_post_navigation', 30 );
add_action( 'alaha_after_single_post_entry', 'alaha_template_single_post_related', 40 );
add_action( 'alaha_after_single_post_entry', 'alaha_template_single_post_comments', 50 );

//Inner hook
add_action( 'alaha_single_post_header', 'alaha_template_single_post_title', 10 );
add_action( 'alaha_single_post_header', 'alaha_template_single_post_meta', 20 );
 
/**
 * Portfolio Loop.
 *
 * @see alaha_template_portfolio_filter()
 * @see alaha_post_wrapper()
 * @see alaha_template_portfolio_loop_thumbnail()
 * @see alaha_template_portfolio_loop_action_icon()
 * @see alaha_template_portfolio_loop_header()
 * @see alaha_post_wrapper_end()
 * @see alaha_template_portfolio_loop_categories()
 * @see alaha_template_portfolio_loop_title()
 * @see alaha_portfolio_pagination()
 */

add_action( 'alaha_before_portfolio_loop', 'alaha_template_portfolio_filter', 10 );
add_action( 'alaha_portfolio_loop_entry_top', 'alaha_post_wrapper', 10 );
add_action( 'alaha_portfolio_loop_thumbnail', 'alaha_template_portfolio_loop_thumbnail', 10 );
add_action( 'alaha_portfolio_loop_thumbnail', 'alaha_template_portfolio_loop_action_icon', 20 );
add_action( 'alaha_portfolio_loop_content', 'alaha_template_portfolio_loop_header', 10 );
add_action( 'alaha_portfolio_loop_entry_bottom', 'alaha_post_wrapper_end', 10 );
add_action( 'alaha_after_portfolio_loop', 'alaha_portfolio_pagination', 10 );

//Inner hook 
add_action( 'alaha_portfolio_loop_header', 'alaha_template_portfolio_loop_categories',10 );
add_action( 'alaha_portfolio_loop_header', 'alaha_template_portfolio_loop_title',20 );;

/**
 * Single Post.
 *
 * @see alaha_post_wrapper()
 * @see alaha_template_single_portfolio_image()
 * @see alaha_template_single_portfolio_title()
 * @see alaha_template_single_portfolio_content()
 * @see alaha_template_single_portfolio_client()
 * @see alaha_template_single_portfolio_date()
 * @see alaha_template_single_portfolio_category()
 * @see alaha_template_single_portfolio_skill()
 * @see alaha_template_single_portfolio_share()
 * @see alaha_template_single_portfolio_navigation()
 * @see alaha_template_single_related_portfolio()
 * @see alaha_template_single_portfolio_comments()
 * @see alaha_post_wrapper_end()
 */
add_action( 'alaha_single_portfolio_entry_top', 'alaha_post_wrapper', 10 );
add_action( 'alaha_single_portfolio_image', 'alaha_template_single_portfolio_image', 10 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_title', 5 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_content', 10 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_preview', 15 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_client', 20 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_date', 25 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_category', 30 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_skill', 35 );
add_action( 'alaha_single_portfolio_summary', 'alaha_template_single_portfolio_share', 40 );
add_action( 'alaha_after_single_portfolio_entry', 'alaha_template_single_portfolio_navigation', 10 );
add_action( 'alaha_after_single_portfolio_entry', 'alaha_template_single_related_portfolio', 20 );
add_action( 'alaha_after_single_portfolio_entry', 'alaha_template_single_portfolio_comments', 30 );
add_action( 'alaha_single_portfolio_entry_bottom', 'alaha_post_wrapper_end', 10 );


/* Comming Soon */
add_action( 'template_redirect', 'alaha_coming_soon_redirect' );

/**
 * Footer.
 *
 * @see alaha_template_footer()
 */
add_action( 'alaha_footer', 'alaha_template_footer', 10 );
add_action( 'alaha_footer', 'alaha_back_to_top', 20 );
add_action( 'alaha_footer', 'alaha_newsletter_popup',30);/* Newsletter popup */
add_action( 'alaha_body_bottom', 'alaha_close_popup', 50 );