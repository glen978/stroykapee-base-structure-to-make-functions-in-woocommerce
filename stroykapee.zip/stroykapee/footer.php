<?php
/**
 * The template for displaying the footer
 *
 * @author 	stroykas
 * @package alaha
 * @since 1.0.0
 */
?>
				</div><!-- .row -->		
			</div><!-- .container -->
			
			<?php do_action( 'alaha_site_content_botton' ); ?>
			
		</div><!-- .site-content -->
		
		<?php
		/**
		 * Hook: alaha_footer.
		 *
		 * @hooked alaha_template_footer- 10
		 */
		do_action( 'alaha_footer' );
		?>
		
	</div><!-- .site-wrapper -->
	
	<?php do_action( 'alaha_body_bottom' ); ?>
	<?php wp_footer(); ?>
	</body>
</html>